package com.veo.suite.CancellationProcess;

import java.awt.AWTException;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Cancellation_09_03_Submitted extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CancellationProcess_xls,this.getClass().getSimpleName())){
				prntResults("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CancellationProcess_xls, this.getClass().getSimpleName());
		}
	
		@Test(dataProvider="getTestData")
		public void ablity_to_Cancel_SubmittedOrder(
			String UsernameBackoffice,
			String PasswordBackoffice,
			String OrderStatus_Dropdwon,
			String OrderStatus_Dropdwon_New,
			String OrderDetailsPage_Status
			) throws InterruptedException, IOException, AWTException,Exception, Throwable
{
				count++;
				
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		//Starting Point of the Testcase
		prntResults("***************************************************************************************");
		prntResults("Executing CancellationProcess TC_09_03_Submitted");
		prntResults("***************************************************************************************");
		prntResults("Able to Cancel an order in Submitted Status");
		prntResults("***************************************************************************************");
		prntResults("Username: "+UsernameBackoffice +"& Password: "+PasswordBackoffice);
		sessionData.put("mobile_"+count, UsernameBackoffice);
		
		String Flagged_OrderNo;
		
		//=================================== Opening the Browser ===================================//
			openBrowser();
			prntResults("Browserup"+this.getClass().getSimpleName());
		
			//Enter the URL 
			driver.get(CONFIG.getProperty("backofficeurl"));
			prntResults("Entered the URL of Backoffice Application");
		
		try
		{
		
	//======================================== Login to Backoffice ========================================//
			
			if(!LoginBackOffice("CancellationProcess_BO_UserName","CancellationProcess_BO_PassWord","CancellationProcess_BO_Login",UsernameBackoffice,PasswordBackoffice)){
				// screenshot
				prntResults("Login Backoffice FAILED");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			//WaitForObjectAvailability("CancellationProcess_BO_OrderStatus");
			
	//======================================== Selecting Flagged Order from Order Status ========================================//
			//Clear the Start Date 
			getObject("CancellationProcess_BO_StartDate").clear();
			prntResults("Cleraed the Start Date");
			
			//Select the Flagged Order from the Order Status Dropdown 
			getObject("CancellationProcess_BO_OrderStatus").click();
			prntResults("Clicked on Order Status");
			getObject("CancellationProcess_BO_OrderStatus").clear();
			getObject("CancellationProcess_BO_OrderStatus").sendKeys(OrderStatus_Dropdwon);
			prntResults("Selected the Option "+OrderStatus_Dropdwon+" from the Order Status");
			getObject("CancellationProcess_BO_OrderStatus").click();
			prntResults("Clicked on Order Status");
			
	//======================================== Click on Refresh button ========================================//
			
			//Click on Refresh
			getObject("CancellationProcess_BO_RefreshButton").click();
			prntResults("Clicked on Refresh button");
			//Thread.sleep(3000);
			//WaitForObjectAvailability("CancellationProcess_BO_Order");
			
		//=========================== To Click on First Flagged Order ==============================//
			
			int order_rowcount = driver.findElements(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[1]/div/div/div[2]/div[3]/div[3]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr")).size();
			prntResults("No.Of.Orders found in first page is : "+order_rowcount);
			//WaitForObjectAvailability("CancellationProcess_BO_Order");
			
			if(!(order_rowcount == 0))
			{
			//Click on the First Order in Backoffice 
			Flagged_OrderNo = getObject("CancellationProcess_BO_Order").getText();
			prntResults("Selected Order No is : "+Flagged_OrderNo);
			getObject("CancellationProcess_BO_Order").click();
			prntResults("Clicked on First Flagged Order in Backoffice");
			}
			else
			{
				prntResults("FAILED: No Results Found Error / Unexpected Error");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				throw new Exception("FAILED: No Results Found Error / Unexpected Error");
			}
			
	//=========================== Window Handle(Veo Cart Page) ==============================//
			
			//get the handle of parent window
			String Parent_Window =driver.getWindowHandle(); 
			prntResults("Parent Window is :"+driver.getTitle());
			/*//get all the windows handle
			Set<String> handles1=driver.getWindowHandles();*/
			
			//loop through each handles
			for(String childWindow:driver.getWindowHandles())
			{
				//check if the handles is not parent
				if(!childWindow.equals(Parent_Window))
				{
					//Change the control into new window
					driver.switchTo().window(childWindow);
					Thread.sleep(5000);

				}
			}
			prntResults("Switched to new window: "+driver.getTitle());
			Thread.sleep(7000);
			//WaitForObjectAvailability("CancellationProcess_BO_Amend");
			
		//=========================== Clicking on Amend Button ==============================//
			
			//click on the Amend Button 
			highlightElement("CancellationProcess_BO_Amend");
			getObject("CancellationProcess_BO_Amend").click();
			prntResults("Clicked on Amend button");
			//WaitForObjectAvailability("CancellationProcess_BO_Cancel");
		
	//=========================== Clicking on Cancel Button ==============================//

			//Click on Cancel 
			getObject("CancellationProcess_BO_Cancel").click();
			prntResults("Clicked on the Cancel order");
			//WaitForObjectAvailability("CancellationProcess_BO_CancelYes");			
	//=========================== Clicking on Yes Button in Cancel Popup ==============================//
			//Click on Yes Button 
			getObject("CancellationProcess_BO_CancelYes").click();
			prntResults("Clicked on the Cancel order->yes");
			//Thread.sleep(5000);
			
	//=========================== Changing the Window Handle to Parent Window(Backoffice) ==============================//
			driver.switchTo().window(Parent_Window);
			prntResults("Switched to Parent Window: "+driver.getTitle());
			//WaitForObjectAvailability("CancellationProcess_BO_OrderStatus");
			
	//======================================== Selecting Cancelled Order from Order Status ========================================//

			getObject("CancellationProcess_BO_OrderStatus").click();
			prntResults("Clicked on Order Status");
			getObject("CancellationProcess_BO_OrderStatus").clear();
			getObject("CancellationProcess_BO_OrderStatus").sendKeys(OrderStatus_Dropdwon_New);
			prntResults("Selected the Option "+OrderStatus_Dropdwon_New+" from the Order Status");
			getObject("CancellationProcess_BO_OrderStatus").click();
			prntResults("Clicked on Order Status");
			//WaitForObjectAvailability("CancellationProcess_BO_RefreshButton");
			
	//======================================== Click on Refresh button ========================================//
			
			//Click on Refresh
			getObject("CancellationProcess_BO_RefreshButton").click();
			prntResults("Clicked on Refresh button");
			Thread.sleep(3000);
			
			//======================================== Validating Order Status from Cancelled Order ========================================//

			int order_rowcount1 = driver.findElements(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[1]/div/div/div[2]/div[3]/div[3]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr")).size();
			prntResults("No.Of.Orders found in first page is : "+order_rowcount1);
			//WaitForObjectAvailability("CancellationProcess_BO_Order");
			
			if(!(order_rowcount1 == 0))
			{
				for(int i=1;i<=order_rowcount1;i++)
				{
					//Click on the First Order in Backoffice 
					String Cancelled_OrderNo = driver.findElement(By.xpath("//table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).getText();
					prntResults("Checking Order No : "+Cancelled_OrderNo);
					
								if(Cancelled_OrderNo.equals(Flagged_OrderNo))
								{
								prntResults("Success: Order Status changed from "+OrderStatus_Dropdwon+" to "+OrderStatus_Dropdwon_New+" in Back-Office");
								
								//Fetch the ERP Number and Click on the ERP for the Selected Orders 
								String ERP_No = driver.findElement(By.xpath("//table/tbody[2]/tr["+i+"]/td[2]/div/span/a")).getText();
								prntResults("Selected ERP is :"+ERP_No);
								
								//Click on the ERP Number 
								//Highlight the ERP Number
					              JavascriptExecutor js = (JavascriptExecutor)driver;
					              WebElement element = driver.findElement(By.xpath("//table/tbody[2]/tr["+i+"]/td[2]/div/span/a"));    
			                      js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
			                      element, "color: red; border: 5px solid red;");	                           
			                      Thread.sleep(2000);
					              
								driver.findElement(By.xpath("//table/tbody[2]/tr["+i+"]/td[2]/div/span/a")).click();
								prntResults("Clicked on the ERP : "+ERP_No);
								Thread.sleep(5000);
								
								//=========================== Window Handle(Veo Home Page) ==============================//
											
								//loop through each handles
											for(String childWindow2:driver.getWindowHandles())
											{
													//check if the handles is not parent
													if(!childWindow2.equals(Parent_Window))
													{
														//Change the control into new window
														driver.switchTo().window(childWindow2);
														Thread.sleep(5000);
													}
											}
								prntResults("Switched to New Window : "+driver.getTitle());
								Thread.sleep(7000);
					
					//=========================== Click on Man Ikon ==============================//
					getObject("CancellationProcess_Veo_ManIkon").click();
					prntResults("Clicked on Man Ikon");
					Thread.sleep(3000);
					//=========================== Click on Order History ==============================//
					highlightElement("CancellationProcess_Veo_OrderHistory");
					getObject("CancellationProcess_Veo_OrderHistory").click();
					prntResults("Clicked on Order History");

					//================ Get the Order Count in Order History Page ==============//
					int OrderHistory_OrdersCount = driver.findElements(By.xpath("html/body/div[2]/div/div[3]/div/div[2]/form/div/table/tbody/tr")).size();
					prntResults("No.Of.Orders found in Order History Page is : "+OrderHistory_OrdersCount);
					
					if(!(OrderHistory_OrdersCount == 0))
					{
						for(int j=1;j<=OrderHistory_OrdersCount;j++)
						{
							String OrderHistory_OrderNo = driver.findElement(By.xpath(".//*[@id='history-table']/tbody/tr["+j+"]/td[1]/div/a")).getText();
							prntResults(j+" row Order No in Order History Page is: "+OrderHistory_OrderNo);
							if(Cancelled_OrderNo.equals(OrderHistory_OrderNo))
							{
								highlightElement("CancellationProcess_Veo_OrderHistoryPage_Status");
								String OrderHistory_Status = getObject("CancellationProcess_Veo_OrderHistoryPage_Status").getText();
								prntResults("Status of Order in Order History Page is : "+OrderHistory_Status);
								
								if(OrderHistory_Status.equals(OrderStatus_Dropdwon_New))
								{
									prntResults("Success: Orders Status in Order History page is : "+OrderHistory_Status);
								}
									else
									{
										prntResults("FAILED: Status of the Order in Order Details page as : "+OrderHistory_Status+" not as "+OrderStatus_Dropdwon_New);
										capturescreenshot(this.getClass().getSimpleName()+"_"+count);
										throw new Exception("FAILED: Status of the Order in Order Details page as : "+OrderHistory_Status+" not as "+OrderStatus_Dropdwon_New);
									
									}
								break;
							}
								else
								{
									if(j == OrderHistory_OrdersCount)
									{
									prntResults("FAILED: Cancelled Order Number not found in Order History Page");
									capturescreenshot(this.getClass().getSimpleName()+"_"+count);
									throw new Exception("FAILED: Cancelled Order Number not found in Order History Page");
									}
								}
						}
					
					}
							else
							{
								prntResults("FAILED: No Orders found in Order History Page");
								capturescreenshot(this.getClass().getSimpleName()+"_"+count);
								throw new Exception("FAILED: No Orders found in Order History Page");
							}
							break;
					}
						else
						{
							if(i==order_rowcount1)
							{
							prntResults("FAILED: Cancelled Orders not found in Displayed Orders");
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							throw new Exception("FAILED: Cancelled Orders not found in Displayed Orders");
						}
					}
				}
			}
			
			else
			{
				prntResults("FAILED: Cancelled Order is not displayed in Cancelled Order Window");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				throw new Exception("FAILED: Cancelled Order is not displayed in Cancelled Order Window");
			}
						
	}
		catch (Exception e) 
		{
			ErrorUtil.addVerificationFailure(e);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			System.err.println("Failed");
			prntResults("Test Failed");
			throw e;
		} 
	

	}
			
			@AfterMethod
			public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_CancellationProcess_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_CancellationProcess_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_CancellationProcess_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
			
			}
			
			@AfterTest
			public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_CancellationProcess_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CancellationProcess_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_CancellationProcess_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CancellationProcess_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
				
			@DataProvider
			public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_CancellationProcess_xls, this.getClass().getSimpleName()) ;
			}
		}

		

