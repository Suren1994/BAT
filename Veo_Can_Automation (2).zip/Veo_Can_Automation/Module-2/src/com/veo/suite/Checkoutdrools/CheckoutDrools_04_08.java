package com.veo.suite.Checkoutdrools;

import java.awt.AWTException;
import java.io.IOException;
import org.openqa.selenium.By;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class CheckoutDrools_04_08 extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName())){
				prntResults("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName());
		}
	
		@Test(dataProvider="getTestData")
	public void OrderHistory_status_Order_Submitted_Desktop(
			String uname,
			String pwd,
			String title1,
			String orderbtn_text,
			String CreateOrder_Header,
			String Qty,
			String Order_Status
			) throws InterruptedException, IOException, AWTException,Exception, Throwable
{
				count++;
				
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		//Starting Point of the Testcase
		prntResults("***************************************************************************************");
		prntResults("Executing CheckoutDrools TC_04_08");
		prntResults("***************************************************************************************");
		prntResults("OrderHistory - View Order in status: Order_Submitted");
		prntResults("***************************************************************************************");
		prntResults("Username: "+uname +"& Password: "+pwd);
		sessionData.put("mobile_"+count, uname);
		
		
		//=================================== Opening the Browser ===================================//
			openBrowser();
			prntResults("Browserup"+this.getClass().getSimpleName());
		
			//Enter the URL 
			driver.get(CONFIG.getProperty("testSiteName"));
			prntResults("Entered the URL of the Application");
		
		try
		{
		
	//=================================== Login to Veo ===================================//
			
		if(!Login("CheckoutDrools_Veo_username","CheckoutDrools_Veo_pwd","CheckoutDrools_Veo_LoginCheckbox","CheckoutDrools_Veo_LoginSubmit",uname,pwd)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}
		
          //=================================== Verify Title exist ===================================//	
		if(!compareTitle(title1)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}
		
		//=================================== To Retrieve a text from Create Order Label===================================// 
			String LabelText = getObject("CheckoutDrools_Veo_CreateOrder").getText();
			prntResults("The label of the button present is: "+LabelText);
		
		//============== To click on Create Order Button ====//
		if(LabelText.equals(orderbtn_text))
		{
		Thread.sleep(2000);
		highlightElement("CheckoutDrools_Veo_CreateOrderbutton");
		getObject("CheckoutDrools_Veo_CreateOrderbutton").click();
		prntResults("Clicked Create Order Button");
		Thread.sleep(4000);
			
				//Validating Off-Route Order		
				offRoutePopup();
				Thread.sleep(4000);

				if(!checkText("CheckoutDrools_CartHeader",CreateOrder_Header))
				{
					// screenshot
					prntResults("Failed: Not Navigated to Cart Page");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit	
					return;
				 }		
				Thread.sleep(3000);

		}
		
  //=================================== To click on Order In Progress Button ===================================//
		else {
			highlightElement("CheckoutDrools_Veo_OrderInProgress");
			getObject("CheckoutDrools_Veo_OrderInProgress").click();
			prntResults("Clicked Order In Progress Button");
			Thread.sleep(2000);
			
			//Clicking on Cancel button 
			highlightElement("CheckoutDrools_Veo_CancelOrder");
			getObject("CheckoutDrools_Veo_CancelOrder").click();
			prntResults("Clicked on cancel order button");
			
			//Clicking on Cancel yes button 
			highlightElement("CheckoutDrools_Veo_CancelOrder_Yes");
			getObject("CheckoutDrools_Veo_CancelOrder_Yes").click();
			prntResults("Clicked on cancel order yes button");
			Thread.sleep(2000);

			//Click on Create Order Button
			highlightElement("CheckoutDrools_Veo_CreateOrderbutton");
			getObject("CheckoutDrools_Veo_CreateOrderbutton").click();
			prntResults("Highlighted Create order button");
			Thread.sleep(5000);
			
			offRoutePopup();
			Thread.sleep(2000);
			
			if(!checkText("CheckoutDrools_CartHeader",CreateOrder_Header))
			{
				// screenshot
				prntResults("Failed: Not Navigated to Cart Page");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit	
				return;
			 }		
			Thread.sleep(3000);
		}
		
		//click on Filter 
		getObject("CheckoutDrools_Veo_CartFilter").click();
		prntResults("Clicked on Cart Filter");
		Thread.sleep(3000);
		
		//Entering the Order Qty
		if(getObject("CheckoutDrools_Veo_quantity").isDisplayed()) {
			for(int i=0;i<=3;i++) {
				driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).clear();
				prntResults("Cleared the quantity for "+i+ " products");
				Thread.sleep(1000);

				driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).sendKeys(Qty);
				prntResults("Entered the quantity for "+i+ " products as: "+Qty);
				Thread.sleep(2000);

				}
				
				Thread.sleep(4000);
		}
		else{
			prntResults("Failed: could not find Oder Quanity Fields OR Not able to Enter Order Quantity");
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("Failed: could not find Oder Quanity Fields OR Not able to Enter Order Quantity");
		}
			
		Thread.sleep(4000);
		
		getObject("CheckoutDrools_Veo_continue").click();
		prntResults("Clicked on continue button");
		Thread.sleep(3000);
		
		ignoreAndContinue();
		Thread.sleep(3000);
		
		
			highlightElement("CheckoutDrools_Veo_PlaceOrder");
			getObject("CheckoutDrools_Veo_PlaceOrder").click();
			prntResults("Clicked on place order button");
			Thread.sleep(3000);
								
			highlightElement("CheckoutDrools_Veo_OrderNo_Value");
			String order_no =getObject("CheckoutDrools_Veo_OrderNo_Value").getText();
			System.out.println("The Order No is: "+order_no);
			prntResults("The Order No is: "+order_no);
			Thread.sleep(5000);
			
			//No of products Ordered
			
			if(driver.findElement(By.xpath("html/body/div[2]/div/div[2]/div[5]/div[2]/div/table/tbody/tr")).isDisplayed())
			{
				int rowcount = driver.findElements(By.xpath("html/body/div[2]/div/div[2]/div[5]/div[2]/div/table/tbody/tr")).size();
				System.out.println("The No.of.Products ordered are: "+rowcount);
				prntResults("The No.of.Products ordered are: "+rowcount);
				Thread.sleep(3000);
			}
			
			else{
				prntResults("Failed: Ordered Products are not found");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				throw new Exception("Failed: Ordered Products are not found");
			}
			
			
			System.out.println("Order submitted succesfully");
			prntResults("Order submitted succesfully");
			
			//Navigating to Order History Page
			getObject("CheckoutDrools_Veo_ManIkon").click();
			prntResults("Clicked on Man Ikon");
			Thread.sleep(3000);
			
			//Click on Order History 
			highlightElement("CheckoutDrools_Veo_OrderHistory");
			getObject("CheckoutDrools_Veo_OrderHistory").click();
			prntResults("Clicked on Order history");
			Thread.sleep(3000);
			
			//Validating the Order No 
			String OrderSumitNo = getObject("CheckoutDrools_Veo_OrderDetails").getText();
			prntResults("The submitted orderNo in Order details Page :"+OrderSumitNo);
			
			if(order_no.equals(OrderSumitNo))
			{
				highlightElement("CheckoutDrools_Veo_OrderDetails");
				
				//Date Values
				highlightElement("CheckoutDrools_Veo_OrderDetails_Date");
				String Date = getObject("CheckoutDrools_Veo_OrderDetails_Date").getText();
				prntResults("Date of the Submitted Order is : "+Date);
				Thread.sleep(3000);
				
				//Time Values
				highlightElement("CheckoutDrools_Veo_OrderDetails_Time");
				String Time = getObject("CheckoutDrools_Veo_OrderDetails_Time").getText();
				prntResults("Time of the Submitted Order is : "+Time);
				Thread.sleep(3000);
				
				//Status of the Submitted Order
				highlightElement("CheckoutDrools_Veo_OrderDetails_Status");
				String Status = getObject("CheckoutDrools_Veo_OrderDetails_Status").getText();
				prntResults("Status of the Submitted Order is : "+Status);
				Thread.sleep(3000);
				
				//Assert.assertTrue(Status.trim().equalsIgnoreCase(Order_Status));
				
				if(Status.equalsIgnoreCase(Order_Status))
				{
					prntResults("Success : Viewed Order in Order History Status as "+Order_Status);
					Thread.sleep(3000);
				}
				else
				{
					prntResults("FAILED: Viewed Order in Order History Status as "+Status+" but not as "+Order_Status);
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("FAILED: Viewed Order in Order History Status as "+Status+" but not as "+Order_Status);
				}
				
				highlightElement("CheckoutDrools_Veo_OrderDetails_Total");
				Thread.sleep(3000);

			}
			else
			{
				prntResults("Failed: The submitted Order.No did not match");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				throw new Exception();
			}
			prntResults("Test Completed & End of the Step");
			
					
	}
		catch (Exception e) 
		{
			ErrorUtil.addVerificationFailure(e);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			System.err.println("Failed");
			prntResults("Test Failed");
			throw e;
		} 
	

	}
			
			@AfterMethod
			public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
			
			}
			
			@AfterTest
			public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
				
			@DataProvider
			public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName()) ;
			}
		}

		

