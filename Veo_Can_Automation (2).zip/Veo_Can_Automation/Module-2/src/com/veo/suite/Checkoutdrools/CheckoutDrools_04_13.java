package com.veo.suite.Checkoutdrools;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class CheckoutDrools_04_13 extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName());
		}
	
		@Test(dataProvider="getTestData")
	public void Order_Cancelled_Desktop(
			String uname,
			String pwd,
			String title1,
			String orderbtn_text,
			String CreateOrder_Header,
			String Qty,
			String Order_Status,
			String UsernameBackoffice,
			String PasswordBackoffice,
			String OrderStatus_Dropdwon
			) throws InterruptedException, IOException, AWTException,Exception, Throwable
{
				count++;
				
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		//Starting Point of the Testcase
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing CheckoutDrools TC_04_13");
		Reporter.log("Executing CheckoutDrools TC_04_13");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Order History Summary - View Order in status: Order_Cancelled");
		Reporter.log("Order History Summary - View Order in status: Order_Cancelled");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname +"& Password: "+pwd);
		Reporter.log("Username: "+uname +"& Password: "+pwd);
		sessionData.put("mobile_"+count, uname);
		
		
		//=================================== Opening the Browser ===================================//
			openBrowser();
			APP_LOGS.debug("Browserup"+this.getClass().getSimpleName());
			Reporter.log("Browserup"+this.getClass().getSimpleName());
		
			//Enter the URL 
			driver.get(CONFIG.getProperty("testSiteName"));
			APP_LOGS.debug("Entered the URL of the Application");
			Reporter.log("Entered the URL of the Application");
		
		try
		{
		
	//=================================== Login to Veo ===================================//
			
		if(!Login("CheckoutDrools_Veo_username","CheckoutDrools_Veo_pwd","CheckoutDrools_Veo_LoginCheckbox","CheckoutDrools_Veo_LoginSubmit",uname,pwd)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}
		
          //=================================== Verify Title exist ===================================//	
		if(!compareTitle(title1)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}
		
		//=================================== To Retrieve a text from Create Order Label===================================// 
			String LabelText = getObject("CheckoutDrools_Veo_CreateOrder").getText();
			APP_LOGS.debug("The label of the button present is: "+LabelText);
			Reporter.log("The label of the button present is: "+LabelText);
			Thread.sleep(2000);
		
		//============== To click on Create Order Button ====//
		if(LabelText.equals(orderbtn_text))
		{
		Thread.sleep(2000);
		highlightElement("CheckoutDrools_Veo_CreateOrderbutton");
		getObject("CheckoutDrools_Veo_CreateOrderbutton").click();
		APP_LOGS.debug("Clicked Create Order Button");
		Reporter.log("Clicked Create Order Button");
		Thread.sleep(4000);
			
				//Validating Off-Route Order		
				offRoutePopup();
				Thread.sleep(4000);

				if(!checkText("CheckoutDrools_CartHeader",CreateOrder_Header))
				{
					// screenshot
					APP_LOGS.debug("Failed: Not Navigated to Cart Page");
					Reporter.log("Failed: Not Navigated to Cart Page");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit	
					return;
				 }		
				Thread.sleep(3000);

		}
		
  //=================================== To click on Order In Progress Button ===================================//
		else {
			highlightElement("CheckoutDrools_Veo_OrderInProgress");
			getObject("CheckoutDrools_Veo_OrderInProgress").click();
			APP_LOGS.debug("Clicked Order In Progress Button");
			Reporter.log("Clicked Order In Progress Button");
			Thread.sleep(2000);
			
			//Clicking on Cancel button 
			highlightElement("CheckoutDrools_Veo_CancelOrder");
			getObject("CheckoutDrools_Veo_CancelOrder").click();
			APP_LOGS.debug("Clicked on cancel order button");
			Reporter.log("Clicked on cancel order button");
			
			//Clicking on Cancel yes button 
			highlightElement("CheckoutDrools_Veo_CancelOrder_Yes");
			getObject("CheckoutDrools_Veo_CancelOrder_Yes").click();
			APP_LOGS.debug("Clicked on cancel order yes button");
			Reporter.log("Clicked on cancel order yes button");
			Thread.sleep(2000);

			//Click on Create Order Button
			highlightElement("CheckoutDrools_Veo_CreateOrderbutton");
			getObject("CheckoutDrools_Veo_CreateOrderbutton").click();
			APP_LOGS.debug("Highlighted Create order button");
			Reporter.log("Highlighted Create order button");
			Thread.sleep(5000);
			
			offRoutePopup();
			Thread.sleep(2000);
			
			if(!checkText("CheckoutDrools_CartHeader",CreateOrder_Header))
			{
				// screenshot
				APP_LOGS.debug("Failed: Not Navigated to Cart Page");
				Reporter.log("Failed: Not Navigated to Cart Page");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit	
				return;
			 }		
			Thread.sleep(3000);
		}
		
		//click on Filter 
		getObject("CheckoutDrools_Veo_CartFilter").click();
		APP_LOGS.debug("Clicked on Cart Filter");
		Reporter.log("Clicked on Cart Filter");
		Thread.sleep(3000);
		
		//Entering the Order Qty
		if(getObject("CheckoutDrools_Veo_quantity").isDisplayed()) {
			for(int i=0;i<=3;i++) {
				driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).clear();
				APP_LOGS.debug("Cleared the quantity for "+i+ " products");
				Reporter.log("Cleared the quantity for "+i+ " products");
				Thread.sleep(1000);

				driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).sendKeys(Qty);
				APP_LOGS.debug("Entered the quantity for "+i+ " products as: "+Qty);
				Reporter.log("Entered the quantity for "+i+ " products as: "+Qty);
				Thread.sleep(2000);

				}
				
				Thread.sleep(4000);
		}
		else{
			APP_LOGS.debug("Failed: could not find Oder Quanity Fields OR Not able to Enter Order Quantity");
			Reporter.log("Failed: could not find Oder Quanity Fields OR Not able to Enter Order Quantity");
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("Failed: could not find Oder Quanity Fields OR Not able to Enter Order Quantity");
		}
			
		Thread.sleep(4000);
		
		getObject("CheckoutDrools_Veo_continue").click();
		APP_LOGS.debug("Clicked on continue button");
		Reporter.log("Clicked on continue button");
		Thread.sleep(3000);
		
		ignoreAndContinue();
		Thread.sleep(3000);
		
		
			highlightElement("CheckoutDrools_Veo_PlaceOrder");
			getObject("CheckoutDrools_Veo_PlaceOrder").click();
			APP_LOGS.debug("Clicked on place order button");
			Reporter.log("Clicked on place order button");
			Thread.sleep(3000);
								
			highlightElement("CheckoutDrools_Veo_OrderNo_Value");
			String order_no =getObject("CheckoutDrools_Veo_OrderNo_Value").getText();
			System.out.println("The Order No is: "+order_no);
			APP_LOGS.debug("The Order No is: "+order_no);
			Reporter.log("The Order No is: "+order_no);
			Thread.sleep(5000);
			
			/*//Fetch the Value of the total amount
			//highlightElement("CheckoutDrools_Veo_TotalValue");
			//Thread.sleep(3000);

			String total_value =getObject("CheckoutDrools_Veo_TotalValue").getText();
			System.out.println("The total value is: "+total_value);
			APP_LOGS.debug("The total value is: "+total_value);
			Reporter.log("The total value is: "+total_value);
			Thread.sleep(3000);
			*/
			//No of products Ordered
			
			if(driver.findElement(By.xpath("html/body/div[2]/div/div[2]/div[5]/div[2]/div/table/tbody/tr")).isDisplayed())
			{
				int rowcount = driver.findElements(By.xpath("html/body/div[2]/div/div[2]/div[5]/div[2]/div/table/tbody/tr")).size();
				System.out.println("The No.of.Products ordered are: "+rowcount);
				APP_LOGS.debug("The No.of.Products ordered are: "+rowcount);
				Reporter.log("The No.of.Products ordered are: "+rowcount);
				Thread.sleep(3000);
			}
			
			else{
				APP_LOGS.debug("Failed: Ordered Products are not found");
				Reporter.log("Failed: Ordered Products are not found");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				throw new Exception("Failed: Ordered Products are not found");
			}
			
			
			System.out.println("Order submitted succesfully");
			APP_LOGS.debug("Order submitted succesfully");
			Reporter.log("Order submitted succesfully");
			
		/*	highlightElement("CheckoutDrools_Veo_ManIkon");
			getObject("CheckoutDrools_Veo_ManIkon").click();
			APP_LOGS.debug("Clicked on Man Ikon");
			Reporter.log("Clicked on Man Ikon");
			Thread.sleep(3000);
			
			highlightElement("CheckoutDrools_Veo_Logout");
			getObject("CheckoutDrools_Veo_Logout").click();
			APP_LOGS.debug("Clicked on Logout");
			Reporter.log("Clicked on Logout");
			Thread.sleep(3000);
			*/
		//============================== Backoffice Login ==========================// 
			
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL ,"t");
			APP_LOGS.debug("Opened a new tab");
			Reporter.log("Opened a new tab");
			
			driver.get(CONFIG.getProperty("backofficeurl"));
			APP_LOGS.debug("Entered Replenishment cockpit URL");
			Reporter.log("Entered Replenishment cockpit URL");
			
			//Login
			if(!LoginBackOffice("CheckoutDrools_BO_UserName","CheckoutDrools_BO_PassWord","CheckoutDrools_BO_Login",UsernameBackoffice,PasswordBackoffice)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}	
				
			Thread.sleep(3000);
			
			//Select the Flagged Order from the Order Status Dropdown 
			getObject("CheckoutDrools_BO_OrderStatus").click();
			APP_LOGS.debug("Clicked on Order Status");
			Reporter.log("Clicked on Order Status");
			getObject("CheckoutDrools_BO_OrderStatus").clear();
			getObject("CheckoutDrools_BO_OrderStatus").sendKeys(OrderStatus_Dropdwon);
			APP_LOGS.debug("Selected the Option "+OrderStatus_Dropdwon+" from the Order Status");
			Reporter.log("Selected the Option "+OrderStatus_Dropdwon+" from the Order Status");
			getObject("CheckoutDrools_BO_OrderStatus").click();
			APP_LOGS.debug("Clicked on Order Status");
			Reporter.log("Clicked on Order Status");
			Thread.sleep(3000);
			
			//Click on Refresh
			getObject("CheckoutDrools_BO_RefreshButton").click();
			APP_LOGS.debug("Clicked on Refresh button");
			Reporter.log("Clicked on Refresh button");
			Thread.sleep(3000);
			
		//=========================== To Click on the Submitted Order ==============================//
			
			int order_rowcount = driver.findElements(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[1]/div/div/div[2]/div[3]/div[3]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr")).size();
			APP_LOGS.debug("No.Of.Orders found in first page is : "+order_rowcount);
			Reporter.log("No.Of.Orders found in first page is : "+order_rowcount);
			Thread.sleep(3000);
			
			//To Select the Correct Order 
			for(int i=1;i<=order_rowcount;i++)
			{
				String orderno_txt = driver.findElement(By.xpath("//div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).getText();
				APP_LOGS.debug("Order.No in "+i+" row is: "+orderno_txt);
				Reporter.log("Order.No in "+i+" row is: "+orderno_txt);
				Thread.sleep(3000);
				
				if(order_no.equals(orderno_txt))
				{
					driver.findElement(By.xpath("//div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).click();
					APP_LOGS.debug("Clicked on the Order No "+orderno_txt);
					Reporter.log("Clicked on the Order No "+orderno_txt);
					Thread.sleep(3000);
					break;
				}
				else
				{
					if(i==order_rowcount)
					{
						APP_LOGS.debug("FAILED: The Submitted Order No not fount in first page of Backoffice");
						Reporter.log("FAILED: The Submitted Order No not fount in first page of Backoffice");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						throw new Exception("FAILED: The Submitted Order No not fount in first page of Backoffice");
					}
				}
			}
					
			//get the handle of parent window
			String handle1=driver.getWindowHandle(); 
			
			//get all the windows handle
			Set<String> handles1=driver.getWindowHandles();
			
			//loop through each handles
			for(String hmd1:handles1)
			{
				//check if the handles is not parent
				if(!hmd1.equals(handle1))
				{
					//Change the control into new window
					driver.switchTo().window(hmd1);
				}
			}
			System.out.println("Switched to new window: "+driver.getTitle());
			APP_LOGS.debug("Switched to new window: "+driver.getTitle());
			Reporter.log("Switched to new window: "+driver.getTitle());
			Thread.sleep(5000);
			
			//click on the Amend Button 
			highlightElement("CheckoutDrools_BO_Amend");
			getObject("CheckoutDrools_BO_Amend").click();
			APP_LOGS.debug("Clicked on Amend button");
			Reporter.log("Clicked on Amend button");
			Thread.sleep(4000);
			
			//Click on Cancel 
			getObject("CheckoutDrools_BO_Cancel").click();
			APP_LOGS.debug("Clicked on the Cancel order");
			Reporter.log("Clicked on the Cancel order");
			Thread.sleep(3000);
			
			//Click on Yes Button 
			getObject("CheckoutDrools_BO_CancelYes").click();
			APP_LOGS.debug("Clicked on the Cancel order->yes");
			Reporter.log("Clicked on the Cancel order->yes");
			Thread.sleep(5000);
			
			driver.switchTo().window(handle1);
			APP_LOGS.debug("Switched to Parent Window: "+driver.getTitle());
			Reporter.log("Switched to Parent Window: "+driver.getTitle());
			Thread.sleep(5000);

			
			/*//To Enter the Values in the Cart Page
			if(getObject("CheckoutDrools_Veo_quantity").isDisplayed())
			{
				for(int j=0;j<=2;j++)
				{
					driver.findElement(By.xpath(".//*[@id='quantity-"+j+"']")).clear();
					driver.findElement(By.xpath(".//*[@id='quantity-"+j+"']")).sendKeys(Qty_New);
					APP_LOGS.debug("Entered the Quantity for Product "+j+" as: "+Qty_New);
					Reporter.log("Entered the Quantity for Product "+j+" as: "+Qty_New);
					Thread.sleep(3000);
				}
			}
			else
			{
				APP_LOGS.debug("FAILED: No Products found for the Selected Order");
				Reporter.log("FAILED: No Products found for the Selected Order");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				throw new Exception("FAILED: No Products found for the Selected Order");
			}
			
			//Click on Continue Button
			getObject("CheckoutDrools_Veo_continue").click();
			APP_LOGS.debug("Clicked on Continue Button");
			Reporter.log("Clicked on Continue Button");
			Thread.sleep(3000);
			
			//To Click on Ignore and Continu Buuton if Appears 
			ignoreAndContinue();
			Thread.sleep(3000);
			
			//Click on Place Order Button 
			getObject("CheckoutDrools_Veo_PlaceOrder").click();
			APP_LOGS.debug("Clicked on Place Order Button");
			Reporter.log("Clicked on Place Order Button");
			Thread.sleep(3000);
			*/
			//Switching to Main Window
			driver.switchTo().window(handle1);	
			APP_LOGS.debug("Switched back to Parent window");
			Reporter.log("Switched back to Parent window");
			Thread.sleep(5000);	
			
			/*driver.close();
			APP_LOGS.debug("Closed Order Confirmation Page");
			Reporter.log("Closed Order Confirmation Page");
			Thread.sleep(3000);
*/
			//=============== Switch to StoreFront ==================// 
			switchToTab();
			APP_LOGS.debug("Switched back to StoreFront");
			Reporter.log("Switched back to StoreFront");
			Thread.sleep(3000);
			
			highlightElement("CheckoutDrools_Veo_ManIkon");
			getObject("CheckoutDrools_Veo_ManIkon").click();
			APP_LOGS.debug("Clicked on Man Ikon");
			Reporter.log("Clicked on Man Ikon");
			Thread.sleep(3000);
			
			highlightElement("CheckoutDrools_Veo_Logout");
			getObject("CheckoutDrools_Veo_Logout").click();
			APP_LOGS.debug("Clicked on Logout");
			Reporter.log("Clicked on Logout");
			Thread.sleep(3000);
			
			/*driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL ,"t");
			APP_LOGS.debug("Opened a new tab");
			Reporter.log("Opened a new tab");
			
			//Enter the URL 
			driver.get(CONFIG.getProperty("testSiteName"));
			APP_LOGS.debug("Entered the URL of the Application");
			Reporter.log("Entered the URL of the Application"); */
		
			//=================================== Login to Veo ===================================//
			
			if(!Login("CheckoutDrools_Veo_username","CheckoutDrools_Veo_pwd","CheckoutDrools_Veo_LoginCheckbox","CheckoutDrools_Veo_LoginSubmit",uname,pwd))
			{
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
		
			Thread.sleep(3000);
			
			//Click on Man Ikon
			getObject("CheckoutDrools_Veo_ManIkon").click();
			APP_LOGS.debug("Clicked on Man Ikon");
			Reporter.log("Clicked on Man Ikon");
			Thread.sleep(3000);
			
			//Clicked on Order History 
			getObject("CheckoutDrools_Veo_OrderHistory").click();
			APP_LOGS.debug("Clicked on Order History");
			Reporter.log("Clicked on Order History");
			Thread.sleep(3000);
			
			//To get the Order History Row Count 
			int orderhistory_rowcount = driver.findElements(By.xpath(".//*[@id='history-table']/tbody/tr")).size();
			APP_LOGS.debug("No.of.OrderHistoy Count is : "+orderhistory_rowcount);
			Reporter.log("No.of.OrderHistoy Count is : "+orderhistory_rowcount);
			Thread.sleep(3000);
			
			for(int i=1;i<=orderhistory_rowcount;i++)
			{
				//Validating the Order No 
				String OrderSumitNo = driver.findElement(By.xpath(".//*[@id='history-table']/tbody/tr["+i+"]/td[1]/div/a")).getText();
				APP_LOGS.debug("The submitted orderNo in Order details Page :"+OrderSumitNo);
				Reporter.log("The submitted orderNo in Order details Page :"+OrderSumitNo);
				
				if(order_no.equals(OrderSumitNo))
				{
					highlightElement("CheckoutDrools_Veo_OrderDetails");
					
					//Status of the Submitted Order
					String Status=driver.findElement(By.xpath(".//*[@id='history-table']/tbody/tr["+i+"]/td[4]/strong")).getText();
					APP_LOGS.debug("Status of the Submitted Order is : "+Status);
					Reporter.log("Status of the Submitted Order is : "+Status);
					Thread.sleep(3000);
					
					//Assert.assertTrue(Status.trim().equalsIgnoreCase(Order_Status));
					
					if(Status.equalsIgnoreCase(Order_Status))
					{
						APP_LOGS.debug("Success : Viewed Order in Order History Status as "+Order_Status);
						Reporter.log("Success : Viewed Order in Order History Status as "+Order_Status);
						Thread.sleep(3000);
						//break;
					}
					else
					{
						APP_LOGS.debug("FAILED: Viewed Order in Order History Status as "+Status+" but not as "+Order_Status);
						Reporter.log("FAILED: Viewed Order in Order History Status as "+Status+" but not as "+Order_Status);
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						throw new Exception("FAILED: Viewed Order in Order History Status as "+Status+" but not as "+Order_Status);
					}
					
						JavascriptExecutor js = (JavascriptExecutor)driver;
						WebElement element = driver.findElement(By.xpath(".//*[@id='history-table']/tbody/tr["+i+"]/td[3]/span"));    
		                     for (int k = 0; k < 1; k++) 
		                     {
		                           js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
		                           element, "color: red; border: 5px solid red;");	                           
		                           Thread.sleep(2000);
		                           js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
		                           element, "");
		                           Thread.sleep(2000);
		                       	APP_LOGS.debug("Highlighted the Order Cancelled by BAT");
		     					Reporter.log("Highlighted the Order Cancelled by BAT");
		     					 Thread.sleep(3000);
		                     }	
					
					break;
				}
				else
				{
					if(i==orderhistory_rowcount)
					{
					APP_LOGS.debug("Failed: The submitted Order.No did not match");
					Reporter.log("Failed: The submitted Order.No did not match");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("Failed: The submitted Order.No did not match");
					}
				}

			}
			
					
	}
		catch (Exception e) 
		{
			ErrorUtil.addVerificationFailure(e);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			System.err.println("Failed");
			APP_LOGS.debug("Test Failed");
			Reporter.log("Test Failed");
			throw e;
		} 
	

	}
			
			@AfterMethod
			public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
			
			}
			
			@AfterTest
			public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
				
			@DataProvider
			public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName()) ;
			}
		}

		

