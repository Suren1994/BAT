package com.veo.suite.Checkoutdrools;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.TestUtil;

public class Checkout_Drool_4_01 extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName())){
				prntResults("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName());
		}
	//===Drools_Suite_xls
		@Test(dataProvider="getTestData")
	public void Checkout_Drool_01(
			String uname,
			String pwd,
			String RuleName_toSearch,
			String MessageSize,
			String OutcomeSize,
			String RuleMessage,
			String Outcome,
			String UsernameStoreFront,
			String PasswordStoreFront,
			String DroolMessage_inCart
			) throws Throwable,Exception{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		prntResults("==================================================================");
		prntResults("Customer is warned about a Low Order Quantity for every product where order quanitity product  is < 90% of the SOQ ");
		prntResults("***************************************************************************************");
		prntResults("Username: "+uname+" & Password:"+pwd);
		//sessionData.put("mobile_"+count, uname);

		// webdriver
		openBrowser();
		
		driver.get(CONFIG.getProperty("BRMS"));
		driver.navigate().refresh();
				
		try
		{
//============================Login to Go Smart Application=================================//
			
				if(!LoginCheckout_Drools("CheckoutDrools_UserName","CheckoutDrools_Password","CheckoutDrools_Login_Ok_Button",uname,pwd))
				{
				// screenshot
				prntResults("Login Failed for Checkout Drools");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			          }
			
//===============================To Click on Knowledge Bases Package==================================//
			
				Thread.sleep(7000);
			//	highlightElement("Drools_KnowledgeBase");
				getObject("Drools_KnowledgeBase").click();
				prntResults("Clicked On BRMS Knowledge Base Package");
				//=======To Expand Packages Plus Sign==========//
				
				Thread.sleep(3000);
				//highlightElement("Drools_Package_PlusSign");
				getObject("Drools_Package_PlusSign").click();
				prntResults("Expanded Packages Plus Sign");
				
				//=======To Select VEO Aus Package==========//
				
				Thread.sleep(2000);
			    highlightElement("Drools_Package_veo_can");
		 		getObject("Drools_Package_veo_can").click();
				prntResults("Selected VEO Can Package");
				
				//=======To Expand Business Rule Assets Plus Sign==========//
				Thread.sleep(2000);
				getObject("Drools_BusinessRuleAssets_PlusSign").click();
				prntResults("Expanded Business Rule Assets Plus Sign");
			
					//=======To Click on Find Tab==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Tab");
					getObject("Drools_Find_Tab").click();
					prntResults("Clicked On Find Tab");
					
					//=======To Give Search Name==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Name_Matching");
					getObject("Drools_Find_Name_Matching").clear();
					getObject("Drools_Find_Name_Matching").sendKeys(RuleName_toSearch);
					Thread.sleep(2000);
					getObject("Drools_Find_Name_Matching").sendKeys(Keys.TAB);
					prntResults("Searching Name is: "+RuleName_toSearch);
					
					//=======To Click on Search Button==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Searchbtn");
					getObject("Drools_Find_Searchbtn").click();
					prntResults("Clicked On Search Button");
					
					Thread.sleep(2000);
					highlightElement("Drools_Openbutton");
					getObject("Drools_Openbutton").click();
					prntResults("Clicked On Drools_Openbutton ");
										
					String rule = driver.findElement(By.xpath("//input[@class='gwt-TextBox' and @size='"+MessageSize+"']")).getAttribute("value");
					prntResults("Rule name is" + rule);	
					
					String OUTCOME = driver.findElement(By.xpath("//input[@class='gwt-TextBox' and @size='"+OutcomeSize+"']")).getAttribute("value");
					prntResults("outcome is" + OUTCOME);	
					
				   /* Assert.assertEquals(rule,RuleMessage);
				    
				    Assert.assertEquals(OUTCOME,Outcome);	*/		    
					
					if(!checkAttributevalue("CheckoutDrools_LowOrderQtyLine_RuleMessage", RuleMessage))
					{
						// screenshot
						//hightlightscreenshot("MyDocHeader");
						prntResults("Failed: Rule Message is incorrect");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						 //quit
						return;
					}
				    
					if(!checkAttributevalue("CheckoutDrools_LowOrderQtyLine_OutCome", Outcome)){
						// screenshot
						//hightlightscreenshot("MyDocHeader");
						prntResults("Failed: Outcome is incorrect");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						 //quit
						return;
					}
					
				    driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");		
				    prntResults("Opened a new tab");
			       //switchToTab();
				    
					driver.get(CONFIG.getProperty("testSiteName"));			        
					prntResults("Entered the URL of Storefront Application");
//=================================== Login to Veo ===================================//
			         
					if(!Login("StoreFront_LoginPage_Username","StoreFront_LoginPage_Password",
							"StoreFront_LoginPage_AgeCheckbox","StoreFront_LoginPage_LoginButton",
							UsernameStoreFront,PasswordStoreFront)){
						// screenshot
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						// quit
						return;
					}
				
				//=================================== To Retrieve a text from Create Order Label===================================// 
					String LabelText = getObject("CreateOrder_InProgressButton").getText();
					prntResults("The label of the button present is: "+LabelText);
					Thread.sleep(2000);
				
				//=================================== To Click on Create Order Button =======================================//
				
					if(LabelText.equals("Create order"))
				{
				Thread.sleep(2000);
				highlightElement("CreateOrderbutton");
				getObject("CreateOrderbutton").click();
				prntResults("Clicked Create Order Button");
				Thread.sleep(3000);
					
						//Validating Off-Route Order		
						offRoutePopup();
				}
				
			//=================================== To click on Order In Progress Button ===================================//
				else 
				{
					Thread.sleep(2000);
					highlightElement("CreateOrder_InProgressButton");
					getObject("CreateOrder_InProgressButton").click();
					prntResults("Clicked on Order In Progress Button");
					Thread.sleep(2000);		
				}			
					
						getObject("Cart_FilterSearch").click();
						prntResults("Clicked on Filter_Searchbox");
		          	
						WaitForObjectAvailability("Cart_quantity");
						getObject("Cart_quantity").clear();
						Thread.sleep(2000);
						getObject("Cart_quantity").sendKeys("1");
						prntResults("Entered the Quantity");
						Thread.sleep(4000);
						
						getObject("Createorder_continue").click();
						prntResults("Clicked on Continue");
						
						WaitForObjectAvailability("Changeorder");
						getObject("Changeorder").click();
						prntResults("change order");
					
						
						WaitForObjectAvailability("CheckoutDrools_DroolMessage");
						if(!checkText("CheckoutDrools_DroolMessage",DroolMessage_inCart))
						{
							// screenshot
							prntResults("Validation Failed for Drools Warning Message");
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							fail=true;
							 //quit
							return;
						}
						
						//Logout
						getObject("CheckoutDrools_Veo_ManIkon").click();
						prntResults("Clicked on ManIkon");

						getObject("CheckoutDrools_Veo_Logout").click();
						prntResults("Clicked on Logout");
						
						System.out.println("Test Completed");
						prntResults("Test Completed & End of the Step");
								
					//html/body/div[4]/div[2]/div/div[3]/div/div[4]/div/div[3]/div/div[3]/div/div[4]/div/div/table/tbody/tr[3]/td/table/tbody/tr[2]/td/div/div[2]/div/div/div/table/tbody/tr/td/table/tbody/tr[3]/td[2]/table/tbody/tr[1]/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr/td[2]/input
				
 //===============Close the Test Case=====================//
					
		prntResults("Test Case Completed and End of the step");
		}
		catch (Exception e) 
		{
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			prntResults("Failed");
			throw e;
		} 
		}
		
		@AfterMethod
		public void reportDataSetResult(){
		if(skip)
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "SKIP");
		else if(fail){
			isTestPass=false;
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
		else
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
				
			}
			
		@AfterTest
		public void reportTestResult(){
		if(isTestPass)
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
			}			
						
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName()) ;
		}
		}

		

