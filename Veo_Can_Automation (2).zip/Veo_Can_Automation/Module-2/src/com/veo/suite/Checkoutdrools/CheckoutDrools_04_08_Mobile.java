package com.veo.suite.Checkoutdrools;


import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.TestUtil;


public class CheckoutDrools_04_08_Mobile extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName());
		}
	
	
	@Test(dataProvider="getTestData")
	public void OrderHistory_status_Order_Submitted_Mobile(
			String UsernameStoreFront,
			String PasswordStoreFront,
			String title1,
			String orderbtn_text,
			String CreateOrder_Header,
			String Order_Status
			) throws Throwable{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		prntResults("***************************************************************************************");
		prntResults("Executing CheckoutDrools TC_04_08_Mobile");
		prntResults("***************************************************************************************");
		prntResults("Mobile - OrderHistory - View Order in status: Order_Submitted");
		prntResults("***************************************************************************************");
		prntResults("Username: "+UsernameStoreFront +"& Password: "+PasswordStoreFront);
		sessionData.put("mobile_"+count, UsernameStoreFront);
		
		
		// LOGIN_BROWSER
		
		Firefoxprofile();
		prntResults("Browserup"+this.getClass().getSimpleName());
		
		driver.get(CONFIG.getProperty("testSiteName"));
		prntResults("Entered the URL of the Application");

		try
		{
		if(!Login2("Mobile_CheckoutDrools_Veo_Username","Mobile_CheckoutDrools_Veo_Password","Login_checkbox2","Login_submit",UsernameStoreFront,PasswordStoreFront)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}

   
		// CLICK_ON_MODULE
		FirstCloseButton();
		
		if(WaitForObjectAvailability("Mobile_createorder"))
		{
		getObject("Mobile_createorder").click();
		prntResults("clicked on Mobile_createorder");
		//Thread.sleep(4000);
		}
		
	//	SecondCloseButton();
		
		offRoutePopup();  
		Thread.sleep(3000);
		
		FirstCloseButton();

		if(WaitForObjectAvailability("Mobile_CancelOrder"))
		{
		getObject("Mobile_CancelOrder").click();
		prntResults("Clicked on CancelOrder");
		//Thread.sleep(3000);
		}

		if(WaitForObjectAvailability("Mobile_CancelOrder_yes"))
		{
		getObject("Mobile_CancelOrder_yes").click();
		prntResults("clicked on Yes button");
		//Thread.sleep(3000);
		}
		
		FirstCloseButton();
		Thread.sleep(3000);

		if(WaitForObjectAvailability("Mobile_createorder"))
		{
		getObject("Mobile_createorder").click();
		prntResults("clicked on Mobile_createorder");
		Thread.sleep(3000);
		}

		offRoutePopup();
		Thread.sleep(3000);

		SecondCloseButton();
		Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_quantity");
		
		getObject("Mobile_quantity").click();
		prntResults("clicked on Mobile_quantity");
		//Thread.sleep(4000);
		WaitForObjectAvailability("Mobile_CreateOrder_CartonsQuantity");
		
		getObject("Mobile_CreateOrder_CartonsQuantity").click(); 
		prntResults("Clicked on Mobile Cartons Quantity");
		//Thread.sleep(3000); 
		WaitForObjectAvailability("Mobile_Cart_quantity");
		
		
		getObject("Mobile_Cart_Keyboard_Two").click();
		prntResults("clicked on value 2");
		Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");


		getObject("Mobile_Cart_Keyboard_Next").click();
		prntResults("clicked on next");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Next");
		
		getObject("Mobile_Cart_Keyboard_Next").click();
		prntResults("clicked on next");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");
				
		getObject("Mobile_Cart_Keyboard_Two").click();
		prntResults("clicked on value 2");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");

		getObject("Mobile_Cart_Keyboard_Two").click();
		prntResults("clicked on value 2");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Three");
		
		getObject("Mobile_Cart_Keyboard_Three").click();
		prntResults("clicked on value 3");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Done");
		
		getObject("Mobile_Cart_Keyboard_Done").click();
		prntResults("clicked on Done button");
		//Thread.sleep(4000);
		WaitForObjectAvailability("Mobile_Cart_Continue");
		
		getObject("Mobile_Cart_Continue").click();
		prntResults("clicked on continue button");
		WaitForObjectAvailability("Ign_n_Con_createOrder_mobile");
		
		ignoreAndContinue_mobile();
		prntResults("clicked on Ign_n_Con_createOrder");
		//Thread.sleep(4000);
		WaitForObjectAvailability("Mobile_Cart_placeOrder");

		getObject("Mobile_Cart_placeOrder").click();
		prntResults("clicked on Mobile_Cart_placeOrder");
		//Thread.sleep(4000);
		WaitForObjectAvailability("Mobile_Cart_ORDER_Order_Submitted");

		checkText("Mobile_Cart_ORDER_Order_Submitted","Order Submitted");

		//To get the Order No 
		highlightElement("Mobile_CheckoutDrools_Veo_OrderDetails_OrderNo");
		String Order_Number = getObject("Mobile_CheckoutDrools_Veo_OrderDetails_OrderNo").getText();
		prntResults("Order No is : "+Order_Number);
		
		
		//Click on Veo Image 
		getObject("GoSmartimage").click();
		prntResults("clicked on GoSmartimage");
		Thread.sleep(2000);
		FirstCloseButton();
		
		//Click on Order History in Home Page 
		getObject("Mobile_CheckoutDrools_Veo_OrderHistory").click();
		prntResults("Clicked on Order History");
		
		//No.Of.Products in Order Hitory Page 
		int OrdersCount = driver.findElements(By.xpath(".//*[@id='page-content']/div[2]/div/div")).size();
		prntResults("No.Of.Orders found in Order History page is : "+OrdersCount);
		
		for(int i=1;i<=OrdersCount;i++)
		{
			String OrderHistory_OrderNo = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/h3/span[1]")).getText();
			prntResults("Order no in "+i+" row is : "+OrderHistory_OrderNo);
			
			if(Order_Number.equals(OrderHistory_OrderNo))
			{
				//Order Status
				String CurrentStatus = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/h3/span[2]")).getText();
				prntResults("Current Status of the Order is : "+CurrentStatus);
				
				if(CurrentStatus.equalsIgnoreCase(Order_Status))
				{
					prntResults("Success: Verified that Order is in Submitted Status");
				}
				else
				{
					prntResults("Verification Failed: Order status is not Submitted but as : "+CurrentStatus);
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("Verification Failed: Order status is not Submitted but as : "+CurrentStatus);
				}
				
				//Order date Stamp 
				String DateStamp = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/dl["+i+"]/dd")).getText();
				prntResults("Date Stamp is : "+DateStamp);
				
	//=========================== Order Total Values (Net,Discount,$$ Values) ========================//
	 			 int TotalValue_List = driver.findElements(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/dl")).size();
	 			 
	 			 if(!(TotalValue_List == 0))
	 			 {
	 				for(int j=1;j<=TotalValue_List;j++)
	 				{
	 					String ListHeader = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/dl["+j+"]/dt")).getText();
	 					String ListValue = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/dl["+j+"]/dd")).getText();
	 					APP_LOGS.debug(ListHeader+" is : "+ListValue);
	 		      		Reporter.log(ListHeader+" is : "+ListValue);
	 		 			Thread.sleep(3000);
	 				}
	 			 }
	 			 break;
			}
			else
			{
				if(i==OrdersCount)
				{
					prntResults("Failed: Placed Order No is not found in Order History Page");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("Failed: Placed Order No is not found in Order History Page");
				}
			}
		}
		
	
		}
		catch(Exception e)
		{
		System.err.println("Failed");
		prntResults("Failedddd");
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		throw e;
		}
		finally
		{
		getObject("GoSmartimage").click();
		prntResults("clicked on GoSmartimage");
		Thread.sleep(2000);
		FirstCloseButton();

		highlightElement("Mobile_Logout");
		getObject("Mobile_Logout").click();
		prntResults("Clicked on MobileLogout button");

		System.out.println("Test Completed");
		prntResults("Test Completed");
		} 
		}
		@AfterMethod
		public void reportDataSetResult(){
		if(skip)
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "SKIP");
		else if(fail){
		isTestPass=false;
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "FAIL");
		}
		else
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "PASS");
		skip=false;
		fail=false; 

		}
		@AfterTest
		public void reportTestResult(){
		if(isTestPass)
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "PASS");
		else
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "FAIL");
		closeBrowser();
		}
		@DataProvider
		public Object[][] getTestData(){
		return TestUtil.getData(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName()) ;
		}
		}

