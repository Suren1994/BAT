package com.veo.suite.Checkoutdrools;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class CheckoutDrools_04_16 extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName());
		}
	
		@Test(dataProvider="getTestData")
	public void OrderDetails_status_Order_Submitted_Desktop(
			String uname,
			String pwd,
			String title1,
			String orderbtn_text,
			String CreateOrder_Header,
			String Qty,
			String Qty1
			) throws InterruptedException, IOException, AWTException,Exception, Throwable
{
				count++;
				
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		//Starting Point of the Testcase
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing CheckoutDrools TC_04_16");
		Reporter.log("Executing CheckoutDrools TC_04_16");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("OrderHistory - View Order in status: Order_Submitted");
		Reporter.log("OrderHistory - View Order in status: Order_Submitted");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname +"& Password: "+pwd);
		Reporter.log("Username: "+uname +"& Password: "+pwd);
		sessionData.put("mobile_"+count, uname);
		
		
		//=================================== Opening the Browser ===================================//
			openBrowser();
			APP_LOGS.debug("Browserup"+this.getClass().getSimpleName());
			Reporter.log("Browserup"+this.getClass().getSimpleName());
		
			//Enter the URL 
			driver.get(CONFIG.getProperty("testSiteName"));
			APP_LOGS.debug("Entered the URL of the Application");
			Reporter.log("Entered the URL of the Application");
		
		try
		{
		
	//=================================== Login to Veo ===================================//
			
		if(!Login("CheckoutDrools_Veo_username","CheckoutDrools_Veo_pwd","CheckoutDrools_Veo_LoginCheckbox","CheckoutDrools_Veo_LoginSubmit",uname,pwd)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}
		
		
          //=================================== Verify Title exist ===================================//	
		if(!compareTitle(title1)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}
		
		//=================================== To Retrieve a text from Create Order Label===================================// 
			String LabelText = getObject("CheckoutDrools_Veo_CreateOrder").getText();
			APP_LOGS.debug("The label of the button present is: "+LabelText);
			Reporter.log("The label of the button present is: "+LabelText);
			Thread.sleep(2000);
		
		//============== To click on Create Order Button ====//
		if(LabelText.equals(orderbtn_text))
		{
		Thread.sleep(2000);
		highlightElement("CheckoutDrools_Veo_CreateOrderbutton");
		getObject("CheckoutDrools_Veo_CreateOrderbutton").click();
		APP_LOGS.debug("Clicked Create Order Button");
		Reporter.log("Clicked Create Order Button");
		Thread.sleep(4000);
			
				//Validating Off-Route Order		
				offRoutePopup();
				Thread.sleep(4000);

				if(!checkText("CheckoutDrools_CartHeader",CreateOrder_Header))
				{
					// screenshot
					APP_LOGS.debug("Failed: Not Navigated to Cart Page");
					Reporter.log("Failed: Not Navigated to Cart Page");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit	
					return;
				 }		
				Thread.sleep(3000);
		}
		
  //=================================== To click on Order In Progress Button ===================================//
		else {
			highlightElement("CheckoutDrools_Veo_OrderInProgress");
			getObject("CheckoutDrools_Veo_OrderInProgress").click();
			APP_LOGS.debug("Clicked Order In Progress Button");
			Reporter.log("Clicked Order In Progress Button");
			Thread.sleep(2000);
			
			//Clicking on Cancel button 
			highlightElement("CheckoutDrools_Veo_CancelOrder");
			getObject("CheckoutDrools_Veo_CancelOrder").click();
			APP_LOGS.debug("Clicked on cancel order button");
			Reporter.log("Clicked on cancel order button");
			Thread.sleep(2000);

			//Clicking on Cancel yes button 
			highlightElement("CheckoutDrools_Veo_CancelOrder_Yes");
			getObject("CheckoutDrools_Veo_CancelOrder_Yes").click();
			APP_LOGS.debug("Clicked on cancel order yes button");
			Reporter.log("Clicked on cancel order yes button");
			Thread.sleep(2000);

			//Click on Create Order Button
			highlightElement("CheckoutDrools_Veo_CreateOrderbutton");
			getObject("CheckoutDrools_Veo_CreateOrderbutton").click();
			APP_LOGS.debug("Highlighted Create order button");
			Reporter.log("Highlighted Create order button");
			Thread.sleep(5000);
			
			offRoutePopup();
			Thread.sleep(4000);

			if(!checkText("CheckoutDrools_CartHeader",CreateOrder_Header))
			{
				// screenshot
				APP_LOGS.debug("Failed: Not Navigated to Cart Page");
				Reporter.log("Failed: Not Navigated to Cart Page");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit	
				return;
			 }		
			Thread.sleep(3000);		}
		
		
		getObject("CheckoutDrools_Veo_CartFilter").click();
		APP_LOGS.debug("Clicked on Cart Filter");
		Reporter.log("Clicked on Cart Filter");
		Thread.sleep(3000);
		
		//Entering the Order Qty
		if(getObject("CheckoutDrools_Veo_quantity").isDisplayed()) {
			for(int i=0;i<3;i++) {
				driver.findElement(By.xpath(".//*[@id='on-hand-inv-carton-"+i+"']")).clear();
				APP_LOGS.debug("Cleared On Hand Inventory Carton for "+i+" Product");
				Reporter.log("Cleared On Hand Inventory Carton for "+i+" Product");
				
				driver.findElement(By.xpath(".//*[@id='on-hand-inv-carton-"+i+"']")).sendKeys(Qty1);
				APP_LOGS.debug("Entered On Hand Inventory Carton for "+i+" Product as: "+Qty1);
				Reporter.log("Entered On Hand Inventory Carton for "+i+" Product as: "+Qty1);
				
				driver.findElement(By.xpath(".//*[@id='on-hand-inv-pack-"+i+"']")).clear();
				APP_LOGS.debug("Cleared On Hand Inventory Pack for "+i+" Product");
				Reporter.log("Cleared On Hand Inventory Pack for "+i+" Product");
				
				driver.findElement(By.xpath(".//*[@id='on-hand-inv-pack-"+i+"']")).sendKeys(Qty1);
				APP_LOGS.debug("Entered On Hand Inventory pack for "+i+" Product as: "+Qty1);
				Reporter.log("Entered On Hand Inventory pack for "+i+" Product as: "+Qty1);
				
				driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).clear();
				APP_LOGS.debug("Cleared Order Quantity for "+i+" Product");
				Reporter.log("Cleared Order Quantity for "+i+" Product");
				
				driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).sendKeys(Qty);
				APP_LOGS.debug("Entered Order Quantity for "+i+" Product as: "+Qty);
				Reporter.log("Entered Order Quantity for "+i+" Product as: "+Qty);
				}
				APP_LOGS.debug("Entered the quantity for several products");
				Reporter.log("Entered the quantity for several products");
				Thread.sleep(2000);
		}
		else{
			APP_LOGS.debug("Failed: Cannot find Oder Quanity Fields/Not able to Enter Order Quantity");
			Reporter.log("Failed: Cannot find Oder Quanity Fields/Not able to Enter Order Quantity");
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("Failed: Cannot find Oder Quanity Fields/Not able to Enter Order Quantity");
		}
		
		
		getObject("CheckoutDrools_Veo_continue").click();
		APP_LOGS.debug("Clicked on continue button");
		Reporter.log("Clicked on continue button");
		Thread.sleep(3000);
		
			ignoreAndContinue();
			Thread.sleep(3000);

			highlightElement("CheckoutDrools_Veo_PlaceOrder");
			getObject("CheckoutDrools_Veo_PlaceOrder").click();
			APP_LOGS.debug("Clicked on place order button");
			Reporter.log("Clicked on place order button");
			Thread.sleep(5000);
	
								
			highlightElement("CheckoutDrools_Veo_OrderNo_Value");
			Thread.sleep(3000);

			String order_no =getObject("CheckoutDrools_Veo_OrderNo_Value").getText();
			System.out.println("The Order No is: "+order_no);
			APP_LOGS.debug("The Order No is: "+order_no);
			Reporter.log("The Order No is: "+order_no);
			Thread.sleep(3000);
			
			
			System.out.println("Order submitted succesfully");
			APP_LOGS.debug("Order submitted succesfully");
			Reporter.log("Order submitted succesfully");
			
			
			//Navigating to Order History Page
			getObject("CheckoutDrools_Veo_ManIkon").click();
			APP_LOGS.debug("Clicked on Man Ikon");
			Reporter.log("Clicked on Man Ikon");
			Thread.sleep(3000);
			
			//Click on Order History 
			highlightElement("CheckoutDrools_Veo_OrderHistory");
			getObject("CheckoutDrools_Veo_OrderHistory").click();
			APP_LOGS.debug("Clicked on Order history");
			Reporter.log("Clicked on Order history");
			Thread.sleep(3000);
			
			//Validating the Order No 
			//Get total row count 
			int orderhistory_rowcount = driver.findElements(By.xpath(".//*[@id='history-table']/tbody/tr")).size();
			APP_LOGS.debug("The No.of.rows Present in Order History Page is: "+orderhistory_rowcount);
			Reporter.log("The No.of.rows Present in Order History Page is: "+orderhistory_rowcount);
			Thread.sleep(2000);

			if(!(orderhistory_rowcount == 0))
			{
			for(int i=1;i<=orderhistory_rowcount;i++)
			{
			String OrderSubmitNo = driver.findElement(By.xpath(".//*[@id='history-table']/tbody/tr["+i+"]/td[1]/div/a")).getText();
			APP_LOGS.debug("The submitted orderNo in Order details Page :"+OrderSubmitNo);
			Reporter.log("The submitted orderNo in Order details Page :"+OrderSubmitNo);
			
			if(order_no.equals(OrderSubmitNo))
			{
				/*highlightElement("CheckoutDrools_Veo_OrderDetails");
				highlightElement("CheckoutDrools_Veo_OrderDetails_Date");
				highlightElement("CheckoutDrools_Veo_OrderDetails_Status");
				highlightElement("CheckoutDrools_Veo_OrderDetails_Total");
				highlightElement("CheckoutDrools_Veo_OrderDetails_review");*/
				
				
				//Highlight Order Number
				 JavascriptExecutor js = (JavascriptExecutor)driver;
	             WebElement element = driver.findElement(By.xpath(".//*[@id='history-table']/tbody/tr["+i+"]/td[1]/div/a"));    
	      		 js.executeScript("arguments[0].style.border='5px solid red'", element);
	      		 APP_LOGS.debug("Highlighted respective Order Number element");
	      		 Reporter.log("Highlighted respective Order Number element");
	      		 Thread.sleep(3000);
	      		 
	      		 //Click on the Order Number 
	      		 driver.findElement(By.xpath(".//*[@id='history-table']/tbody/tr["+i+"]/td[1]/div/a")).click();
	      		 APP_LOGS.debug("Clicked on Order No and Navigated to Order Detail Page");
	      		 Reporter.log("Clicked on Order No and Navigated to Order Detail Page");
	      		 Thread.sleep(3000);
	      		 
	      		 //Highlight Status
	      		 highlightElement("CheckoutDrools_Veo_OrderNo_Value");
	      		 APP_LOGS.debug("Highlighted Order Number");
	      		 Reporter.log("Highlighted Order Number");
	 			 Thread.sleep(3000);
	      		 
	      		 //To Highlight and get the Order Submitted Date Stamp 
	 			 highlightElement("CheckoutDrools_Veo_OrderDetailPage_Submitted_DateStamp");
	 			 String DateStamp = getObject("CheckoutDrools_Veo_OrderDetailPage_Submitted_DateStamp").getText();
	 			 APP_LOGS.debug("Date Stamp for the Submitted Order is : "+DateStamp);
	      		 Reporter.log("Date Stamp for the Submitted Order is : "+DateStamp);
	 			 Thread.sleep(3000);
	      		
	 //=========================== Order Total Values (Net,Discount,$$ Values) ========================//
	 			 int TotalValue_List = driver.findElements(By.xpath("//div[@class='col-xs-4 right veo-pale-blue']/dl")).size();
	 			 
	 			 if(!(TotalValue_List == 0))
	 			 {
	 				for(int j=1;j<=TotalValue_List;j++)
	 				{
	 					String ListHeader = driver.findElement(By.xpath("//div[@class='col-xs-4 right veo-pale-blue']/dl["+j+"]/dt")).getText();
	 					String ListValue = driver.findElement(By.xpath("//div[@class='col-xs-4 right veo-pale-blue']/dl["+j+"]/dd")).getText();
	 					APP_LOGS.debug(ListHeader+" is : "+ListValue);
	 		      		Reporter.log(ListHeader+" is : "+ListValue);
	 		 			Thread.sleep(3000);
	 				}
	 			 }
	 
	 //=========================== To Verify that Submitted icon is highlighted and other icons remain shaded ========================//
	 			 int ShadedIconSize = driver.findElements(By.xpath("//span[@class='round round-completed']")).size();
	 			 APP_LOGS.debug("Size of Highlighted Icon is : "+ShadedIconSize);
		      	 Reporter.log("Size of Highlighted Icon is : "+ShadedIconSize);
		 		 Thread.sleep(3000);	
		 		
	 			 int UnShadedIconSize = driver.findElements(By.xpath("//span[@class='round round-uncompleted']")).size();
	 			 APP_LOGS.debug("Size of Shaded Icon is : "+UnShadedIconSize);
		      	 Reporter.log("Success: Verified that Submitted icon is highlighted and other icons remain shaded");
		 		 Thread.sleep(3000);	
		 		 
	 			 if((ShadedIconSize == 1)&&(UnShadedIconSize == 3))
	 			 {
	 				//Highlight the Order Status 
	 		 		highlightElement("CheckoutDrools_Veo_OrderDetailPage_OrderSubmitted");
	 		 		APP_LOGS.debug("Highlighted the Order Submitted");
	 		      	Reporter.log("Highlighted the Order Submitted");
	 		 		Thread.sleep(3000);
	 		 		
	 				APP_LOGS.debug("Success: Verified that Submitted icon is highlighted and other icons remain shaded");
 		      		Reporter.log("Success: Verified that Submitted icon is highlighted and other icons remain shaded");
 		 			Thread.sleep(3000);	
	 			 }
	 			 
	      		 break;
			}
			else
			{
				if(i==orderhistory_rowcount)
				{
					APP_LOGS.debug("FAILED: Submitted Order.No not found in Order History Page");
					Reporter.log("FAILED: Submitted Order.No not found in Order History Page");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("FAILED: Submitted Order.No not found in Order History Page");
				}
			}
			}
			}
		else
		{
			APP_LOGS.debug("FAILED: No Rows found in Order History Page");
			Reporter.log("FAILED: No Rows found in Order History Page");
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("FAILED: No Rows found in Order History Page");
		}
			
			APP_LOGS.debug("Test Completed & End of the Step");
			Reporter.log("Test Completed & End of the Step");
			
					
	}
		catch (Exception e) 
		{
			ErrorUtil.addVerificationFailure(e);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			System.err.println("Failed");
			APP_LOGS.debug("Test Failed & End of the Step");
			Reporter.log("Test Failed & End of the Step");
			throw e;
		} 
	

	}
			
			@AfterMethod
			public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
			
			}
			
			@AfterTest
			public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
				
			@DataProvider
			public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName()) ;
			}
		}

		

