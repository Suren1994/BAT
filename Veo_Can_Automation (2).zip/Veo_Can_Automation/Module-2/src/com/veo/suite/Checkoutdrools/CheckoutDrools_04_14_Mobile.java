package com.veo.suite.Checkoutdrools;


import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.TestUtil;


public class CheckoutDrools_04_14_Mobile extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName());
		}
	
	
	@Test(dataProvider="getTestData")
	public void Order_Pending_Cancellation_Mobile(
			String UsernameStoreFront,
			String PasswordStoreFront,
			String title1,
			String orderbtn_text,
			String CreateOrder_Header,
			String Order_Status,
			String UsernameBackoffice,
			String PasswordBackoffice,
			String OrderStatus_Dropdwon,
			String Qty_New
			) throws Throwable{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		prntResults("***************************************************************************************");
		prntResults("Executing CheckoutDrools TC_04_12_Mobile");
		prntResults("***************************************************************************************");
		prntResults("Mobile - Order History Summary - View Order in status: Order_Pending Cancellation");
		prntResults("***************************************************************************************");
		prntResults("Username: "+UsernameStoreFront +"& Password: "+PasswordStoreFront);
		sessionData.put("mobile_"+count, UsernameStoreFront);
		
		
		// LOGIN_BROWSER
		
		Firefoxprofile();
		prntResults("Browserup"+this.getClass().getSimpleName());
		
		driver.get(CONFIG.getProperty("testSiteName"));
		prntResults("Entered the URL of the Application");

		try
		{
		if(!Login2("Mobile_CheckoutDrools_Veo_Username","Mobile_CheckoutDrools_Veo_Password","Login_checkbox2","Login_submit",UsernameStoreFront,PasswordStoreFront)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}

   
		// CLICK_ON_MODULE
		FirstCloseButton();
		
		if(WaitForObjectAvailability("Mobile_createorder"))
		{
		getObject("Mobile_createorder").click();
		prntResults("clicked on Mobile_createorder");
		//Thread.sleep(4000);
		}
		
	//	SecondCloseButton();
		
		offRoutePopup();  
		Thread.sleep(3000);
		
		FirstCloseButton();

		if(WaitForObjectAvailability("Mobile_CancelOrder"))
		{
		getObject("Mobile_CancelOrder").click();
		prntResults("Clicked on CancelOrder");
		//Thread.sleep(3000);
		}

		if(WaitForObjectAvailability("Mobile_CancelOrder_yes"))
		{
		getObject("Mobile_CancelOrder_yes").click();
		prntResults("clicked on Yes button");
		//Thread.sleep(3000);
		}
		
		FirstCloseButton();
		Thread.sleep(3000);

		if(WaitForObjectAvailability("Mobile_createorder"))
		{
		getObject("Mobile_createorder").click();
		prntResults("clicked on Mobile_createorder");
		Thread.sleep(3000);
		}

		offRoutePopup();
		Thread.sleep(3000);

		SecondCloseButton();
		Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_quantity");
		
		getObject("Mobile_quantity").click();
		prntResults("clicked on Mobile_quantity");
		//Thread.sleep(4000);
		WaitForObjectAvailability("Mobile_CreateOrder_CartonsQuantity");
		
		getObject("Mobile_CreateOrder_CartonsQuantity").click(); 
		prntResults("Clicked on Mobile Cartons Quantity");
		//Thread.sleep(3000); 
		WaitForObjectAvailability("Mobile_Cart_quantity");
		
		
		getObject("Mobile_Cart_Keyboard_Two").click();
		prntResults("clicked on value 2");
		Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");


		getObject("Mobile_Cart_Keyboard_Next").click();
		prntResults("clicked on next");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Next");
		
		getObject("Mobile_Cart_Keyboard_Next").click();
		prntResults("clicked on next");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");
				
		getObject("Mobile_Cart_Keyboard_Two").click();
		prntResults("clicked on value 2");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");

		getObject("Mobile_Cart_Keyboard_Two").click();
		prntResults("clicked on value 2");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Three");
		
		getObject("Mobile_Cart_Keyboard_Three").click();
		prntResults("clicked on value 3");
		//Thread.sleep(3000);
		WaitForObjectAvailability("Mobile_Cart_Keyboard_Done");
		
		getObject("Mobile_Cart_Keyboard_Done").click();
		prntResults("clicked on Done button");
		//Thread.sleep(4000);
		WaitForObjectAvailability("Mobile_Cart_Continue");
		
		getObject("Mobile_Cart_Continue").click();
		prntResults("clicked on continue button");
		WaitForObjectAvailability("Ign_n_Con_createOrder_mobile");
		
		ignoreAndContinue_mobile();
		prntResults("clicked on Ign_n_Con_createOrder");
		//Thread.sleep(4000);
		WaitForObjectAvailability("Mobile_Cart_placeOrder");

		getObject("Mobile_Cart_placeOrder").click();
		prntResults("clicked on Mobile_Cart_placeOrder");
		//Thread.sleep(4000);
		WaitForObjectAvailability("Mobile_Cart_ORDER_Order_Submitted");

		checkText("Mobile_Cart_ORDER_Order_Submitted","Order Submitted");

		//To get the Order No 
		highlightElement("Mobile_CheckoutDrools_Veo_OrderDetails_OrderNo");
		String Order_Number = getObject("Mobile_CheckoutDrools_Veo_OrderDetails_OrderNo").getText();
		prntResults("Order No is : "+Order_Number);
		
		driver.quit();	
		//============================== Backoffice Login ==========================// 
		
		openBrowser();
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		//Login
		if(!LoginBackOffice("CheckoutDrools_BO_UserName","CheckoutDrools_BO_PassWord","CheckoutDrools_BO_Login",UsernameBackoffice,PasswordBackoffice)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}	
			
		Thread.sleep(3000);
		
		//Select the Flagged Order from the Order Status Dropdown 
		getObject("CheckoutDrools_BO_OrderStatus").click();
		APP_LOGS.debug("Clicked on Order Status");
		Reporter.log("Clicked on Order Status");
		getObject("CheckoutDrools_BO_OrderStatus").clear();
		getObject("CheckoutDrools_BO_OrderStatus").sendKeys(OrderStatus_Dropdwon);
		APP_LOGS.debug("Selected the Option "+OrderStatus_Dropdwon+" from the Order Status");
		Reporter.log("Selected the Option "+OrderStatus_Dropdwon+" from the Order Status");
		getObject("CheckoutDrools_BO_OrderStatus").click();
		APP_LOGS.debug("Clicked on Order Status");
		Reporter.log("Clicked on Order Status");
		Thread.sleep(3000);
		
		//Click on Refresh
		getObject("CheckoutDrools_BO_RefreshButton").click();
		APP_LOGS.debug("Clicked on Refresh button");
		Reporter.log("Clicked on Refresh button");
		Thread.sleep(3000);
		
	//=========================== To Click on the Submitted Order ==============================//
		
		int order_rowcount = driver.findElements(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[1]/div/div/div[2]/div[3]/div[3]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr")).size();
		APP_LOGS.debug("No.Of.Orders found in first page is : "+order_rowcount);
		Reporter.log("No.Of.Orders found in first page is : "+order_rowcount);
		Thread.sleep(3000);
		
		//To Select the Correct Order 
		for(int i=1;i<=order_rowcount;i++)
		{
			String orderno_txt = driver.findElement(By.xpath("//div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).getText();
			APP_LOGS.debug("Order.No in "+i+" row is: "+orderno_txt);
			Reporter.log("Order.No in "+i+" row is: "+orderno_txt);
			Thread.sleep(3000);
			
			if(Order_Number.equals(orderno_txt))
			{
				driver.findElement(By.xpath("//div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).click();
				APP_LOGS.debug("Clicked on the Order No "+orderno_txt);
				Reporter.log("Clicked on the Order No "+orderno_txt);
				Thread.sleep(3000);
				break;
			}
			else
			{
				if(i==order_rowcount)
				{
					APP_LOGS.debug("FAILED: The Submitted Order No not fount in first page of Backoffice");
					Reporter.log("FAILED: The Submitted Order No not fount in first page of Backoffice");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("FAILED: The Submitted Order No not fount in first page of Backoffice");
				}
			}
		}
				
		//get the handle of parent window
		String handle1=driver.getWindowHandle(); 
		
		//get all the windows handle
		Set<String> handles1=driver.getWindowHandles();
		
		//loop through each handles
		for(String hmd1:handles1)
		{
			//check if the handles is not parent
			if(!hmd1.equals(handle1))
			{
				//Change the control into new window
				driver.switchTo().window(hmd1);
			}
		}
		System.out.println("Switched to new window: "+driver.getTitle());
		APP_LOGS.debug("Switched to new window: "+driver.getTitle());
		Reporter.log("Switched to new window: "+driver.getTitle());
		Thread.sleep(5000);
	
		
		//click on the Amend Button 
		highlightElement("CheckoutDrools_BO_Amend");
		getObject("CheckoutDrools_BO_Amend").click();
		APP_LOGS.debug("Clicked on Amend button");
		Reporter.log("Clicked on Amend button");
		Thread.sleep(4000);
		
		//To Enter the Values in the Cart Page
		if(getObject("CheckoutDrools_Veo_quantity").isDisplayed())
		{
			for(int j=0;j<=2;j++)
			{
				driver.findElement(By.xpath(".//*[@id='quantity-"+j+"']")).clear();
				driver.findElement(By.xpath(".//*[@id='quantity-"+j+"']")).sendKeys(Qty_New);
				APP_LOGS.debug("Entered the Quantity for Product "+j+" as: "+Qty_New);
				Reporter.log("Entered the Quantity for Product "+j+" as: "+Qty_New);
				Thread.sleep(3000);
			}
		}
		else
		{
			APP_LOGS.debug("FAILED: No Products found for the Selected Order");
			Reporter.log("FAILED: No Products found for the Selected Order");
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("FAILED: No Products found for the Selected Order");
		}
		
		//Click on Continue Button
		getObject("CheckoutDrools_Veo_continue").click();
		APP_LOGS.debug("Clicked on Continue Button");
		Reporter.log("Clicked on Continue Button");
		Thread.sleep(3000);
		
		//To Click on Ignore and Continu Buuton if Appears 
		ignoreAndContinue();
		Thread.sleep(3000);
		
		//Click on Place Order Button 
		getObject("CheckoutDrools_Veo_PlaceOrder").click();
		APP_LOGS.debug("Clicked on Place Order Button");
		Reporter.log("Clicked on Place Order Button");
		Thread.sleep(3000);		
		
		//Switching to Main Window
		driver.switchTo().window(handle1);	
		APP_LOGS.debug("Switched back to Parent window");
		Reporter.log("Switched back to Parent window");
		Thread.sleep(5000);	
		
		//Select the Flagged Order from the Order Status Dropdown 
		getObject("CheckoutDrools_BO_OrderStatus").click();
		APP_LOGS.debug("Clicked on Order Status");
		Reporter.log("Clicked on Order Status");
		getObject("CheckoutDrools_BO_OrderStatus").clear();
		getObject("CheckoutDrools_BO_OrderStatus").sendKeys("Amended");
		APP_LOGS.debug("Selected the Option "+OrderStatus_Dropdwon+" from the Order Status");
		Reporter.log("Selected the Option "+OrderStatus_Dropdwon+" from the Order Status");
		getObject("CheckoutDrools_BO_OrderStatus").click();
		APP_LOGS.debug("Clicked on Order Status");
		Reporter.log("Clicked on Order Status");
		Thread.sleep(3000);
		
		//Click on Refresh
		getObject("CheckoutDrools_BO_RefreshButton").click();
		APP_LOGS.debug("Clicked on Refresh button");
		Reporter.log("Clicked on Refresh button");
		Thread.sleep(3000);
		
		//To Select the Correct Order 
		for(int i=1;i<=order_rowcount;i++)
		{
			String orderno_txt = driver.findElement(By.xpath("//div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).getText();
			APP_LOGS.debug("Order.No in "+i+" row is: "+orderno_txt);
			Reporter.log("Order.No in "+i+" row is: "+orderno_txt);
			Thread.sleep(3000);
			
			if(Order_Number.equals(orderno_txt))
			{
				driver.findElement(By.xpath("//div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).click();
				APP_LOGS.debug("Clicked on the Order No "+orderno_txt);
				Reporter.log("Clicked on the Order No "+orderno_txt);
				Thread.sleep(3000);
				break;
			}
			else
			{
				if(i==order_rowcount)
				{
					APP_LOGS.debug("FAILED: The Submitted Order No not fount in first page of Backoffice");
					Reporter.log("FAILED: The Submitted Order No not fount in first page of Backoffice");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("FAILED: The Submitted Order No not fount in first page of Backoffice");
				}
			}
		}
				
		
		//get all the windows handle
		Set<String> handles2=driver.getWindowHandles();
		
		//loop through each handles
		for(String hmd2:handles2)
		{
			//check if the handles is not parent
			if(!hmd2.equals(handles2))
			{
				//Change the control into new window
				driver.switchTo().window(hmd2);
			}
		}
		System.out.println("Switched to new window: "+driver.getTitle());
		APP_LOGS.debug("Switched to new window: "+driver.getTitle());
		Reporter.log("Switched to new window: "+driver.getTitle());
		Thread.sleep(5000);
		
		//click on the Amend Button 
		highlightElement("CheckoutDrools_BO_Amend");
		getObject("CheckoutDrools_BO_Amend").click();
		APP_LOGS.debug("Clicked on Amend button");
		Reporter.log("Clicked on Amend button");
		Thread.sleep(4000);

		//Click on Cancel 
		getObject("CheckoutDrools_BO_Cancel").click();
		APP_LOGS.debug("Clicked on the Cancel order");
		Reporter.log("Clicked on the Cancel order");
		Thread.sleep(3000);
		
		//Click on Yes Button 
		getObject("CheckoutDrools_BO_CancelYes").click();
		APP_LOGS.debug("Clicked on the Cancel order->yes");
		Reporter.log("Clicked on the Cancel order->yes");
		Thread.sleep(5000);
		
		driver.switchTo().window(handle1);
		APP_LOGS.debug("Switched to Parent Window: "+driver.getTitle());
		Reporter.log("Switched to Parent Window: "+driver.getTitle());
		Thread.sleep(5000);

		driver.quit();
		
		//=============== Switch to StoreFront ==================// 
	/*	switchToTab();
		APP_LOGS.debug("Switched back to StoreFront");
		Reporter.log("Switched back to StoreFront");
		WaitForObjectAvailability("GoSmartimage");*/
		
		FirefoxDeafultprofile();
		
		driver.get(CONFIG.getProperty("testSiteName"));
		prntResults("Entered the URL of the Application");

		
		if(!Login2("Mobile_CheckoutDrools_Veo_Username","Mobile_CheckoutDrools_Veo_Password","Login_checkbox2","Login_submit",UsernameStoreFront,PasswordStoreFront)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}

   
		// CLICK_ON_MODULE
		FirstCloseButton();

		getObject("GoSmartimage").click();
		prntResults("clicked on GoSmartimage");
		Thread.sleep(2000);
		FirstCloseButton();		
		
		highlightElement("Mobile_Logout");
		getObject("Mobile_Logout").click();
		prntResults("Clicked on MobileLogout button");
		WaitForObjectAvailability("Mobile_CheckoutDrools_Veo_Username");
		
		if(!Login2("Mobile_CheckoutDrools_Veo_Username","Mobile_CheckoutDrools_Veo_Password","Login_checkbox2","Login_submit",UsernameStoreFront,PasswordStoreFront)){
			// screenshot
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			fail=true;
			// quit
			return;
		}

   
		// CLICK_ON_MODULE
		FirstCloseButton();

		//Click on Order History in Home Page 
		getObject("Mobile_CheckoutDrools_Veo_OrderHistory").click();
		prntResults("Clicked on Order History");

		//No.Of.Products in Order Hitory Page 
		int OrdersCount = driver.findElements(By.xpath(".//*[@id='page-content']/div[2]/div/div")).size();
		prntResults("No.Of.Orders found in Order History page is : "+OrdersCount);
		
		for(int i=1;i<=OrdersCount;i++)
		{
			String OrderHistory_OrderNo = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/h3/span[1]")).getText();
			prntResults("Order no in "+i+" row is : "+OrderHistory_OrderNo);
			
			if(Order_Number.equals(OrderHistory_OrderNo))
			{
				//Order Status
				String CurrentStatus = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/h3/span[2]")).getText();
				prntResults("Current Status of the Order is : "+CurrentStatus);
				
				if(CurrentStatus.equalsIgnoreCase(Order_Status))
				{
					prntResults("Success: Verified that Order is in CANCELLATION REQUESTED Status");
				}
				else
				{
					prntResults("Verification Failed: Order status is not CANCELLATION REQUESTED but as : "+CurrentStatus);
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("Verification Failed: Order status is not CANCELLATION REQUESTED but as : "+CurrentStatus);
				}
				
				//Order date Stamp 
				String DateStamp = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/dl["+i+"]/dd")).getText();
				prntResults("Date Stamp is : "+DateStamp);
				
	//=========================== Order Total Values (Net,Discount,$$ Values) ========================//
	 			 int TotalValue_List = driver.findElements(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/dl")).size();
	 			 
	 			 if(!(TotalValue_List == 0))
	 			 {
	 				for(int j=1;j<=TotalValue_List;j++)
	 				{
	 					String ListHeader = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/dl["+j+"]/dt")).getText();
	 					String ListValue = driver.findElement(By.xpath(".//*[@id='page-content']/div[2]/div/div["+i+"]/div/dl["+j+"]/dd")).getText();
	 					APP_LOGS.debug(ListHeader+" is : "+ListValue);
	 		      		Reporter.log(ListHeader+" is : "+ListValue);
	 		 			Thread.sleep(3000);
	 				}
	 			 }
	 			 break;
			}
			else
			{
				if(i==OrdersCount)
				{
					prntResults("Failed: Placed Order No is not found in Order History Page");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("Failed: Placed Order No is not found in Order History Page");
				}
			}
		}
		

		
		}
		catch(Exception e)
		{
		System.err.println("Failed");
		prntResults("Failedddd");
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		throw e;
		}
		finally
		{
		getObject("GoSmartimage").click();
		prntResults("clicked on GoSmartimage");
		Thread.sleep(2000);
		FirstCloseButton();

		highlightElement("Mobile_Logout");
		getObject("Mobile_Logout").click();
		prntResults("Clicked on MobileLogout button");

		System.out.println("Test Completed");
		prntResults("Test Completed");
		} 
	}
		@AfterMethod
		public void reportDataSetResult(){
		if(skip)
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "SKIP");
		else if(fail){
		isTestPass=false;
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "FAIL");
		}
		else
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "PASS");
		skip=false;
		fail=false; 

		}
		@AfterTest
		public void reportTestResult(){
		if(isTestPass)
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "PASS");
		else
		TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "FAIL");
		closeBrowser();
		}
		@DataProvider
		public Object[][] getTestData(){
		return TestUtil.getData(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName()) ;
		}
		}

