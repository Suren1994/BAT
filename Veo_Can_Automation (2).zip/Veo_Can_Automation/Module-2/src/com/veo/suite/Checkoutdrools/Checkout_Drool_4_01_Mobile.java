package com.veo.suite.Checkoutdrools;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.TestUtil;

public class Checkout_Drool_4_01_Mobile extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName())){
				prntResults("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName());
		}
	//===Drools_Suite_xls
		@Test(dataProvider="getTestData")
	public void Checkout_Drool_01_Mobile(
			String uname,
			String pwd,
			String RuleName_toSearch,
			String MessageSize,
			String OutcomeSize,
			String RuleMessage,
			String Outcome,
			String UsernameStoreFront,
			String PasswordStoreFront,
			String DroolMessage_inCart
			) throws Throwable,Exception{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		prntResults("==================================================================");
		prntResults("CheckoutDrools_Mobile - Low Order Quantity for every product where order quanitity product  is < 90% of the SOQ");
		prntResults("***************************************************************************************");
		prntResults("Username: "+uname+" & Password:"+pwd);
		//sessionData.put("mobile_"+count, uname);

		// webdriver
		openBrowser();
		
		driver.get(CONFIG.getProperty("BRMS"));
		driver.navigate().refresh();
		
		//driver.findElement(By.xpath(xpathExpression))
		
		try
		{
//============================Login to Go Smart Application=================================//
			
				if(!LoginCheckout_Drools("CheckoutDrools_UserName","CheckoutDrools_Password","CheckoutDrools_Login_Ok_Button",uname,pwd))
				{
				// screenshot
				prntResults("Login Failed for Checkout Drools");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			          }
			
//===============================To Click on Knowledge Bases Package==================================//
			
				Thread.sleep(7000);
			//	highlightElement("Drools_KnowledgeBase");
				getObject("Drools_KnowledgeBase").click();
				prntResults("Clicked On BRMS Knowledge Base Package");
				//=======To Expand Packages Plus Sign==========//
				
				Thread.sleep(3000);
				//highlightElement("Drools_Package_PlusSign");
				getObject("Drools_Package_PlusSign").click();
				prntResults("Expanded Packages Plus Sign");
				
				//=======To Select VEO Aus Package==========//
				
				Thread.sleep(2000);
			    highlightElement("Drools_Package_veo_can");
		 		getObject("Drools_Package_veo_can").click();
				prntResults("Selected VEO Can Package");
				
				//=======To Expand Business Rule Assets Plus Sign==========//
				Thread.sleep(2000);
				getObject("Drools_BusinessRuleAssets_PlusSign").click();
				prntResults("Expanded Business Rule Assets Plus Sign");
			
					//=======To Click on Find Tab==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Tab");
					getObject("Drools_Find_Tab").click();
					prntResults("Clicked On Find Tab");
					
					//=======To Give Search Name==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Name_Matching");
					getObject("Drools_Find_Name_Matching").clear();
					getObject("Drools_Find_Name_Matching").sendKeys(RuleName_toSearch);
					Thread.sleep(2000);
					getObject("Drools_Find_Name_Matching").sendKeys(Keys.TAB);
					prntResults("Searching Name is: "+RuleName_toSearch);
					
					//=======To Click on Search Button==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Searchbtn");
					getObject("Drools_Find_Searchbtn").click();
					prntResults("Clicked On Search Button");
					
					Thread.sleep(2000);
					highlightElement("Drools_Openbutton");
					getObject("Drools_Openbutton").click();
					prntResults("Clicked On Drools_Openbutton ");
										
					String rule = driver.findElement(By.xpath("//input[@class='gwt-TextBox' and @size='"+MessageSize+"']")).getAttribute("value");
					prntResults("Rule name is" + rule);	
					
					String OUTCOME = driver.findElement(By.xpath("//input[@class='gwt-TextBox' and @size='"+OutcomeSize+"']")).getAttribute("value");
					prntResults("outcome is" + OUTCOME);	
					
				   /* Assert.assertEquals(rule,RuleMessage);
				    
				    Assert.assertEquals(OUTCOME,Outcome);	*/		    
					
					if(!checkAttributevalue("CheckoutDrools_LowOrderQtyLine_RuleMessage", RuleMessage))
					{
						// screenshot
						//hightlightscreenshot("MyDocHeader");
						prntResults("Failed: Rule Message is incorrect");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						 //quit
						return;
					}
				    
					if(!checkAttributevalue("CheckoutDrools_LowOrderQtyLine_OutCome", Outcome)){
						// screenshot
						//hightlightscreenshot("MyDocHeader");
						prntResults("Failed: Outcome is incorrect");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						 //quit
						return;
					}
					
closeBrowser();
					//Open A New Browser 
					Firefoxprofile();
					
					driver.get(CONFIG.getProperty("testSiteName"));
					prntResults("Entered the URL of the Application");

					if(!Login2("Mobile_CheckoutDrools_Veo_Username","Mobile_CheckoutDrools_Veo_Password","Login_checkbox2","Login_submit",UsernameStoreFront,PasswordStoreFront)){
						// screenshot
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						// quit
						return;
					}

			   
					// CLICK_ON_MODULE
					FirstCloseButton();
					
					if(WaitForObjectAvailability("Mobile_createorder"))
					{
					getObject("Mobile_createorder").click();
					prntResults("clicked on Mobile_createorder");
					//Thread.sleep(4000);
					}
					
					SecondCloseButton();
					
					offRoutePopup();  
					Thread.sleep(3000);
					
					FirstCloseButton();

					if(WaitForObjectAvailability("Mobile_CancelOrder"))
					{
					getObject("Mobile_CancelOrder").click();
					prntResults("Clicked on CancelOrder");
					//Thread.sleep(3000);
					}

					if(WaitForObjectAvailability("Mobile_CancelOrder_yes"))
					{
					getObject("Mobile_CancelOrder_yes").click();
					prntResults("clicked on Yes button");
					//Thread.sleep(3000);
					}
					
					FirstCloseButton();
					Thread.sleep(3000);

					if(WaitForObjectAvailability("Mobile_createorder"))
					{
					getObject("Mobile_createorder").click();
					prntResults("clicked on Mobile_createorder");
					Thread.sleep(3000);
					}

					offRoutePopup();
					Thread.sleep(3000);

					SecondCloseButton();
					Thread.sleep(3000);
					WaitForObjectAvailability("Mobile_quantity");
					
					getObject("Mobile_quantity").click();
					prntResults("clicked on Mobile_quantity");
					//Thread.sleep(4000);
					WaitForObjectAvailability("Mobile_CreateOrder_CartonsQuantity");
					
					getObject("Mobile_CreateOrder_CartonsQuantity").click(); 
					prntResults("Clicked on Mobile Cartons Quantity");
					//Thread.sleep(3000); 
					WaitForObjectAvailability("Mobile_Cart_quantity");
					
					getObject("Mobile_Cart_Keyboard_Next").click();
					prntResults("clicked on next");
					//Thread.sleep(3000);
					WaitForObjectAvailability("Mobile_Cart_Keyboard_Next");
					
					getObject("Mobile_Cart_Keyboard_Next").click();
					prntResults("clicked on next");
					
					getObject("Mobile_Cart_Keyboard_Three").click();
					prntResults("clicked on value 3");
					//Thread.sleep(3000);
					WaitForObjectAvailability("Mobile_Cart_Keyboard_Done");
					
					getObject("Mobile_Cart_Keyboard_Done").click();
					prntResults("clicked on Done button");
					//Thread.sleep(4000);
					WaitForObjectAvailability("Mobile_Cart_Continue");
					
					getObject("Mobile_Cart_Continue").click();
					prntResults("clicked on continue button");

					getObject("Mobile_Cart_AmendOrder").click();
					prntResults("Clicked on Amend Order");
					
					highlightElement("Mobile_Cart_Amend_Warning");
					
					if(!checkText("Mobile_Cart_Amend_Warning",DroolMessage_inCart))
					{
						// screenshot
						prntResults("Validation Failed for Drools Warning Message");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						 //quit
						return;
					}
					
					//Logout
					
					System.out.println("Test Completed");
					prntResults("Test Completed & End of the Step");

					
		}
		catch (Exception e) 
		{
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			prntResults("Failed");
			throw e;
		} 
		}
		
		@AfterMethod
		public void reportDataSetResult(){
		if(skip)
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "SKIP");
		else if(fail){
			isTestPass=false;
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
		else
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
				
			}
			
		@AfterTest
		public void reportTestResult(){
		if(isTestPass)
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
			}			
						
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName()) ;
		}
		}

		

