package com.veo.suite.Checkoutdrools;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.TestUtil;

public class Checkout_Drool_4_06_Mobile extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName())){
				prntResults("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName());
		}
	//===Drools_Suite_xls
		@Test(dataProvider="getTestData")
	public void Checkout_Drool_06_Mobile(
			String UsernameBRMS,
			String PasswordBRMS,
			String RuleName_toSearch,
			String MessageSize,
			String OutcomeSize,
			String RuleMessage,
			String Outcome,
			String UsernameStoreFront,
			String PasswordStoreFront,
			String Qty,
			String DroolMessage_inCart,
			String UsernameBackoffice,
			String PasswordBackoffice
			) throws Throwable,Exception{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		prntResults("***************************************************************************************");
		prntResults("Mobile - Customer & Replenishment Agent sees Off-Route rule(Warn & Flag)applied after order submission");
		prntResults("***************************************************************************************");
		prntResults("Username: "+UsernameStoreFront+" & Password:"+PasswordStoreFront);
		//sessionData.put("mobile_"+count, uname);

		// webdriver
		openBrowser();
		
		driver.get(CONFIG.getProperty("BRMS"));
		driver.navigate().refresh();
		
		//driver.findElement(By.xpath(xpathExpression))
		
		try
		{
//============================Login to Go Smart Application=================================//
			
				if(!LoginCheckout_Drools("CheckoutDrools_UserName","CheckoutDrools_Password","CheckoutDrools_Login_Ok_Button",UsernameBRMS,PasswordBRMS))
				{
				// screenshot
				prntResults("Login Failed for Checkout Drools");
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			          }
			
//===============================To Click on Knowledge Bases Package==================================//
			
				Thread.sleep(7000);
			//	highlightElement("Drools_KnowledgeBase");
				getObject("Drools_KnowledgeBase").click();
				prntResults("Clicked On BRMS Knowledge Base Package");
				//=======To Expand Packages Plus Sign==========//
				
				Thread.sleep(3000);
				//highlightElement("Drools_Package_PlusSign");
				getObject("Drools_Package_PlusSign").click();
				prntResults("Expanded Packages Plus Sign");
				
				//=======To Select VEO Aus Package==========//
				
				Thread.sleep(2000);
			    highlightElement("Drools_Package_veo_can");
		 		getObject("Drools_Package_veo_can").click();
				prntResults("Selected VEO Can Package");
				
				//=======To Expand Business Rule Assets Plus Sign==========//
				Thread.sleep(2000);
				getObject("Drools_BusinessRuleAssets_PlusSign").click();
				prntResults("Expanded Business Rule Assets Plus Sign");
			
					//=======To Click on Find Tab==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Tab");
					getObject("Drools_Find_Tab").click();
					prntResults("Clicked On Find Tab");
					
					//=======To Give Search Name==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Name_Matching");
					getObject("Drools_Find_Name_Matching").clear();
					getObject("Drools_Find_Name_Matching").sendKeys(RuleName_toSearch);
					Thread.sleep(2000);
					getObject("Drools_Find_Name_Matching").sendKeys(Keys.TAB);
					prntResults("Searching Name is: "+RuleName_toSearch);
					
					//=======To Click on Search Button==========//
					Thread.sleep(2000);
					highlightElement("Drools_Find_Searchbtn");
					getObject("Drools_Find_Searchbtn").click();
					prntResults("Clicked On Search Button");
					
					Thread.sleep(2000);
					highlightElement("Drools_Openbutton");
					getObject("Drools_Openbutton").click();
					prntResults("Clicked On Drools_Openbutton ");
										
					String rule = driver.findElement(By.xpath("//input[@class='gwt-TextBox' and @size='"+MessageSize+"']")).getAttribute("value");
					prntResults("Rule name is" + rule);	
					
					String OUTCOME = driver.findElement(By.xpath("//input[@class='gwt-TextBox' and @size='"+OutcomeSize+"']")).getAttribute("value");
					prntResults("outcome is" + OUTCOME);	
					
				   /* Assert.assertEquals(rule,RuleMessage);
				    
				    Assert.assertEquals(OUTCOME,Outcome);	*/		    
					
					if(!checkAttributevalue("CheckoutDrools_offRouteValidation_RuleMessage", RuleMessage))
					{
						// screenshot
						//hightlightscreenshot("MyDocHeader");
						prntResults("Failed: Rule Message is incorrect");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						 //quit
						return;
					}
				    
					if(!checkAttributevalue("CheckoutDrools_offRouteValidation_OutCome", Outcome)){
						// screenshot
						//hightlightscreenshot("MyDocHeader");
						prntResults("Failed: Outcome is incorrect");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						 //quit
						return;
					}
					
//========================== Login to Mobile StoreFront ===============================//					

						Firefoxprofile();
						prntResults("Browserup"+this.getClass().getSimpleName());
						
						driver.get(CONFIG.getProperty("testSiteName"));
						prntResults("Entered the URL of the Application");

						if(!Login_Mobile("Mobile_CheckoutDrools_Veo_Username","Mobile_CheckoutDrools_Veo_Password","Login_checkbox2","Login_submit",UsernameStoreFront,PasswordStoreFront)){
							// screenshot
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							fail=true;
							// quit
							return;
						}

				   
						// CLICK_ON_MODULE
						FirstCloseButton();
						
						if(WaitForObjectAvailability("Mobile_createorder"))
						{
						getObject("Mobile_createorder").click();
						prntResults("clicked on Mobile_createorder");
						//Thread.sleep(4000);
						}
						
					//	SecondCloseButton();
						
						offRoutePopup();  
						Thread.sleep(3000);
						
						FirstCloseButton();

						if(WaitForObjectAvailability("Mobile_CancelOrder"))
						{
						getObject("Mobile_CancelOrder").click();
						prntResults("Clicked on CancelOrder");
						//Thread.sleep(3000);
						}

						if(WaitForObjectAvailability("Mobile_CancelOrder_yes"))
						{
						getObject("Mobile_CancelOrder_yes").click();
						prntResults("clicked on Yes button");
						//Thread.sleep(3000);
						}
						
						FirstCloseButton();
						Thread.sleep(3000);

						if(WaitForObjectAvailability("Mobile_createorder"))
						{
						getObject("Mobile_createorder").click();
						prntResults("clicked on Mobile_createorder");
						Thread.sleep(3000);
						}

						offRoutePopup();
						Thread.sleep(3000);

						SecondCloseButton();
						Thread.sleep(3000);
						WaitForObjectAvailability("Mobile_quantity");
						
						getObject("Mobile_quantity").click();
						prntResults("clicked on Mobile_quantity");
						//Thread.sleep(4000);
						WaitForObjectAvailability("Mobile_CreateOrder_CartonsQuantity");
						
						getObject("Mobile_CreateOrder_CartonsQuantity").click(); 
						prntResults("Clicked on Mobile Cartons Quantity");
						//Thread.sleep(3000); 
						WaitForObjectAvailability("Mobile_Cart_quantity");
						
						
						getObject("Mobile_Cart_Keyboard_Two").click();
						prntResults("clicked on value 2");
						Thread.sleep(3000);
						WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");


						getObject("Mobile_Cart_Keyboard_Next").click();
						prntResults("clicked on next");
						//Thread.sleep(3000);
						WaitForObjectAvailability("Mobile_Cart_Keyboard_Next");
						
						getObject("Mobile_Cart_Keyboard_Next").click();
						prntResults("clicked on next");
						//Thread.sleep(3000);
						WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");
								
						getObject("Mobile_Cart_Keyboard_Two").click();
						prntResults("clicked on value 2");
						//Thread.sleep(3000);
						WaitForObjectAvailability("Mobile_Cart_Keyboard_Two");

						getObject("Mobile_Cart_Keyboard_Two").click();
						prntResults("clicked on value 2");
						//Thread.sleep(3000);
						/*WaitForObjectAvailability("Mobile_Cart_Keyboard_Three");
						
						getObject("Mobile_Cart_Keyboard_Three").click();
						prntResults("clicked on value 3");
						//Thread.sleep(3000);
*/						WaitForObjectAvailability("Mobile_Cart_Keyboard_Done");
						
						getObject("Mobile_Cart_Keyboard_Done").click();
						prntResults("clicked on Done button");
						//Thread.sleep(4000);
						WaitForObjectAvailability("Mobile_Cart_Continue");
						
						getObject("Mobile_Cart_Continue").click();
						prntResults("clicked on continue button");
						WaitForObjectAvailability("Ign_n_Con_createOrder_mobile");
						
						highlightElement("Mobile_CheckoutDrools_offRouteValidation_WarnMsg");
						if(!checkText("Mobile_CheckoutDrools_offRouteValidation_WarnMsg",DroolMessage_inCart))
						{
							// screenshot
							prntResults("Validation Failed for Drools Warning Message");
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							fail=true;
							 //quit
							return;
						}

						
						ignoreAndContinue_mobile();
						prntResults("clicked on Ign_n_Con_createOrder");
						//Thread.sleep(4000);
						WaitForObjectAvailability("Mobile_Cart_placeOrder");

						getObject("Mobile_Cart_placeOrder").click();
						prntResults("clicked on Mobile_Cart_placeOrder");
						//Thread.sleep(4000);
						WaitForObjectAvailability("Mobile_Cart_ORDER_Order_Submitted");

						checkText("Mobile_Cart_ORDER_Order_Submitted","Order Submitted");

						//To get the Order No 
						highlightElement("Mobile_CheckoutDrools_Veo_OrderDetails_OrderNo");
						String Order_Number = getObject("Mobile_CheckoutDrools_Veo_OrderDetails_OrderNo").getText();
						prntResults("Order No is : "+Order_Number);
						
						//driver.quit();	
			//============================== Backoffice Login ==========================// 
						
						openBrowser();
						
						driver.get(CONFIG.getProperty("backofficeurl"));
						APP_LOGS.debug("Entered Replenishment cockpit URL");
						Reporter.log("Entered Replenishment cockpit URL");
						
						//Login
						if(!LoginBackOffice("CheckoutDrools_BO_UserName","CheckoutDrools_BO_PassWord","CheckoutDrools_BO_Login",UsernameBackoffice,PasswordBackoffice)){
							// screenshot
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							fail=true;
							// quit
							return;
						}	
							
						Thread.sleep(3000);

						int order_rowcount = driver.findElements(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[1]/div/div/div[2]/div[3]/div[3]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr")).size();
						APP_LOGS.debug("No.Of.Orders found in first page is : "+order_rowcount);
						Reporter.log("No.Of.Orders found in first page is : "+order_rowcount);
						Thread.sleep(3000);
						
						//To Select the Correct Order 
						for(int i=1;i<=order_rowcount;i++)
						{
							String orderno_txt = driver.findElement(By.xpath("//div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).getText();
							APP_LOGS.debug("Order.No in "+i+" row is: "+orderno_txt);
							Reporter.log("Order.No in "+i+" row is: "+orderno_txt);
							Thread.sleep(3000);
							
							if(Order_Number.equals(orderno_txt))
							{
								//Click on the Reason Column
								driver.findElement(By.xpath("//table/tbody[2]/tr["+i+"]/td[6]/div/img")).click();
								prntResults("Clicked on Reason Column of the Matched Order Number");
								
								for(int j=4;j<7;j++)
								{
								String rulereason=driver.findElement(By.xpath("html/body/div[3]/div/div/span/table/tbody/tr["+j+"]/td[1]")).getText();
								if(rulereason.equals(RuleMessage))
								{
									prntResults("Success: Applied Rule Code found in the Submitted Order");
								}
								
								else
								{
									if(j==7)
									{
										prntResults("FAILED: Applied Rule not found in the Submitted Order");
										capturescreenshot(this.getClass().getSimpleName()+"_"+count);
										throw new Exception("FAILED: Applied Rule not found in the Submitted Order");
									}
								}
							break;
							}
							break;
						}
							else
							{
								if(i==order_rowcount)
								{
									APP_LOGS.debug("FAILED: The Submitted Order No not fount in first page of Backoffice");
									Reporter.log("FAILED: The Submitted Order No not fount in first page of Backoffice");
									capturescreenshot(this.getClass().getSimpleName()+"_"+count);
									throw new Exception("FAILED: The Submitted Order No not fount in first page of Backoffice");
								}
							}
						}

						System.out.println("Test Completed");
						prntResults("Test Completed & End of the Step");
								

						
 //===============Close the Test Case=====================//
					
		prntResults("Test Case Completed and End of the step");
		}
		catch (Exception e) 
		{
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			prntResults("Failed");
			throw e;
		} 
		}
		
		@AfterMethod
		public void reportDataSetResult(){
		if(skip)
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "SKIP");
		else if(fail){
			isTestPass=false;
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
		else
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
				
			}
			
		@AfterTest
		public void reportTestResult(){
		if(isTestPass)
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suite_Can_CheckoutDrools_xls, "Test Cases", TestUtil.getRowNum(suite_Can_CheckoutDrools_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
			}			
						
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_CheckoutDrools_xls, this.getClass().getSimpleName()) ;
		}
		}

		

