package com.veo.base;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Hashtable;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Parameters;

//import atu.testng.reports.ATUReports;

































import com.google.common.base.Predicate;
import com.sun.org.apache.xpath.internal.functions.Function;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;
import com.veo.util.Xls_Reader;

public class TestBase {
	private static final String Invalid = null;
	public static Logger APP_LOGS=null;
	public static Properties CONFIG=null;
	public static Properties OR=null;
	//public static Properties OR2=null;
	public static Properties AppText = null;
	public static Xls_Reader suiteXls = null;
	
	public static Xls_Reader suite_Can_BackOffice_xls=null;	
	public static Xls_Reader suite_Can_ContactUs_xls=null;
	
	public static Xls_Reader suite_Can_Mobile_Trusted_xls=null;	
	public static Xls_Reader suite_Can_Cart_xls=null;
	public static Xls_Reader suite_Can_MyAccount_xls=null;
	public static Xls_Reader suite_Can_MyPerformance_xls=null;
	public static Xls_Reader suite_Can_Desktop_Trusted_xls=null;
	public static Xls_Reader suite_Can_Desktop_xls=null;
	public static Xls_Reader suite_Can_Desktop_Engagement=null;
	public static Xls_Reader suite_Can_Price_Capture=null;
	public static Xls_Reader suite_Can_Volume_Capture=null;
	public static Xls_Reader suite_Can_Program_Components=null;
	public static Xls_Reader suite_Can_Mobile_Engagement=null;	
	public static Xls_Reader suite_trustedclerk_xls=null;
	public static Xls_Reader suite_Can_Mobile_xls = null;
	public static Xls_Reader suite_Can_Personalisation_xls=null;
	public static Xls_Reader suite_Can_MyTransaction_xls=null; 
	public static Xls_Reader suite_Can_CancellationProcess_xls=null;
    public static Xls_Reader suite_Can_CheckoutDrools_xls = null; 
	public static Xls_Reader suite_Can_DynamicListing_xls = null;
	public static Xls_Reader suite_Can_DynamicTracking_xls = null;
	public static Xls_Reader suite_Can_Desktop_Cart_xls=null;	
	public static Xls_Reader suite_Can_EventForecast_xls=null;
	public static Xls_Reader suite_Can_comsandmesagesBO_xls=null;
	public static Xls_Reader suite_Can_ContentManagement_xls=null;
	public static Xls_Reader suite_Can_CommsCalendar_xls=null;
	public static Xls_Reader suite_Can_InventoryUpload_xls=null; 
	
	//public static Xls_Reader suite_Can_BackOffice_xls=null;	
	public static boolean isInitalized=false;
	public static boolean isBrowserOpened=false;
	//public static boolean islogin=false;
	public static Hashtable<String,String> sessionData = new Hashtable<String,String>();
	public static  WebDriver driver1 = null;
	public static  WebDriver driver =null;
	public static  FirefoxProfile profile  =null;
	public static int count=-1;
	public static boolean fail=false;
	//public static String browserType;
	
	// initializing the Tests
	public void initialize() throws Exception{
		// logs
		if(!isInitalized){
		APP_LOGS = Logger.getLogger("devpinoyLogger");
		
		// config
		APP_LOGS.debug("Loading Property files");
		Reporter.log("Loading Property files");
		
		CONFIG = new Properties();
		FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config/config.properties");
		CONFIG.load(ip);
			
		OR = new Properties();
		ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config/OR.properties");
		OR.load(ip);
		
		/*OR2 = new Properties();
		ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config/OR2.properties");
		OR2.load(ip);	*/
		
		APP_LOGS.debug("Loaded Property files successfully");
		Reporter.log("Loaded Property files successfully");
		APP_LOGS.debug("Loading XLS Files");
		Reporter.log("Loading XLS Files");	
		
		//System.out.println(OR2.getProperty("HMC_Logout"));
		
		AppText=new Properties();
		ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config/AppText.properties");
		AppText.load(ip);

		// xls file
		suite_Can_CheckoutDrools_xls   = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_CheckoutDrools_Suite.xlsx");
		suite_Can_Cart_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Cart_Suite.xlsx");
		suite_Can_ContactUs_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_ContactUs_Suite.xlsx");
		suite_Can_Volume_Capture = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Volume_Capture_Suite.xlsx");
		suite_Can_Price_Capture = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Price_Capture_Suite.xlsx");
		suite_Can_Program_Components = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Program_Component_Suite.xlsx");
		suite_Can_Desktop_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Desktop_Suite.xlsx");
		suite_Can_BackOffice_xls=new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_BackOffice_Suite.xlsx");
		//suite_shop_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Shop Suite.xlsx");
		suite_Can_Desktop_Engagement = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Desktop_Engagement_Suite.xlsx");
		suite_Can_Mobile_Engagement = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Mobile_Engagement_Suite.xlsx");
//suite_trustedclerk_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Trustedclerk Suite.xlsx");
		//suite_Can_Mobile_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Mobile Suite.xlsx");
		suite_Can_Mobile_Trusted_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Mobile_Trusted_Suite.xlsx");
		suite_Can_Mobile_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Mobile_Suite.xlsx");
		suite_Can_MyAccount_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_MyAccount_Suite.xlsx");
		suite_Can_MyPerformance_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_MyPerformance_Suite.xlsx");
		suite_Can_Desktop_Trusted_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Desktop_Trusted_Suite.xlsx");
		suite_Can_DynamicListing_xls= new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Dynamic_Listing_Suite.xlsx");
		suite_Can_DynamicTracking_xls= new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Dynamic_Tracking_Suite.xlsx");
		suite_Can_MyTransaction_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_MyTransaction_Suite.xlsx");
		suite_Can_Personalisation_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Personalisation_Suite.xlsx");
		suite_Can_CancellationProcess_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_CancellationProcess_Suite.xlsx");
		suite_Can_Desktop_Cart_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Desktop_Cart_Suite.xlsx");
		suite_Can_EventForecast_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_EventForecast_Suite.xlsx");
		suite_Can_comsandmesagesBO_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Comms&Messages_BO_suite.xlsx");
		suite_Can_ContentManagement_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_ContentManagement_Suite.xlsx");
		suite_Can_Personalisation_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_Personalisation_Suite.xlsx");
		suite_Can_CommsCalendar_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_CommsCalendar_Suite.xlsx");
		suite_Can_InventoryUpload_xls = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Can_InventoryUpload.xlsx");
		
		suiteXls = new Xls_Reader(System.getProperty("user.dir")+"\\src\\com\\veo\\xls\\Suite.xlsx");
		
		
		APP_LOGS.debug("Loaded XLS Files successfully");
		isInitalized=true;
		}
	}
	
	@Parameters ({"browserType"})
	public void openBrowser() throws InterruptedException
	{
	if(!isBrowserOpened)
	{
		if(CONFIG.getProperty("browserType").equals("MOZILLA"))
		{
			
			driver = new FirefoxDriver();
		
		driver.manage().timeouts().pageLoadTimeout(10000,TimeUnit.SECONDS);
	    }		
		else if (CONFIG.getProperty("browserType").equals("IE"))
			{	
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			
			//capabilities.setJavascriptEnabled(true);
			//capabilities.setCapability("unexpectedAlertBehaviour", "accept");
			//capabilities.setCapability("ignoreZoomSetting", true);
			//capabilities.setCapability("nativeEvents",false);
			capabilities.setCapability("disable-popup-blocking", true);
			capabilities.setCapability("REQUIRE_WINDOW_FOCUS", true);
			
		System.setProperty("webdriver.ie.driver", "D:\\Chromedriver\\IEDriverServer.exe");	
        driver = new InternetExplorerDriver(capabilities);
	    }
		         
		else if (CONFIG.getProperty("browserType").equals("CHROME"))
		
		{
			/*ChromeOptions options = new ChromeOptions();
			options.addArguments("start-maximized", "forced-maximize-mode",
					"disable-threaded-compositing", "disable-gpu",
					"disable-custom-jumplist", "disable-desktop-notifications",
					"disable-device-orientation", "disable-extensions",
					"disable-webgl", "no-default-browser-check");*/

			DesiredCapabilities capabilities = new DesiredCapabilities(
					DesiredCapabilities.chrome());
			
			
			//capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			//capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		System.setProperty("webdriver.chrome.driver", "D:\\Chromedriver\\chromedriver.exe") ;
		driver = new ChromeDriver(capabilities);
		}		
		isBrowserOpened=true;
		String waitTime=CONFIG.getProperty("default_implicitWait");
		//Thread.sleep(10000);
		driver.manage().window().maximize();
		
	    driver.manage().timeouts().implicitlyWait(Long.parseLong(waitTime), TimeUnit.SECONDS);
	
	}
 	}
	
	public void WaitUntil_element_tobe_clicked(String xpathKey,int Time)throws Exception
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, Time); 
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(OR.getProperty(xpathKey)))); 
		}
		catch (Exception e) 
		{			
			// reports		
			ErrorUtil.addVerificationFailure(e);		
			APP_LOGS.debug("Could not wait until element to be clicked"+xpathKey);		
			Reporter.log("Could not wait until element to be clicked"+xpathKey);	
			throw new Exception("Failed:Could not wait until element to be clicked"+xpathKey);
	}
	}
	public void WaitUntil_Presenceof_ElementLocated(String xpathKey,int Time)throws Exception
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, Time); 
		wait.until(ExpectedConditions.presenceOfElementLocated((By.xpath(OR.getProperty(xpathKey))))); 
		}
		catch (Exception e) 
		{			
			// reports		
			ErrorUtil.addVerificationFailure(e);		
			APP_LOGS.debug("Could not wait until element to be present"+xpathKey);		
			Reporter.log("Could not wait until element to be present"+xpathKey);	
			throw new Exception("Failed:Could not wait until element to be present in the page"+xpathKey);
	}
	}
	public void WaitUntil_element_Visible(String xpathKey,int Time)throws Exception
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, Time); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(OR.getProperty(xpathKey))));
		}
		catch (Exception e) 
		{			
			// reports		
			ErrorUtil.addVerificationFailure(e);		
			APP_LOGS.debug("Could not wait until element is Visible"+xpathKey);		
			Reporter.log("Could not wait until element is Visible"+xpathKey);	
			throw new Exception("Failed:Could not wait until element is Visible"+xpathKey);
	}
	}
	
//Mobile Testing	
	public void Firefoxprofile()
	{		
		profile=new  FirefoxProfile();
		profile.setPreference("general.useragent.override", "iPhone");
		driver = new FirefoxDriver(profile);
		String waitTime=CONFIG.getProperty("default_implicitWait");
		//Thread.sleep(10000);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Long.parseLong(waitTime), TimeUnit.SECONDS);

		}

	//Download Files
	
public void Firefoxprofile2(){
		
		profile = new  FirefoxProfile();
		profile.setPreference("browser.download.dir", "D:\\WebDriverdownloads");
	    profile.setPreference("browser.download.folderList",2);
	    profile.setPreference("browser.download.manager.showWhenStarting",false);
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk","application/vnd.ms-excel");

		driver = new FirefoxDriver(profile);
		String waitTime=CONFIG.getProperty("default_implicitWait");
		//Thread.sleep(10000);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Long.parseLong(waitTime), TimeUnit.SECONDS);

		}

public void FirefoxDeafultprofile(){
	
	ProfilesIni profile = new ProfilesIni();

	FirefoxProfile myprofile = profile.getProfile("default");

	driver = new FirefoxDriver(myprofile);
	String waitTime=CONFIG.getProperty("default_implicitWait");
	//Thread.sleep(10000);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Long.parseLong(waitTime), TimeUnit.SECONDS);

	}

public void openBrowser_3()
{
ProfilesIni profile = new ProfilesIni();
FirefoxProfile myprofile = profile.getProfile("default");
driver = new FirefoxDriver(myprofile);
String waitTime = CONFIG.getProperty("default_implicitWait");
//Thread.sleep(10000);
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(Long.parseLong(waitTime), TimeUnit.SECONDS);
}

public void openBrowser_4()
{
ProfilesIni profile = new ProfilesIni();
FirefoxProfile myprofile = profile.getProfile("default");
driver = new FirefoxDriver(myprofile);
String waitTime=CONFIG.getProperty("default_implicitWait");
//Thread.sleep(10000);
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(Long.parseLong(waitTime), TimeUnit.SECONDS);
}

	
//Mobile Testing	
	public void openBrowser_2()
	{
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("general.useragent.override","Mozilla/5.0 (Linux;U; Android 2.3.1; en-gb; Nexus S Build/GRH78) AppleWebKit/533.1 (KHTML,like Gecko) Version/4.0 Mobile Safari/533.1");
		 driver = new FirefoxDriver(profile);
	}
	
	public boolean LoginVEOPersonalisation(String xpath1, String xpath2, String xpath3,				
			String xpath4, String uname, String pwd) throws Throwable,Exception {		
		try {			
			driver.manage().window().maximize();		
			driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();		
			driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
			APP_LOGS.debug("Entered Username");		
			Reporter.log("Entered Username");	
			
			driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();		
			driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);	
			APP_LOGS.debug("Entered Password");		
			Reporter.log("Entered Password");		
			
			driver.findElement(By.xpath(OR.getProperty(xpath3))).click();	
			APP_LOGS.debug("Selecting Language");		
			Reporter.log("Selecting Language");	
			
			Thread.sleep(3000);		
			driver.findElement(By.xpath(OR.getProperty(xpath4))).click();	
			APP_LOGS.debug("Clicking Loginbutton");		
			Reporter.log("Clicking Loginbutton");	
					
			boolean HomePageHeader = driver.findElement(By.xpath(OR.getProperty("VEO_Home"))).isDisplayed();		
			 if(HomePageHeader==true) 		
			  {		
		     	highlightElement("VEO_Home");		
		        APP_LOGS.debug("Login Successfully as validation of Home in Homepage is Passed");			
		        Reporter.log("Login Successfully as validation of Home in Homepage is Passed");			
		       }			
					
		} catch (Exception e) 
		{			
			// reports		
			ErrorUtil.addVerificationFailure(e);		
			APP_LOGS.debug("Failed:Login Failed for HMC to Validate Personalisation");		
			Reporter.log("Failed:Login Failed for HMC to Validate Personalisation");	
			throw new Exception("Failed:Login Failed for HMC to Validate Personalisation");
					
			//return false;		
		}			
		APP_LOGS.debug("LOGIN Successful");
		Reporter.log("LOGIN Successful");
		return true;			
	}				
							

public void Ok_Excel() throws AWTException, InterruptedException
{
Robot object=new Robot();
Thread.sleep(3000);
object.keyPress(KeyEvent.VK_ALT);
object.keyPress(KeyEvent.VK_S);
object.keyRelease(KeyEvent.VK_ALT);
object.keyRelease(KeyEvent.VK_S);
// Press Enter
object.keyPress(KeyEvent.VK_ENTER);
// Release Enter
object.keyRelease(KeyEvent.VK_ENTER);
	
}
	//Launch url
	public void LaunchUrl(){
		try{
		driver.get(CONFIG.getProperty("testSiteName"));
		}catch(Throwable t){
			ErrorUtil.addVerificationFailure(t);
			APP_LOGS.debug("Unable to Launch URL");
			Reporter.log("Unable to Launch URL");
	}
		APP_LOGS.debug("Launched URL");
		Reporter.log("Launched URL");
		System.out.println("Launched URL");
	}	
	
		
	// close browser
	public void closeBrowser() 
	{
		try
		{
		driver.quit();
		isBrowserOpened=false;
		}
		catch(Throwable t)
		{
			ErrorUtil.addVerificationFailure(t);
			APP_LOGS.debug("Close Browser Failed : Not able to close the Browser");
			Reporter.log("Close Browser Failed : Not able to close the Browser");
			//throw t;
	    }
	}
	
	// compare titles
		public boolean compareTitle(String expectedVal)throws Throwable{
			try{
				Assert.assertEquals(driver.getTitle() , expectedVal);
				APP_LOGS.debug("Expected Title is"+" "+driver.getTitle());
				Reporter.log("Expected Title is"+" "+driver.getTitle());
				}catch(Throwable t){
					ErrorUtil.addVerificationFailure(t);			
					APP_LOGS.debug("Titles do not match as Expected"+"  "+ "displaying in application as" +driver.getTitle());
					Reporter.log("Titles do not match as Expected"+"  "+ "displaying in application as" +driver.getTitle());
					throw new Exception("Titles do not match as Expected"+"  "+ "displaying in application as" +driver.getTitle(),t);
					
				}
			APP_LOGS.debug("Titles  match"+" "+driver.getTitle());
			Reporter.log("Titles  match"+" "+driver.getTitle());
			return true;
		}
		// compaerStrings
		// compare titles
			public boolean compareNumbers(int expectedVal, int actualValue){
				try{
					Assert.assertEquals(actualValue,expectedVal   );
					}catch(Throwable t){
						ErrorUtil.addVerificationFailure(t);
						APP_LOGS.debug("Values do not match");
						Reporter.log("Values do not match");
						return false;
					}
				return true;
			}
			
			public boolean compareOrders(Double expectedVal, Double actualValue) throws Exception{
				try{
					Assert.assertEquals(actualValue,expectedVal   );
					}catch(Throwable t){
						ErrorUtil.addVerificationFailure(t);
						
						APP_LOGS.debug("Values do not match"+"******************* "+" "+expectedVal);
						Reporter.log("Values do not match"+"******************* "+" "+expectedVal);
						return false;
					}
				APP_LOGS.debug("Values match"+" "+"******************** "+" "+expectedVal);
				Reporter.log("Values match"+" "+"******************** "+" "+expectedVal);
				return true;
			}
			
			public boolean compareOrderss(String expectedVal, Double actualValue){
				try{
					Assert.assertEquals(actualValue,expectedVal   );
					}catch(Throwable t){
						ErrorUtil.addVerificationFailure(t);		
						APP_LOGS.debug("Values do not match"+" "+expectedVal);
						Reporter.log("Values do not match"+" "+expectedVal);
						APP_LOGS.debug("***************************************************");
						Reporter.log("***************************************************");
						return false;
					}
				APP_LOGS.debug("Text match"+" "+expectedVal);
				Reporter.log("Text match"+" "+expectedVal);
				APP_LOGS.debug("***************************************************");
				Reporter.log("***************************************************");
				return true;
			}
		
			
			public boolean checkElementPresence(String xpathKey) throws IOException,Throwable,Exception{
				int count = driver.findElements(By.xpath(OR.getProperty(xpathKey))).size();				
				try{
				Assert.assertTrue(count>0, "element present");
				}catch(Throwable t){
					ErrorUtil.addVerificationFailure(t);			
					capturescreenshot(this.getClass().getSimpleName() + "_" + count);
					//Assert.assertEquals(Invalid, xpathKey);
					//Assert.assertNotSame(Invalid, xpathKey);
					APP_LOGS.debug("Not Able to find the Element "+" "+"________________"+" to do further validations"+xpathKey);
					Reporter.log("Not Able to find the Element "+" "+"________________"+"to do further validations"+xpathKey);
					APP_LOGS.debug("***************************************************");
					Reporter.log("***************************************************");					
					throw new Exception("Not Able to find the Element "+" "+ xpathKey+ "to do further validations",t);
					//return false;
				}
				APP_LOGS.debug("Element Present"+" "+"________________"+" "+xpathKey);
				Reporter.log("Element Present"+" "+"________________"+" "+xpathKey);
				APP_LOGS.debug("***************************************************");
				Reporter.log("***************************************************");
				return true;
			}	
			
			
			// your own functions

			
			
			
			
public boolean checkText(String xpathKey, String expectedVal) throws Throwable 
{
	   String actual = driver.findElement(By.xpath(OR.getProperty(xpathKey))).getText();	
		   
	   try 
		{		
		//System.out.println(actual.trim());
		//System.out.println(expectedVal.trim());
		String actual2 = actual.trim().replaceAll("[^a-zA-Z]","");
		String expectedVal2 = expectedVal.trim().replaceAll("[^a-zA-Z]","");
		Thread.sleep(3000);
		Assert.assertTrue(actual2.trim().equalsIgnoreCase(expectedVal2));
		    } 
		catch (Throwable t) 
		{
			ErrorUtil.addVerificationFailure(t);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			// Assert.assertEquals(Invalid, xpathKey);
			APP_LOGS.debug("TEXT do not match" + " " + "__________" + " "+ "Text displaying in application as" + " " +actual+ " "
					+ "Text Expected is" + " " +expectedVal.toString());
			Reporter.log("TEXT do not match" + " " + "__________" + " "
					+ "Text displaying in application as" + "   " + actual + " "
					+ "Text Expected is" + " " + expectedVal.toString());
			APP_LOGS.debug("***************************************************");
			Reporter.log("***************************************************");
			throw new Exception("Failed : TEXT do not match" + " "
					+ "Text displaying in application as" + "   " + actual + " "
					+ "Text Expected is" + " " + expectedVal.toString(), t);
			// return false;
		}
		prntResults("Text match" + " "
				+ "_____________________________________" + " " + expectedVal);
		prntResults("***************************************************");
		return true;
}




			
			public boolean checkAttributevalue(String xpathKey,String expectedVal) throws IOException, InterruptedException,Throwable{
				String actual = driver.findElement(By.xpath(OR.getProperty(xpathKey))).getAttribute("value");
				APP_LOGS.debug(actual);
				Reporter.log(actual);
				try
				{
					Assert.assertTrue(actual.trim().equalsIgnoreCase(expectedVal));
				}
				catch(Throwable t)
				{
						ErrorUtil.addVerificationFailure(t);
							
						APP_LOGS.debug("TEXT do not match"+" "+"__________"+" " + "dispalying" +" " + actual+ "expected is" +" " + xpathKey);
						Reporter.log("TEXT do not match"+" "+"__________"+" " + "dispalying" +" " + actual+ "expected is" +" " + xpathKey);
						APP_LOGS.debug("***************************************************");
						Reporter.log("***************************************************");
						throw new Exception("Failed : TEXT do not match"+" "+"__________"+" " + "dispalying in application as" +" " + actual,t);		
						//return false;
				}
				APP_LOGS.debug("Text match"+" "+"_____________________________________"+" "+ expectedVal);
				Reporter.log("Text match"+" "+"_____________________________________"+" "+ expectedVal);
				
				APP_LOGS.debug("***************************************************");
				Reporter.log("***************************************************");
				return true;
			}
		
			
			public boolean checkTextx(String xpathKey,String xpathKey1) throws Exception{
				String actual=driver.findElement(By.xpath(OR.getProperty(xpathKey))).getText();
				String expectedVal=driver.findElement(By.xpath(OR.getProperty(xpathKey1))).getText();
				try{
					Assert.assertEquals(actual.trim().equalsIgnoreCase(actual) , expectedVal.trim().equalsIgnoreCase(actual)   );
					}catch(Throwable t){
						ErrorUtil.addVerificationFailure(t);	
						APP_LOGS.debug("TEXT do not match"+" "+"_______________________"+" "+actual);
						Reporter.log("TEXT do not match"+" "+"_______________________"+" "+actual);
						APP_LOGS.debug("***************************************************");
						Reporter.log("***************************************************");
						return false;
					}
				APP_LOGS.debug("Text match"+" "+"_____________________________________"+" "+expectedVal);
				Reporter.log("Text match"+" "+"_____________________________________"+" "+expectedVal);
				APP_LOGS.debug("***************************************************");
				Reporter.log("***************************************************");
				return true;
			}
			
			
			public boolean Mousehover_click (String xpathKey) throws IOException, InterruptedException,Throwable
			 { 
				try{
			  //Generate mouse hover event on main menu to click on sub menu
			  Actions action = new Actions(driver);
			  WebElement moveonmenu = driver.findElement(By.xpath(OR.getProperty(xpathKey)));
			 
				action.moveToElement(moveonmenu).click(moveonmenu).build().perform();
				APP_LOGS.debug("MouseHover Click on " + xpathKey);
				Reporter.log("MouseHover Click on " + xpathKey);
				}
				catch(Throwable t)
				{
					hightlightscreenshot(xpathKey);
					ErrorUtil.addVerificationFailure(t);
					APP_LOGS.debug("Not able to mousehover click on--  " + xpathKey);
					Reporter.log("Not able to mousehover click on--  " + xpathKey);
					throw new Exception("Failed:Not able to mousehover click on--  " + xpathKey ,t);					
				}
				return true;
				}
	      
			public static void highlightElement(String xpathKey) throws InterruptedException, IOException,Throwable {
				 try {
					 Thread.sleep(2000);
	              JavascriptExecutor js = (JavascriptExecutor)driver;
	              WebElement element = driver.findElement(By.xpath(OR.getProperty(xpathKey)));    
	                     for (int i = 0; i < 2; i++) 
	                     {
	                           js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
	                           element, "color: red; border: 5px solid red;");	                           
	                           Thread.sleep(2000);
	                           js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
	                           element, "");
	                           Thread.sleep(2000);
	                       	APP_LOGS.debug("Highlighted respective selected element  " + xpathKey );
	     					Reporter.log("Highlighted respective selected element    " +xpathKey);
	                     }	
				 }
	                     catch(Throwable t)
	     				{
	     	        	    ErrorUtil.addVerificationFailure(t);		
	     					APP_LOGS.debug("Not able to highlight respective element" + xpathKey );
	     					Reporter.log("Not able to highlight  respective element" +xpathKey);
	     					 throw new Exception("Failed:Not able to highlight element with key -- " +xpathKey ,t);
	     				}
	     	       
	       }
	       public void hightlightscreenshot(String xpathKey) throws IOException, InterruptedException,Throwable {
	    	   try {
	   		JavascriptExecutor js=(JavascriptExecutor)driver;
	   	    WebElement element = getObject(xpathKey);           
	           for (int i = 0; i < 3; i++) {
	                 js.executeScript("arguments[0].setAttribute('style', arguments[1]);",element, "color: red; border: 5px solid red;");
	                 File screenshot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	                 //FileUtils.copyFile(screenshot, new File("E:\\Testing_Dyn_Nan\\Core_Framework_TestNG_Webdriver\\screenshots"));
	                 Thread.sleep(2000);
	                 js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
	                 element, "");
	   		//File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	   		FileUtils.copyFile(screenshot, new File(System.getProperty("user.dir")+"\\screenshots\\" + this.getClass().getSimpleName() + "_"+ count + ".jpg"));
	       
	           }
	    	   }
	           catch(Throwable t)
				{
	        	    ErrorUtil.addVerificationFailure(t);		
					APP_LOGS.debug("Not able to highlight and take screenshot -- " +xpathKey);
					Reporter.log("Not able to highlight and take screenshot -- " +xpathKey);
					 throw new Exception("Not able to highlight and take screenshot -- " +xpathKey ,t);
				}
	       }
	       public boolean CheckImage(String xpathKey) throws Exception, Throwable {
	   		try
	   		{
	   		WebElement ImageFile = driver.findElement((By.xpath(OR.getProperty(xpathKey))));
	   		Boolean ImagePresent = (Boolean) ((JavascriptExecutor) driver).executeScript("return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0",ImageFile);
	   		if (!ImagePresent)
	   		{
	   			//System.out.println("Image not displayed.");
	   			APP_LOGS.debug("Couldnot find the image" + xpathKey);
	   			Reporter.log("Couldnot find the image" + xpathKey);
	   		}
	   		}
	   		catch(Throwable t)
	   		{
	   			ErrorUtil.addVerificationFailure(t);
	   			APP_LOGS.debug("Couldnot find the image" + xpathKey);
	   			Reporter.log("Couldnot find the image" + xpathKey);
	   		 throw new Exception("Couldnot find the image" + xpathKey ,t);
	   		}
	   		APP_LOGS.debug("Validating image present or not:PASSED   "+xpathKey);
	   		Reporter.log("Validating image present or not:PASSED   "+xpathKey);
	   		return true;
	       }
	       
	       public boolean NotEditable(String xpathKey)throws Throwable
	   	{
		try {
			boolean value = false;
			if (!driver.findElement(By.xpath(OR.getProperty(xpathKey))).isEnabled()) 
				
			{
				
				value = true;				
			}
			prntResults("Selected Element  " + xpathKey + " is Not Editable");	
			return value;
			
		} catch (Throwable t) {
			ErrorUtil.addVerificationFailure(t);
			APP_LOGS.debug("Selected Element is Editable" + xpathKey);
			Reporter.log("Selected Element is Editable" + xpathKey);
			 throw new Exception("Selected Element is Editable" + xpathKey ,t);
		}

	}			
			
			public boolean  Menu(String xpath1,String xpath2)throws Throwable{
				try{
				driver.findElement(By.xpath(OR.getProperty(xpath1))).click();
				APP_LOGS.debug("***********************************clicked on" + xpath1 + "***********************************");
				Reporter.log("***********************************clicked on" + xpath1 + "***********************************");
				if(WaitForObjectAvailability(xpath2))
				{
				driver.findElement(By.xpath(OR.getProperty(xpath2))).click();
				APP_LOGS.debug("***********************************clicked on" + xpath2 + "***********************************");
				Reporter.log("***********************************clicked on" + xpath2 + "***********************************");
				}
				}
				catch(Throwable t)
				{
					ErrorUtil.addVerificationFailure(t);	
					APP_LOGS.debug("Clicking on Menu and Submenu "  +xpath1+" and " + xpath2 +  " got Failed");
					Reporter.log("Clicking on Menu and Submenu " +xpath1+" and " + xpath2 + " got Failed");
					 throw new Exception("Clicking on Menu and Submenu "  +xpath1+ xpath2 +  " got Failed" ,t);	
				}
			APP_LOGS.debug("Able to click on "+ xpath1+ "and"+ xpath2);
			Reporter.log("Able to click on"+ xpath1+ "and"+ xpath2);
			return true;
		}
			
	public boolean Login(String xpath1, String xpath2, String xpath3,
			String xpath4, String uname, String pwd) throws Throwable,Exception {
		try {
			driver.manage().window().maximize();
			
			WaitForObjectAvailability(xpath1);
			
			driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
			driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
			APP_LOGS.debug("Entered the Username");
			Reporter.log("Entered the Username");
			
			

			WaitForObjectAvailability(xpath2);
			
			driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
			driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
			APP_LOGS.debug("Entered the Password");
			Reporter.log("Entered the Password");
			
			

			WaitForObjectAvailability(xpath3);
			driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
			System.out.println("clicked on checkbox");
			APP_LOGS.debug("clicked on checkbox");
			Reporter.log("clicked on checkbox");
			
			
			//Thread.sleep(3000);
			WaitForObjectAvailability (xpath4);
			
				driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
				APP_LOGS.debug("clicked on LoginButton");
				Reporter.log("clicked on LoginButton");
			
			//Thread.sleep(3000);
			/**/
			if(WaitForObjectAvailability("StoreFront_HomePage_Menu_Button"))
			{
			 int submitbuttonPresence = driver.findElement(By.xpath(OR.getProperty("StoreFront_HomePage_Menu_Button"))).getSize().getWidth();// .isDisplayed();
			
			 //if(submitbuttonPresence==true) 
			 if (submitbuttonPresence >0)
			 {
		              System.out.println("True");
		              APP_LOGS.debug("Loggedin Successfully as validation of Glosary in Homepage is Passed");
				   Reporter.log("Loggedin Successfully as validation of Glosary in Homepage is Passed");
		     }
			 }
			
		
		} catch (Exception e) {
			// reports
			ErrorUtil.addVerificationFailure(e);
			APP_LOGS.debug("Failed: Failed to Login Storefront");
			Reporter.log("Failed: Failed to Login Storefront");
			 throw new Exception("Failed: Failed to Login Storefront" ,e);	
			 //return false;
		}
		APP_LOGS.debug("LOGIN Successful");
		Reporter.log("LOGIN Successful");
		return true;
	}
	
//Duplicated one used when First Login was not working
			public boolean Login_Mobile(String xpath1,String xpath2,String xpath3,String xpath4,String uname,String pwd) throws Throwable
			{
		        try
		        {
					driver.manage().window().maximize();
					driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
					APP_LOGS.debug("Entered the Username");
					Reporter.log("Entered the Username");
					driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
					APP_LOGS.debug("Entered the Password");
					Reporter.log("Entered the Password");
					driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
					System.out.println("clicked on checkbox");
					APP_LOGS.debug("clicked on checkbox");
					Reporter.log("clicked on checkbox");
					Thread.sleep(3000);
					driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
					APP_LOGS.debug("clicked on LoginButton");
					Reporter.log("clicked on LoginButton");
					
					FirstCloseButton();
					 
					 boolean contactPresence = driver.findElement(By.xpath(OR.getProperty("Mobile_Homepage_Contact"))).isDisplayed();
								  if(contactPresence==true) 
					   {
				             System.out.println("True");
				              APP_LOGS.debug("Loggedin Successfully as validation of contact label in Homepage is Passed");
							   Reporter.log("Loggedin Successfully as validation of contact label in Homepage is Passed");
				        }
				
				} catch (Exception e) {
					// reports
					ErrorUtil.addVerificationFailure(e);
					APP_LOGS.debug("Failed: Failed to Login Mobile");
					Reporter.log("Failed: Failed to Login Mobile");
					 throw new Exception("Failed: Failed to Login Mobile" ,e);	
					 //return false;
				}
				APP_LOGS.debug("LOGIN Successful");
				Reporter.log("LOGIN Successful");
				return true;
			}
	
	//Login for BACKOFFICE	
			public boolean LoginBackOffice(String xpath1,String xpath2,String xpath3,String uname,String pwd) throws Throwable{
				try{
					driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
					Thread.sleep(3000);
					APP_LOGS.debug("Entered the Username");
					Reporter.log("Entered the Username");
					driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
					Thread.sleep(5000);
					APP_LOGS.debug("Entered the Password");
					Reporter.log("Entered the Password");
					driver.findElement(By.cssSelector("body")).sendKeys(Keys.TAB);
					Thread.sleep(2000);
					APP_LOGS.debug("Clicked on TAB");
					Reporter.log("Clicked on TAB");
					driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
					APP_LOGS.debug("Clicked on Login button");
					Reporter.log("Clicked on Login Button");
					Thread.sleep(7000);
					boolean submitbuttonPresence = driver.findElement(By.xpath(OR.getProperty("Backoffice_RefreshButton"))).isDisplayed();
					 if(submitbuttonPresence==true) 
					  {
						           System.out.println("True");
					            highlightElement("Backoffice_RefreshButton");
					             APP_LOGS.debug("Loggedin Successfully as validation of Refresh Button in Homepage is Passed");
					              Reporter.log("Loggedin Successfully as validation of Refresh Button in Homepage is Passed");
					       }
									
				}catch(Throwable t){
					//reports
					ErrorUtil.addVerificationFailure(t);			
					APP_LOGS.debug("Failed: Failed to Login Backoffice");
					Reporter.log("Failed: Failed to Login Backoffice");
					 throw new Exception("Failed: Failed to Login Backoffice" ,t);	
				}
			APP_LOGS.debug("LOGIN Successful");
			Reporter.log("LOGIN Successful");
			return true;
		}		
			
			
	//Login for InfoCockpit		
			
			public boolean Logininfocockpit(String xpath1,String xpath2,String xpath3,String uname,String pwd) throws Throwable{
				try{
					driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
					Thread.sleep(3000);	
					APP_LOGS.debug("Entered the Username");
					Reporter.log("Entered the Username");
					driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
					Thread.sleep(3000);
					APP_LOGS.debug("Entered the Password");
					Reporter.log("Entered the Password");				
					driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
					APP_LOGS.debug("Clicked on LoginButton");
					Reporter.log("Clicked on LoginButton");	
					//APP_LOGS.debug("Log_out"+this.getClass().getSimpleName()+" clicked2");	*/
				}catch(Throwable t){
					//reports
					ErrorUtil.addVerificationFailure(t);	
					APP_LOGS.debug("Failed: Failed to Login Infocockpit");
					Reporter.log("Failed: Failed to Login Infocockpit");
					 throw new Exception("Failed: Failed to Login Infocockpit" ,t);
				}
			APP_LOGS.debug("LOGIN Successful");
			Reporter.log("LOGIN Successful");
			return true;
		}		
	
			//Login for Google
			
			public boolean LoginGoogle(String xpath1,String xpath2,String xpath3,String xpath4,String uname,String pwd) throws Throwable{
				try{
					driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
					Thread.sleep(3000);	
					APP_LOGS.debug("Entered the Username");
					Reporter.log("Entered the Username");
					driver.findElement(By.xpath(OR.getProperty(xpath2))).click();
					APP_LOGS.debug("Clicked Next button");
					Reporter.log("Clicked Next button");
					driver.findElement(By.xpath(OR.getProperty(xpath3))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath3))).sendKeys(pwd);
					Thread.sleep(3000);				
					APP_LOGS.debug("Entered the Password");
					Reporter.log("Entered the Password");
						
					driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
					APP_LOGS.debug("Clicked on Signin button");
					Reporter.log("Clicked on Signin button");
					 boolean PrivacypolicyPresence = driver.findElement(By.xpath(OR.getProperty("GoogleAnalytics_AfterLogin_ValidatePrivacyPolicyLink"))).isDisplayed();
                     if(PrivacypolicyPresence==true)
                {
                           highlightElement("GoogleAnalytics_AfterLogin_ValidatePrivacyPolicyLink");
                            APP_LOGS.debug("Loggedin Successfully as validation of Home in Homepage is Passed");
                           Reporter.log("Loggedin Successfully as validation of Home in Homepage is Passed");
             }
      
       } catch (Exception e) {
              // reports
              ErrorUtil.addVerificationFailure(e);
              APP_LOGS.debug("Failed: Failed to Login GoogleAnalyticsPage");
              Reporter.log("Failed: Failed to Login GoogleAnalyticsPage");
              throw new Exception("Failed: Failed to Login GoogleAnalyticsPage" ,e);
              //return false;
       }
       APP_LOGS.debug("LOGIN Successful");
       Reporter.log("LOGIN Successful");
       return true;
} 
			
		//Login for HMC
			public boolean LoginHMC(String xpath1, String xpath2,
		              String xpath3, String uname, String pwd) throws Throwable,Exception {
		       try {
		    	      driver.manage().deleteAllCookies();
		    	      driver.navigate().refresh();
		              driver.manage().window().maximize();
		              
		              Thread.sleep(4000);
		              driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
		              driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
		              APP_LOGS.debug("Entered the Username");
						Reporter.log("Entered the Username");
		              driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
		              driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
		              Thread.sleep(3000);
		              APP_LOGS.debug("Entered the Password");
						Reporter.log("Entered the Password");
		              driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
		              APP_LOGS.debug("Clicked on Login Button");
						Reporter.log("Clicked on Login Button");
		         
				       Thread.sleep(5000);
				       
				       highlightElement("HMC_Home");
		               boolean HomebuttonPresence = driver.findElement(By.xpath(OR.getProperty("HMC_Home"))).isDisplayed();
		                     if(HomebuttonPresence==true)
		                {
		                           highlightElement("HMC_Home");
		                           Thread.sleep(5000);
		                           APP_LOGS.debug("Loggedin Successfully as validation of Home in Homepage is Passed");
		                           Reporter.log("Loggedin Successfully as validation of Home in Homepage is Passed");
		             }
		      
		       } catch (Exception e) 
		       {
		              // reports
		              ErrorUtil.addVerificationFailure(e);
		              APP_LOGS.debug("Failed: Failed to Login HMC");
		              Reporter.log("Failed: Failed to Login HMC");
		              throw new Exception("Failed: Failed to Login HMC" ,e);
		              //return false;
		       }
		       APP_LOGS.debug("LOGIN Successful");
		       Reporter.log("LOGIN Successful");
		       return true;
		} 
			
			public void switchToTab()throws Exception 
			{
				try
				{
				  //Switching between tabs using CTRL + tab keys.
				  driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"\t");				 
				  //Switch to current selected tab's content.
				  driver.switchTo().defaultContent();  
				    APP_LOGS.debug("Switching to new window tab");
					Reporter.log("Switching to new window tab");
				}
				  catch (Exception e) 
			       {
			              // reports
			              ErrorUtil.addVerificationFailure(e);
			              APP_LOGS.debug("Failed to switch to new tab and Failed to navigate to ValidationPage");
			              Reporter.log("Failed to switch to new tab and Failed to navigate to ValidationPage");
			              throw new Exception("Failed: Failed to switch to new tab and Failed to navigate to ValidationPage" ,e);
			              //return false;
			              }
				 }	

	public boolean LoginClerk(String xpath1, String xpath2, String xpath3,
			String xpath4, String uname, String pwd) throws Throwable,
			Exception {
		try {
			driver.manage().window().maximize();
			driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
			driver.findElement(By.xpath(OR.getProperty(xpath1)))
					.sendKeys(uname);
			 APP_LOGS.debug("Entered the Username");
				Reporter.log("Entered the Username");
			driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
			driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
			    APP_LOGS.debug("Entered the Password");
				Reporter.log("Entered the Password ");
			driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
			System.out.println("clicked on checkbox");
			  APP_LOGS.debug("clicked on checkbox");
				Reporter.log("clicked on checkbox ");
			Thread.sleep(3000);
			driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
			APP_LOGS.debug("clicked on Loginbutton");
			Reporter.log("clicked on Loginbutton ");
			boolean submitbuttonPresence = driver.findElement(
					By.xpath(OR.getProperty("Glosary"))).isDisplayed();
			if (submitbuttonPresence == true) {
				System.out.println("True");
				APP_LOGS.debug("Login Successfully as validation of Glosary in Homepage is Passed");
				Reporter.log("Login Successfully as validation of Glosary in Homepage is Passed");
			}

		} catch (Exception e) {
			// reports
			ErrorUtil.addVerificationFailure(e);
			APP_LOGS.debug("Failed: Login Failed for Clerk_Login");
			Reporter.log("Failed: Login Failed for Clerk__Login");
			throw new Exception("Failed: Login Failed for Clerk_Login" ,e);
			// return false;
		}
		APP_LOGS.debug("LOGIN Successful");
		Reporter.log("LOGIN Successful");
		return true;
	}

			public boolean Mobile_LoginClerk(String xpath1,String xpath2,String xpath3,String xpath4,String uname,String pwd) throws Throwable
			{
		        try
		        {
					driver.manage().window().maximize();
					driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
					APP_LOGS.debug("Entered the Username");
					Reporter.log("Entered the Username");
					driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
					  APP_LOGS.debug("Entered the Password");
						Reporter.log("Entered the Password ");
				 int i = driver.findElements(By.xpath(".//*[@id='clerkLogin']/div[4]/div/div")).size();
				 
					if (i == 0) 
					{
						System.out.println("Element is not present");
						Thread.sleep(3000);
						driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
						  APP_LOGS.debug("Clicked on Login Button");
							Reporter.log("Clicked on Login Button");
						Thread.sleep(3000);
					} else {
						System.out.println("Element is present");
						Thread.sleep(3000);
						//driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(Keys.TAB);
						//System.out.println("TABBBBBBBBBBBB");
						highlightElement(xpath3);
						driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
						System.out.println("clicked on checkbox");
						 APP_LOGS.debug("clicked on checkbox");
							Reporter.log("clicked on checkbox");
						Thread.sleep(3000);
						driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
						APP_LOGS.debug("clicked on Login Button");
						Reporter.log("clicked on Login Button");
					}
					Thread.sleep(1000);
					
				} catch (Throwable t) {
					// reports
					ErrorUtil.addVerificationFailure(t);
					APP_LOGS.debug("Failed: Login Failed for Clerk_Mobile_Login");
					Reporter.log("Failed: Login Failed for Clerk_Mobile_Login");
					throw new Exception("Failed: Login Failed for Clerk_Mobile_Login" ,t);
				}
				APP_LOGS.debug("LOGIN Successful");
				Reporter.log("LOGIN Successful");
				return true;
			}
		
			public boolean LoginCheckout_Drools(String xpath1,String xpath2,String xpath3,String uname,String pwd) throws Exception,Throwable{
				try{
				driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
				driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
				Thread.sleep(1000);
				APP_LOGS.debug("Entered the Username");
				Reporter.log("Entered the Username");
				driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
				driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
				Thread.sleep(1000);
				APP_LOGS.debug("Entered the Password");
				Reporter.log("Entered the Password");
				driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
				APP_LOGS.debug("Clicked on Login Button");
				Reporter.log("Clicked on Login Button");
				//APP_LOGS.debug("Loggedin"+this.getClass().getSimpleName()+" clicked");
				boolean DroolPresence = driver.findElement(
						By.xpath(OR.getProperty("CheckoutDrools_KnowledgeBase"))).isDisplayed();
				if (DroolPresence == true) 
				{
					System.out.println("True");
					APP_LOGS.debug("Loggedin Successfully as validation of CheckoutDrools_KnowledgeBase in Homepage is Passed");
					Reporter.log("Loggedin Successfully as validation of CheckoutDrools_KnowledgeBase in Homepage is Passed");
				}
			} catch (Exception e) {
				// reports
				ErrorUtil.addVerificationFailure(e);
				APP_LOGS.debug("Login Failed");
				Reporter.log("Login failed");
				throw new Exception("Failed: Login Failed for BRMS" ,e);
				// return false;
			}
			APP_LOGS.debug("LOGIN Successful");
			Reporter.log("LOGIN Successful");
			return true;
		}
			
			public boolean LoginBRMS(String xpath1,String xpath2,String xpath3,String uname,String pwd) throws Exception,Throwable{
				try{
				driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
				driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
				Thread.sleep(1000);
				APP_LOGS.debug("Entered the Username");
				Reporter.log("Entered the Username");
				driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
				driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
				Thread.sleep(1000);
				APP_LOGS.debug("Entered the Password");
				Reporter.log("Entered the Password");
				driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
				APP_LOGS.debug("Clicked on Loginbutton");
				Reporter.log("Clicked on Loginbutton");
				//APP_LOGS.debug("Loggedin"+this.getClass().getSimpleName()+" clicked");
				boolean DroolPresence = driver.findElement(
						By.xpath(OR.getProperty("CheckoutDrools_KnowledgeBase"))).isDisplayed();
				if (DroolPresence == true) 
				{
					System.out.println("True");
					APP_LOGS.debug("Loggedin Successfully as validation of CheckoutDrools_KnowledgeBase in Homepage is Passed");
					Reporter.log("Loggedin Successfully as validation of CheckoutDrools_KnowledgeBase in Homepage is Passed");
				}
			} catch (Exception e) {
				// reports
				ErrorUtil.addVerificationFailure(e);
				APP_LOGS.debug("Login Failed");
				Reporter.log("Login Failed");
				throw new Exception("Failed: Login Failed for BRMS" ,e);
				// return false;
			}
			APP_LOGS.debug("LOGIN Successful");
			Reporter.log("LOGIN Successful");
			return true;
		}
		
			public boolean LoginProductCockpit(String xpath1,String xpath2,String xpath3,String xpath4,String uname,String pwd, String Language) throws 

			Exception,Throwable{
					try{
					driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
					Thread.sleep(3000);
					APP_LOGS.debug("Entered the Username");
					Reporter.log("Entered the Username");
					driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
					Thread.sleep(3000);
					APP_LOGS.debug("Entered the Password");
					Reporter.log("Entered the Password");					
					/*Select oSelect = new Select(driver.findElement(By.xpath(OR.getProperty(xpath3))));
					oSelect.selectByVisibleText(Language);*/
					
					driver.findElement(By.xpath(OR.getProperty(xpath3))).clear();
					driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
					driver.findElement(By.xpath(OR.getProperty(xpath3))).sendKeys(Language);
					Thread.sleep(3000);
					APP_LOGS.debug("selecting the Language"+Language);
					Reporter.log("selecting the Language"+Language);
					driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
					APP_LOGS.debug("Clicked on Login Button");
					Reporter.log("Clicked on Login Button");
					Thread.sleep(3000);	
					boolean submitbuttonPresence = driver.findElement(By.xpath(OR.getProperty("ProductManagement_HomePage_AllProducts"))).isDisplayed();
					 if(submitbuttonPresence==true) 
					  {
					            System.out.println("True");
					             APP_LOGS.debug("Loggedin Successfully as validation of AllProducts in Homepage is Passed");
					  Reporter.log("Loggedin Successfully as validation of AllProducts in Homepage is Passed");
					       }
					}catch(Throwable t){
					//reports
					ErrorUtil.addVerificationFailure(t); 
					APP_LOGS.debug("Login failed");
					Reporter.log("Login failed");
					throw new Exception("Failed: Login Failed for ProductCockpit" ,t);
					}
					APP_LOGS.debug("LOGIN Successful");
					Reporter.log("LOGIN Successful");
					return true;
					} 
	
		
			public void click(String xpathkey)throws Throwable{
				try{
				driver.findElement(By.xpath(OR.getProperty(xpathkey))).click();
				APP_LOGS.debug("clicked on the element " +xpathkey);
				Reporter.log("clicked on the element " +xpathkey);
				}catch(Throwable t){
					// report error
					ErrorUtil.addVerificationFailure(t);
					APP_LOGS.debug("Couldnot find the element " +xpathkey);
					Reporter.log("Couldnot find the element  " +xpathkey);
					throw new Exception("Failed: Couldnot find the element  "+ xpathkey ,t);
				}
				
				}
			
			
			
           public void Input(String xpathKey,String input)throws Throwable {
				
				try{
				 driver.findElement(By.xpath(OR.getProperty(xpathKey))).sendKeys(input);
				 APP_LOGS.debug("Sending the input data for " +xpathKey);
					Reporter.log("Sending the input data for  " +xpathKey);
				}catch(Throwable t){
					// report error
					ErrorUtil.addVerificationFailure(t);
					APP_LOGS.debug("Couldnot find the element " +xpathKey);
					Reporter.log("Couldnot find the element  " +xpathKey);
					throw new Exception("Failed: Couldnot find the element  "+ xpathKey ,t);
				
				}
				
			}
			// getObjectByID(String id)
			
			public WebElement getObject(String xpathKey)throws Throwable{
				
				try{
					Thread.sleep(3000);
					//WaitForObjectAvailability(xpathKey);
				WebElement x = driver.findElement(By.xpath(OR.getProperty(xpathKey)));
				return x;
				}
			catch(Throwable t){
					// report error
				ErrorUtil.addVerificationFailure(t);
				APP_LOGS.debug("Couldnot find the element " +xpathKey);
				Reporter.log("Couldnot find the element  " +xpathKey);
				throw new Exception("Failed: Couldnot find the element  "+ xpathKey ,t);
				}
			}
				
			
             public WebElement getObjectName(String xpathKey)throws Throwable{
				
				try{
				WebElement x = driver.findElement(By.name(OR.getProperty(xpathKey)));
				return x;
				}catch(Throwable t){
					// report error
					ErrorUtil.addVerificationFailure(t);
					APP_LOGS.debug("Couldnot find the element " +xpathKey);
					Reporter.log("Couldnot find the element  " +xpathKey);
					throw t;
				}
				
			}
		
			
             public void capturescreenshot(String filename) throws IOException
 			
				//try
			//	{
					{
					File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\"+filename.substring(0, filename.indexOf('_'))+"\\"+filename+".jpg"));	}			
			
			//}
				//catch(Throwable t)
			//{
				//reports
			//	ErrorUtil.addVerificationFailure(t); 
			//	APP_LOGS.debug("Failed to CAPTURE SCREENSHOT ");
			//	Reporter.log("Failed to CAPTURE SCREENSHOT  ");
			//	throw t;
			//	}
			
			
			//***************************************************************************************************************//


public void logoutOperation() throws Throwable{
	
	getObject("Man_Ikon").click();
	APP_LOGS.debug("Man_Ikon"+this.getClass().getSimpleName()+" Passed");
	Reporter.log("Man_Ikon"+this.getClass().getSimpleName()+" Passed");
	
	
	//Click On Logout
	getObject("Log_out").click();
	APP_LOGS.debug("Log_out"+this.getClass().getSimpleName()+" Passed");	
	Reporter.log("Log_out"+this.getClass().getSimpleName()+" Passed");	
	APP_LOGS.debug("**************************************************************************************");
	Reporter.log("**************************************************************************************");
	APP_LOGS.debug("End Of 1st Iteration");
	Reporter.log("End Of 1st Iteration");
	
	
}



public static boolean isAlertPresent(WebDriver driver)throws Exception{
	 
    try{

    	Alert alert = driver.switchTo().alert();
		
		System.out.println(alert.getText());
		Thread.sleep(5000);
		alert.accept();
		
		System.out.println("Swicthed to Alert popup and Clicked on Button");
	    APP_LOGS.debug("Swicthed to Alert popup and Clicked on Button");
		Reporter.log("Swicthed to Alert popup and Clicked on Button");
        return true;

    }
    catch(NoAlertPresentException ex)
    {
    	System.out.println("Couldnot handle the Alert popup");
    	APP_LOGS.debug("Couldnot handle the Alert popup");
    	Reporter.log("Couldnot handle the Alert popup");
    	
    	throw new Exception("Failed: Couldnot handle the Alert popup",ex);

    }

}

//Login for CMS Cockpit
		public boolean LoginCMSCockpit(String xpath1,String xpath2,String xpath3,String xpath4,String uname,String pwd, String Language) throws Throwable{
		try{
		driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
		driver.findElement(By.xpath(OR.getProperty(xpath1))).sendKeys(uname);
		APP_LOGS.debug("Entered the Username");
  	Reporter.log("Entered the Username");
		Thread.sleep(3000);
		driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
		driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
		APP_LOGS.debug("Entered the Password");
  	Reporter.log("Entered the Password");
		Thread.sleep(3000);
			
		driver.findElement(By.xpath(OR.getProperty(xpath3))).clear();
		driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
		driver.findElement(By.xpath(OR.getProperty(xpath3))).sendKeys(Language);
		APP_LOGS.debug("Selected the Language as: "+Language);
  	Reporter.log("Selected the Language as: "+Language);
		Thread.sleep(3000);
		
		driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
		APP_LOGS.debug("Clicked on Login Button");
  	Reporter.log("Clicked on Login Button");
  	
		boolean submitbuttonPresence = driver.findElement(By.xpath(OR.getProperty("CMS_Menu"))).isDisplayed();
		 if(submitbuttonPresence==true) 
		  {
		            System.out.println("True");
		            APP_LOGS.debug("Loggedin Successfully as validation of Menu in Homepage is Passed");
		            Reporter.log("Loggedin Successfully as validation of Menu in Homepage is Passed");
		       }

		}
		catch(Throwable t){
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("LOGIN FAILED");
		Reporter.log("LOGIN FAILED");
		throw new Exception("Failed: Login Failed for CMSCockPit",t);
		}
		APP_LOGS.debug("LOGIN Successful");
		Reporter.log("LOGIN Successful");
		return true;
		}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------



public static void setClipboardData(String string) throws Throwable {
			try{
				StringSelection stringSelection = new StringSelection(string);
				Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
				Thread.sleep(3000);
				APP_LOGS.debug("Success: Copied the Path specified");
				Reporter.log("Success: Copied the Path specified");
			}
			catch(Throwable t){
				ErrorUtil.addVerificationFailure(t); 
				APP_LOGS.debug("Failed: Couldnot copy the Path specified");
				Reporter.log("Failed: Couldnot copy the Path specified");
				throw new Exception("Failed: Couldnot copy the Path specified", t);
			}
		}

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------

public void dragAndDrop(WebElement sourceElement, WebElement destinationElement) throws Throwable
		{
			try{
				(new Actions(driver)).dragAndDrop(sourceElement, destinationElement).perform();
				APP_LOGS.debug("Dragged and Dropped the element successfully");
				Reporter.log("Dragged and Dropped the element successfully");
			}
			
			catch(Throwable t){
				ErrorUtil.addVerificationFailure(t); 
				APP_LOGS.debug("Failed: Couldnot drag and drop the selected Elements");
				Reporter.log("Failed: Couldnot drag and drop the selected Elements");
				throw new Exception("Failed: Couldnot drag and drop the selected Elements", t);
			}
		}

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------

public void dropdownByVisibleText(String xpathKey,String s)throws Throwable,Exception {
		try
		{
		WebElement element = driver.findElement(By.xpath(OR.getProperty(xpathKey)));
		Select sel = new Select(element);
		sel.selectByVisibleText(s);
		APP_LOGS.debug("Selected the option "+s+" from the dropdown");
		Reporter.log("Selected the option "+s+" from the dropdown");
		
		}
		catch(Throwable t){
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Couldnot select the option "+s+" from the dropdown");
		Reporter.log("Failed: Couldnot select the option "+s+" from the dropdown");
		throw new Exception("Failed: Couldnot select the option "+s+" from the dropdown", t);
		}
		}


//--------------------------------------------------------------------------------------------------------------------------------------------------------------------



public void dropdownByIndex(String xpathKey ,int i)throws Throwable,Exception {
		
		try{
		WebElement element = driver.findElement(By.xpath(OR.getProperty(xpathKey)));
		Select sel = new Select(element);
		sel.selectByIndex(i);
		APP_LOGS.debug("Selected option "+i+" from the dropdown");
		Reporter.log("Selected option "+i+" from the dropdown");
		
		}
		catch(Throwable t){
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Couldnot select the desired option from the dropdown");
		Reporter.log("Failed: Couldnot select the desired option from the dropdown");
		throw new Exception("Failed: Couldnot select the option "+i+" from the dropdown", t);
		}
		}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------



public void dropdownByValue(String xpathKey,String s)throws Throwable,Exception {
			try{
				WebElement element = driver.findElement(By.xpath(OR.getProperty(xpathKey)));
				Select sel = new Select(element);
				Thread.sleep(3000);
				sel.selectByValue(s);
				APP_LOGS.debug("Selected option "+s+" from the dropdown");
				Reporter.log("Selected option "+s+" from the dropdown");
				
			}
			catch(Throwable t){
				//reports
				ErrorUtil.addVerificationFailure(t); 
				APP_LOGS.debug("Failed: Couldnot select the option "+s+" from the dropdown");
				Reporter.log("Failed: Couldnot select the option "+s+" from the dropdown");
				throw new Exception("Failed: Couldnot select the option "+s+" from the dropdown", t);
				}
			}



//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
public void rightClick(String xpathKey)throws Throwable,Exception
		{
			try {
				
			  WebElement element = getObject(xpathKey);
		      Point point = element.getLocation();
			 			   
		     System.out.println("X value of Event is " + point.getX());	
		     System.out.println("Y value of Event is " + point.getY());	
			
		     Actions act2 = new Actions(driver);
		     act2.moveToElement(element,point.getX(),point.getY()).
		                       contextClick(element).
		                       perform();
		     prntResults("Sucessfully Right clicked on the Element --"+xpathKey);
		    
			} 
			catch (Exception e) 
			{
				ErrorUtil.addVerificationFailure(e); 
				prntResults("FAILED: Not able to Right click on the Element --"+xpathKey);
				
				throw new Exception("FAILED: Not able to Right click on the Element", e);
			}
		}


//--------------------------------------------------------------------------------------------------------------------------------------------------------------------

public void DoubleClick(String xpathKey)throws Throwable,Exception
		{
		try {	    
			   WebElement element = getObject(xpathKey); 
		        Actions action = new Actions(driver).doubleClick(element);
				action.build().perform();	     
		     APP_LOGS.debug("Double Click on the Element " +xpathKey);
		     Reporter.log("Double Click on the Element " +xpathKey);
			System.out.println("Sucessfully double clicked on the element" +xpathKey);
		} catch (Exception e) 
		{
			ErrorUtil.addVerificationFailure(e); 
			APP_LOGS.debug("Failed: Double Click on Element " + xpathKey);
			Reporter.log("Failed: Double Click on Element " + xpathKey);
			throw new Exception("Failed: Double Click on Element"+xpathKey, e);
		
		}
		}




//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
public void moveToElement(WebElement element)throws Throwable,Exception
		{
		try {
			Actions action = new Actions(driver);
			action.moveToElement(element).build().perform();
			APP_LOGS.debug("Moved to specified element successfully");
			Reporter.log("Moved to specified element successfully");
			System.out.println("Moved to specified element successfully");
		} catch (Exception e) 
		{
			ErrorUtil.addVerificationFailure(e); 
			APP_LOGS.debug("Failed: Cannot able to move to the specified element");
			Reporter.log("Failed: Cannot able to move to the specified element");
			throw new Exception("Failed: Cannot be able to move to the specified element", e);
		
			
		}
		}



////--------------------------------------------------------------------------------------------------------------------------------------------------------------------


public void moveToElementandClick(WebElement element)throws Throwable,Exception
		{
		try {
			Actions action = new Actions(driver);
			action.moveToElement(element).click(element).build().perform();
			APP_LOGS.debug("Moved to specified element and clicked successfully");
			Reporter.log("Moved to specified element and clicked successfully");
			System.out.println("Moved to specified element and clicked successfully");
		}
		catch (Exception e) 
		{
			ErrorUtil.addVerificationFailure(e); 
			APP_LOGS.debug("Failed: Cannot be able to move to the specified element and Click " + element);
			Reporter.log("Failed: Cannot be able to move to the specified element and Click " + element);
			throw new Exception("Failed: Cannot be able to move to the specified element and Click", e);
		}
		}




///--------------------------------------------------------------------------------------------------------------------------------------------------------------------


public void iframesValidation()throws Throwable,Exception {
		try{
			JavascriptExecutor exe = (JavascriptExecutor) driver;
		Integer numberOfFrames = Integer.parseInt(exe.executeScript("return window.length").toString());
		System.out.println("Number of iframes on the page are " + numberOfFrames);
		
		//By finding all the web elements using iframe tag
		List<WebElement> iframeElements = driver.findElements(By.tagName("iframe"));
		System.out.println("The total number of iframes are " + iframeElements.size());
		APP_LOGS.debug("The total number of iframes are " + iframeElements.size());
		Reporter.log("The total number of iframes are " + iframeElements.size());
		}
		catch(Throwable t){
			//reports
			ErrorUtil.addVerificationFailure(t); 
			APP_LOGS.debug("Failed: Cannot find the iframes");
			Reporter.log("Failed: Cannot find the iframes");
			throw new Exception("Failed: Cannot find the iframes", t);
			}
		}


//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
public void offRoutePopup() throws Throwable,Exception
{
try{
int count = driver.findElements(By.xpath(".//*[@id='emergency-check-submit']")).size();
if ((!(count == 0))&&(getObject("Popup_OffRoute_Order_Continue").isDisplayed())) 
		{
		highlightElement("Cart_PopupOffRouteOrder_Continue");
		getObject("Cart_PopupOffRouteOrder_Continue").click();
		APP_LOGS.debug("Clicked on Cart_PopupOffRouteOrder_Continue ");
		Reporter.log("Clicked on Cart_PopupOffRouteOrder_Continue ");
		Thread.sleep(4000);	
		
		System.out.println("Cart Page is displayed!!!!");
		APP_LOGS.debug("Cart Page is displayed");	
		Reporter.log("Cart Page is displayed");	
	}
	else{
		APP_LOGS.debug("It is an On-Route Order");
		Reporter.log("It is an On-Route Order");
	}
}
catch(Throwable t){
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Not able to click on Off Route Continue");
		Reporter.log("Failed: Not able to click on Off Route Continue");
		throw new Exception("Failed: Not able to click on Off Route Continue", t);
		}
}


//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
public void ignoreAndContinue() throws Throwable,Exception
{
try{
int num = driver.findElements(By.xpath(".//*[@id='ignore-soft-block']")).size();
	if (!(num == 0)) 

		{
		getObject("Cart_IgnoreandContinue").click();
		APP_LOGS.debug("Clicked on Ignore & continue button");
		Reporter.log("Clicked on Ignore & continue button");
		Thread.sleep(3000);
	}
	else{
		APP_LOGS.debug("Landing in Order Review Page");
		Reporter.log("Landing in Order Review Page");
	}
}
catch(Throwable t){
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Not able to click on Ignore and continue");
		Reporter.log("Failed: Not able to click on Ignore and continue");
		throw new Exception("Failed: Not able to click on Ignore and continue Link", t);	
		}
}





//--------------------------------------------------------------------------------------------------------------------------------------------------------------------


public void FirstCloseButton() throws Throwable,Exception
{
try{
int count = driver.findElements(By.xpath("//div[@class='popover-content scrollable-y']//following-sibling::a[@class='btn btn-primary close-btn']")).size();
System.out.println("Count is"+count);
		if (((count == 1))
					&& (driver
							.findElement(By
									.xpath("//div[@class='popover-content scrollable-y']//following-sibling::a[@class='btn btn-primary close-btn']"))
							.isDisplayed())) {
				highlightElement("closebutton");			
				APP_LOGS.debug("Close Button is displayed!!");
				Reporter.log("Close Button is displayed!!");
				getObject("closebutton").click();
				APP_LOGS.debug("Clicked on Close Button");
				Reporter.log("Clicked on Close Button");
				Thread.sleep(4000);
				System.out.println("Close Button is displayed!!");
				
			} else {
				APP_LOGS.debug("Close Button is not displayed");
				Reporter.log("Close Button is not displayed");
			}
		}
catch(Throwable t)
{
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Not able to click on Close Button");
		Reporter.log("Failed: Not able to click on Close Button");
		throw new Exception("Failed: Not able to click on Close Button", t);	
		}
}



//--------------------------------------------------------------------------------------------------------------------------------------------------------------------


public void SecondCloseButton() throws Throwable,Exception
{
try{
int count = driver.findElements(By.xpath("html/body/header/div[4]/div[2]/div[2]/div[2]/div/div[2]/div/div/a[2]")).size();
		if (!(count == 0)) 
		{
			highlightElement("Mobile_Cart_Close2button");
			getObject("Mobile_Cart_Close2button").click();
			APP_LOGS.debug("Clicked on Close Button in Cart Page");
			Reporter.log("Clicked on Close Button in Cart Page");
			Thread.sleep(4000);
			System.out.println("Close Button is displayed!!");
			APP_LOGS.debug("Close Button is displayed!!");
			Reporter.log("Close Button is displayed!!");
		}
		else 
		{
			APP_LOGS.debug("Close Button is not displayed");
			Reporter.log("Close Button is not displayed");
		}
}
catch(Throwable t)
{
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Not able to click on Close Button");
		Reporter.log("Failed: Not able to click on Close Button");
		throw new Exception("Failed: Not able to click on Close Button", t);	
		}
}

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

public void NavigatetoTopofPage()throws Throwable,Exception
{
try {
	Robot robot = new Robot();
	robot.keyPress(KeyEvent.VK_PAGE_UP);
	robot.keyRelease(KeyEvent.VK_PAGE_UP);	
	Thread.sleep(2000);
	APP_LOGS.debug("Navigated to Top of Page Successfully");
	Reporter.log("Navigated to Top of Page Successfully");
	System.out.println("Navigated to Top of Page Successfully");
} catch (Exception e) 
{
	ErrorUtil.addVerificationFailure(e); 
	APP_LOGS.debug("Failed: Couldnot Navigate to Top of Page" );
	Reporter.log("Failed: Couldnot Navigate to Top of Page" );
	throw new Exception("Failed: Couldnot Navigate to Top of Page", e);	
}
}

public void NavigatetoEndofPage()throws Throwable,Exception
{
try {
	/*Actions actions2 = new Actions(driver);
	actions2.sendKeys(Keys.CONTROL).sendKeys(Keys.END).perform();*/
	Robot robot = new Robot();
	robot.keyPress(KeyEvent.VK_PAGE_DOWN);
	robot.keyRelease(KeyEvent.VK_PAGE_DOWN);	
	Thread.sleep(2000);
	APP_LOGS.debug("Navigated to End of Page Successfully");
	Reporter.log("Navigated to End of Page Successfully");
	System.out.println("Navigated to End of Page Successfully");
} catch (Exception e) 
{
	ErrorUtil.addVerificationFailure(e); 
	APP_LOGS.debug("Failed: Couldnot Navigate to End of Page" );
	Reporter.log("Failed: Couldnot Navigate to End of Page" );
	throw new Exception("Failed: Couldnot Navigate to End of Page", e);	
}
}

public void selectOrders(String xpathKey, String NumberofOrders_tobeviewed)
		throws Throwable {
	try {
		getObject("OrderHistory_OrderHistoryPage_ViewnumberofOrders").sendKeys(NumberofOrders_tobeviewed);
		prntResults("Selected ordersnumber  "
				+ NumberofOrders_tobeviewed);
		Thread.sleep(4000);

		List<WebElement> NumberofOrders = driver.findElements(By.xpath(OR
				.getProperty(xpathKey)));
		// Select select = new Select(xpathKey);
		Thread.sleep(4000);
		switch (NumberofOrders_tobeviewed) {
		case "20 Orders":
			prntResults("Number of Orders displaying when 20 orders are selected:  "
							+ NumberofOrders.size());
			int i1 = 1;
			for (WebElement column:NumberofOrders) 
			{
				//System.out.println(i);
				prntResults(column.getText());
				//System.out.println(i);
				//int j = i - 1;
				i1 = i1 + 1;
				if(i1>NumberofOrders.size())
				{
				break;	
				}
				}
			break;
		case "40 Orders":

			prntResults("Number of Orders displaying when 40 orders are selected: "
							+ NumberofOrders.size());
			int i2 = 1;
			for (WebElement column:NumberofOrders) 
			{
				//System.out.println(i);
				prntResults(column.getText());
				//System.out.println(i);
				//int j = i - 1;
				i2 = i2 + 1;
				if(i2>NumberofOrders.size())
				{
				break;	
				}
				}
			break;

		case "All Orders":

			prntResults("Number of Orders displaying when All orders are selected: "
							+ NumberofOrders.size());
			int i = 1;
			for (WebElement column:NumberofOrders) 
			{
				//System.out.println(i);
				prntResults(column.getText());
				//System.out.println(i);
				//int j = i - 1;
				i = i + 1;
				if(i>NumberofOrders.size())
				{
				break;	
				}
				}
			break;

		case "":
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.error("Failed: Orders to be viewed Not Mentioned in TestData/Not able to select");
			Reporter.log("Failed: Orders to be viewed Not Mentioned in TestData/Not able to select");
			// throw new Exception(t);
			throw new Exception();

		default:

			System.out.println("default");
		}

	} catch (Exception e) 
	{
		ErrorUtil.addVerificationFailure(e);
		APP_LOGS.debug("Failed: Validation of Orders in OrderHistory Page Failed");
		Reporter.log("Failed: Validation of Orders in OrderHistory Page Failed");
		throw new Exception("Failed: Validation of Orders in OrderHistory Page Failed", e);
	}
}
public boolean Login2(String xpath1, String xpath2, String xpath3,
		String xpath4, String uname, String pwd) throws Throwable,Exception {
	try {
		driver.manage().window().maximize();
		driver.findElement(By.xpath(OR.getProperty(xpath1))).clear();
		driver.findElement(By.xpath(OR.getProperty(xpath1)))
				.sendKeys(uname);
		driver.findElement(By.xpath(OR.getProperty(xpath2))).clear();
		driver.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
		driver.findElement(By.xpath(OR.getProperty(xpath3))).click();
		System.out.println("clicked on checkbox");
		Thread.sleep(3000);
		driver.findElement(By.xpath(OR.getProperty(xpath4))).click();
		
		boolean submitbuttonPresence = driver.findElement(By.xpath(OR.getProperty("Mobile_ContactCollapse"))).isDisplayed();
					  if(submitbuttonPresence==true) 
		   {
	             System.out.println("True");
	              APP_LOGS.debug("Login Successfully as validation of Mobile_ContactCollapse in Homepage is Passed");
				   Reporter.log("Login Successfully as validation of Mobile_ContactCollapse in Homepage is Passed");
	        }
	
	} catch (Exception e) {
		// reports
		ErrorUtil.addVerificationFailure(e);
		APP_LOGS.debug("Login Failed");
		 Reporter.log("Login Failed");
		throw e;
		 //return false;
	}
	APP_LOGS.debug("LOGIN Successful");
	 Reporter.log("LOGIN Successful");
	return true;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
public void PriceCaptureButton() throws Throwable,Exception
{
try{
int count = driver.findElements(By.xpath("html/body/div[1]/div[5]/div[2]/div[2]/div/div[2]/div/div/a[2]")).size();
System.out.println("Count is"+count);
if ((!(count == 0))&&(getObject("closebutton").isDisplayed())) 
		{
			highlightElement("closebutton");
			getObject("closebutton").click();
			APP_LOGS.debug("Clicked on Close Button");
			Reporter.log("Clicked on Close Button");
			Thread.sleep(4000);
			System.out.println("Close Button is displayed!!");
			APP_LOGS.debug("Close Button is displayed!!");
			Reporter.log("Close Button is displayed!!");
		} 
		else 
		{
			APP_LOGS.debug("Close Button is not displayed");
			Reporter.log("Close Button is not displayed");
		}
}
catch(Throwable t)
{
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Not able to click on Close Button");
		Reporter.log("Failed: Not able to click on Close Button");
		throw new Exception("Failed: Not able to click on Close Button", t);	
		}
}
public void ignoreAndContinue_mobile() throws Throwable,Exception
{
try{
int num = driver.findElements(By.xpath(".//*[@id='ignore-soft-block-span']")).size();
	if (!(num == 0)) 

		{
		getObject("Ign_n_Con_createOrder_mobile").click();
		APP_LOGS.debug("Clicked on Ignore & continue button");
		Reporter.log("Clicked on Ignore & continue button");
		Thread.sleep(3000);
	} 
else{
		APP_LOGS.debug("Ignore and Continue Link is not enabled");
		Reporter.log("Ignore and Continue Link is not enabled");
	}
}
catch(Throwable t){
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Not able to click on Ignore and continue");
		Reporter.log("Failed: Not able to click on Ignore and continue");
		throw new Exception("Failed: Not able to click on Ignore and continue Link", t);	
		}
} 
public void highlightElementThinBorder(String xpathKey) throws Throwable {
	try
	{
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath(OR.getProperty(xpathKey)));    
		js1.executeScript("arguments[0].style.border='3px solid red'", element);
		APP_LOGS.debug("Highlighted respective selected element  " + xpathKey );
		Reporter.log("Highlighted respective selected element    " +xpathKey);
			}
	 catch(Throwable t)
		{
  	    ErrorUtil.addVerificationFailure(t);		
			APP_LOGS.debug("Not able to highlight respective element" + xpathKey );
			Reporter.log("Not able to highlight  respective element" +xpathKey);
		    throw t;
		}
}
public void Click_PriceCaptureButton() throws Throwable 
{
	try
	{
		String LabelText = getObject("Mobile_PriceCaptureButton").getText();
		APP_LOGS.debug("The label of the button present is: "+LabelText);
		Reporter.log("The label of the button present is: "+LabelText);
		Thread.sleep(2000);		
		//============== To click on Create Order Button ====//
		if(LabelText.equals("Create Price Capture"))
		{
		Thread.sleep(2000);
		highlightElement("Mobile_CreatePriceCaptutre");
		getObject("Mobile_CreatePriceCaptutre").click();
		APP_LOGS.debug("Clicked Create Price Capture Button");
		Reporter.log("Clicked Create Price Capture Button");
		Thread.sleep(3000);
		
		}		
		//=================================== To click on Order In Progress Button ===================================//
		else 
		{
		Thread.sleep(2000);
		highlightElement("Mobile_PriceCapture_PriceCaptueInProgress");
		getObject("Mobile_PriceCapture_PriceCaptueInProgress").click();
		APP_LOGS.debug("Clicked Order In Progress Button");
		Reporter.log("Clicked Order In Progress Button");
		Thread.sleep(2000);
		
		getObject("Mobile_PriceCapture_Cancel").click();
		APP_LOGS.debug("Clicked cancel Button");
		Reporter.log("Clicked cancel Button");
		Thread.sleep(2000);
		
		getObject("Mobile_PriceCapture_Cancel_Yes").click();
		APP_LOGS.debug("Clicked cancel -> Yes Button");
		Reporter.log("Clicked cancel -> Yes Button");
		Thread.sleep(2000);
		
		String createPriceCapture_Txt = getObject("Mobile_PriceCaptureButton").getText();
		APP_LOGS.debug("The Label Present is: "+createPriceCapture_Txt);
		Reporter.log("The Label Present is: "+createPriceCapture_Txt);
		Thread.sleep(3000);
		
		if(createPriceCapture_Txt.equals("Create Price Capture"))
		{
			APP_LOGS.debug("Success: The Button present is Create Price Capture");
			Reporter.log("Success: The Button present is Create Price Capture");
			Thread.sleep(3000);
		}
		else
		{
			APP_LOGS.debug("FAILED: The Button present is not Create Price Capture");
			Reporter.log("FAILED: The Button present is not Create Price Capture");
			capturescreenshot(this.getClass().getSimpleName()+"__"+count);	
			throw new Exception("FAILED: The Button present is not Create Price Capture");
		
		}
		
		highlightElement("Mobile_CreatePriceCaptutre");
		getObject("Mobile_CreatePriceCaptutre").click();
		APP_LOGS.debug("Clicked on Create Price Capture Button");
		Reporter.log("Clicked on Create Price Capture Button");
		Thread.sleep(3000);
		
		}
	}
	catch(Throwable t)
	{
	    ErrorUtil.addVerificationFailure(t);		
		APP_LOGS.debug("FAILED: Not able to validate Create Price Capture button");
		Reporter.log("FAILED: Not able to validate Create Price Capture button");
	    throw t;
	}
}
public WebElement WaitforElement_Visibility_UsingFluent(String xpathKey, int timeOutInSeconds) throws Throwable{
   try
   {
    WebElement element;
   // highlightElement(xpathKey);
    FluentWait  wait = new FluentWait(driver).withTimeout(timeOutInSeconds,TimeUnit.SECONDS).pollingEvery(200,TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
    element = (WebElement) wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(OR.getProperty(xpathKey))));
    return element;
   }
   catch(Throwable t)
	{
	    ErrorUtil.addVerificationFailure(t);		
		APP_LOGS.debug("FAILED: Not able to wait till element is visible for "+timeOutInSeconds +"Seconds");
		Reporter.log("FAILED: Not able to wait till element is visible"+timeOutInSeconds +"Seconds");
	    throw t;
	}
}
public static boolean WaitForObjectAvailability(String xPathVale) throws Exception
{
	WebElement we;
	Boolean iRet = fail;
	try
	{
		Thread.sleep(2000);
		for (int i=0;i<240; i++)
		{
		 we = driver.findElement(By.xpath(OR.getProperty(xPathVale)));
		 if (we.getSize().getWidth()> 0 && we.isEnabled())
		 {
			iRet = isInitalized;
		 	break;
		 }
		}
	}
		catch (Exception t)
		{
			ErrorUtil.addVerificationFailure(t);		
			APP_LOGS.debug("Could not wait until element is Present "+xPathVale);		
			Reporter.log("Could not wait until element is Present  "+xPathVale);	
			throw t;
		}
	return iRet;
}

public static void prntResults(String sMessage)
{
	System.out.println(sMessage);
	APP_LOGS.debug(sMessage);
	Reporter.log(sMessage);
}

public void waitForAnElementToPresentBy(String xpathKey) throws Exception          // Wait function to wait for element
{ 
	  
    for (int second=0; ; second++)
        {
            if (second>=10000) 
            	Assert.fail("Timeout: Unable to find the Element for the time duration");
            try
            {   
          	  //WebElement element = driver.findElement(By.xpath(OR.getProperty(xpathKey)));               	  
          	  if (driver.findElement(By.xpath(OR.getProperty(xpathKey))).isDisplayed()) 
          		  break;
          	  Thread.sleep(second * 1000); 
          	  
            }
            catch (Exception e)
            { 
          	  throw new Exception("Element : "+xpathKey+" is not present in the page, So throwing an Exception : "+e);
            }
            
         }  
}
public WebElement waitForMe(String xpathKey, int timeout){  
    WebDriverWait wait = new WebDriverWait(driver, timeout);  
    return wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(OR.getProperty(xpathKey))));
} 
public static String isCheckBoxChecked(String xpath) {

    prntResults("Checking if the checkbox related to '"+xpath+"' is checked or not.");
   
    try {    
         //Assuming the objLocator contains xpath
        if (driver.findElement(By.xpath(OR.getProperty(xpath))).isSelected()) 
        {
        	prntResults("Checkbox related to: '"+xpath+"' is checked.");           
        }else
        {
        	prntResults("Checkbox related to: '"+xpath+"' is not checked!!");           
            return "Fail" + ": Checkbox related to: '"+xpath+"' is not checked!!";
        }
    }
    catch (Throwable t) {
    	prntResults("Error while Checking if the checkbox related to '"+xpath+"' is checked or not. -" + t.getMessage());
        
        return "Fail"+": Error while Checking if the checkbox related to '"+xpath+"' is checked or not. -" + t.getMessage();
    }

    return "Pass"+": Checkbox related to: '"+xpath+"' is checked.";
}
public boolean checkTextUsingContains(String xpathKey, String expectedVal)
		throws Throwable 
		{
		  String actual = driver.findElement(By.xpath(OR.getProperty(xpathKey))).getText(); 
		  
		try 
		{ System.out.println("Text1" +actual.trim());
		System.out.println("Text12" +expectedVal.trim());
		String actual2 = actual.trim().replaceAll("[^a-zA-Z]","");
		String expectedVal2 = expectedVal.trim().replaceAll("[^a-zA-Z]","");				
		Assert.assertTrue(actual2.trim().contains(expectedVal2)); 
		System.out.println("Contains Passed");
		   } 
		catch (Throwable t) 
		{
				ErrorUtil.addVerificationFailure(t);
							capturescreenshot(this.getClass().getSimpleName() + "_" + count);
							// Assert.assertEquals(Invalid, xpathKey);
							APP_LOGS.debug("TEXT do not match" + " " + "__________" + " "+ "Text displaying in application as" + " " +actual+ " "
									+ "Text Expected is" + " " +expectedVal.toString());
							Reporter.log("TEXT do not match" + " " + "__________" + " "
									+ "Text displaying in application as" + "   " + actual + " "
									+ "Text Expected is" + " " + expectedVal.toString());
							APP_LOGS.debug("***************************************************");
							Reporter.log("***************************************************");
							throw new Exception("Failed : TEXT do not match" + " "
									+ "Text displaying in application as" + "   " + actual + " "
									+ "Text Expected is" + " " + expectedVal.toString(), t);
							// return false;
						}
						APP_LOGS.debug("Text match" + " "
								+ "_____________________________________" + " " + expectedVal);
						Reporter.log("Text match" + " "
								+ "_____________________________________" + " " + expectedVal);
						APP_LOGS.debug("***************************************************");
						Reporter.log("***************************************************");
						return true; 

		}
public String switchToNewWindow(){ //get the handle of parent window
String handle1 = null;
try {
handle1=driver.getWindowHandle(); 
//get all the windows handle
Set<String> handles1=driver.getWindowHandles();

//loop through each handles
for(String hmd1:handles1) {
//check if the handles is not parent
if(!hmd1.equals(handle1)) {
//Change the control into new window
driver.switchTo().window(hmd1);
}
}

} catch(Exception e) {
ErrorUtil.addVerificationFailure(e); 
APP_LOGS.debug("Problem in switching to new window"); 
Reporter.log("Problem in switching to new window"); 
prntResults(e.getMessage());
}
return handle1;
} 

public String BackofficeFindElements(String xpath,int j)
{
	String linkText ="";
try
{
		List<WebElement> elements = driver.findElements(By.xpath(xpath));
		prntResults("Element size is :"+elements.size());
		if(!(elements.size() == 0))
		{
				prntResults(elements.get(j).getText());
				linkText = elements.get(j).getText();
				//WebElement link = driver.findElement(By.linkText(linkText));
		}
	}
catch(Exception e) 
{
ErrorUtil.addVerificationFailure(e); 
APP_LOGS.debug("Problem in switching to new window"); 
Reporter.log("Problem in switching to new window"); 
prntResults(e.getMessage());
}
return linkText;
} 

public void filepathValidation(String pathname) throws Throwable {
	try
	{
	String realname = getObject("CommsBO_HMC_Auditing_RealName").getAttribute("value");
	System.out.println("The File Path found in HMC is: "+realname);
	APP_LOGS.debug("The File Path found in HMC is: "+realname);
	Reporter.log("The File Path found in HMC is: "+realname);
	
	APP_LOGS.debug("The pathname found in excel is: "+pathname);
	Reporter.log("The pathname found in excel is: "+pathname);

	if(pathname.equals(realname))
	{
		APP_LOGS.debug("The Path Specified is correct!!!!");
		Reporter.log("The Path Specified is correct!!!!");
	}
	else
	{
		APP_LOGS.debug("FAILED: THE FILE PATH SPECIFIED IS INCORRECT");
		Reporter.log("FAILED: THE FILE PATH SPECIFIED IS INCORRECT");
		capturescreenshot(this.getClass().getSimpleName()+"__"+count);
		throw new Exception();
	}
	}
	catch (Exception e) 
	{
		//APP_LOGS.debug("FAILED: THE FILE PATH SPECIFIED IS INCORRECT");
		//Reporter.log("FAILED: THE FILE PATH SPECIFIED IS INCORRECT");
		//capturescreenshot(this.getClass().getSimpleName()+"__"+count);
		throw e;
	}

}


public void highlightElementInGreen(String xpathKey) throws Throwable {
	try
	{
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath(OR.getProperty(xpathKey)));    
		js1.executeScript("arguments[0].style.border='2px groove green'", element);
		APP_LOGS.debug("Highlighted respective selected element  " + xpathKey );
		Reporter.log("Highlighted respective selected element    " +xpathKey);
			}
	 catch(Throwable t)
		{
  	    ErrorUtil.addVerificationFailure(t);		
			APP_LOGS.debug("Not able to highlight respective element "+xpathKey );
			Reporter.log("Not able to highlight  respective element "+xpathKey);
		    throw t;
		}
}



public void offRoutePopup_secondBrowser() throws Throwable,Exception
{
try{
int count = driver1.findElements(By.xpath(".//*[@id='emergency-check-submit']")).size();
System.out.println("Count is"+count);
if ((!(count == 0))&&(getObject_secondBrowser("Cart_PopupOffRouteOrder_Continue").isDisplayed())) 
			{
			
	             getObject_secondBrowser("Cart_PopupOffRouteOrder_Continue").click();
				APP_LOGS.debug("Clicked on Cart_PopupOffRouteOrder_Continue ");
				Reporter.log("Clicked on Cart_PopupOffRouteOrder_Continue ");
				Thread.sleep(4000);		 	
				System.out.println("Cart Page is displayed!!!!");
				APP_LOGS.debug("Cart Page is displayed");
				Reporter.log("Cart Page is displayed");
			} 
			else 
			{
				APP_LOGS.debug("It is an On-Route Order");
				Reporter.log("It is an On-Route Order");
			}
}
catch(Throwable t)
{
		//reports
		ErrorUtil.addVerificationFailure(t); 
		APP_LOGS.debug("Failed: Not able to click on Off Route Continue");
		Reporter.log("Failed: Not able to click on Off Route Continue");
		throw new Exception("Failed: Not able to click on Off Route Continue", t);
}	
	

}
public WebElement getObject_secondBrowser(String xpathKey)throws Throwable{
	
	try{
	WebElement x = driver1.findElement(By.xpath(OR.getProperty(xpathKey)));
	return x;
	}
catch(Throwable t){
		// report error
	ErrorUtil.addVerificationFailure(t);
	APP_LOGS.debug("Couldnot find the element " +xpathKey);
	Reporter.log("Couldnot find the element  " +xpathKey);
	throw new Exception("Failed: Couldnot find the element  "+ xpathKey ,t);
	}
}

public boolean LoginClerk_secondBrowser(String xpath1, String xpath2, String xpath3,
String xpath4, String uname, String pwd) throws Throwable,
Exception {
try {
driver1.manage().window().maximize();
driver1.findElement(By.xpath(OR.getProperty(xpath1))).clear();
driver1.findElement(By.xpath(OR.getProperty(xpath1)))
	.sendKeys(uname);
APP_LOGS.debug("Entered the Username");
Reporter.log("Entered the Username");
driver1.findElement(By.xpath(OR.getProperty(xpath2))).clear();
driver1.findElement(By.xpath(OR.getProperty(xpath2))).sendKeys(pwd);
APP_LOGS.debug("Entered the Password");
Reporter.log("Entered the Password ");
driver1.findElement(By.xpath(OR.getProperty(xpath3))).click();
System.out.println("clicked on checkbox");
APP_LOGS.debug("clicked on checkbox");
Reporter.log("clicked on checkbox ");
Thread.sleep(3000);
driver1.findElement(By.xpath(OR.getProperty(xpath4))).click();
APP_LOGS.debug("clicked on Loginbutton");
Reporter.log("clicked on Loginbutton ");
boolean submitbuttonPresence = driver1.findElement(
	By.xpath(OR.getProperty("Glosary"))).isDisplayed();
if (submitbuttonPresence == true) {
System.out.println("True");
APP_LOGS.debug("Login Successfully as validation of Glosary in Homepage is Passed");
Reporter.log("Login Successfully as validation of Glosary in Homepage is Passed");
}
} catch (Exception e) {
// reports
ErrorUtil.addVerificationFailure(e);
APP_LOGS.debug("Failed: Login Failed for Clerk_Login");
Reporter.log("Failed: Login Failed for Clerk__Login");
throw new Exception("Failed: Login Failed for Clerk_Login" ,e);
// return false;
}
APP_LOGS.debug("LOGIN Successful");
Reporter.log("LOGIN Successful");
return true;
} 
public void OpenSecond_Browser() throws InterruptedException
{
	//System.setProperty("webdriver.chrome.driver", "D:\\Chromedriver\\chromedriver.exe");	
	    driver1 = new FirefoxDriver();			
		driver1.get(CONFIG.getProperty("testSiteName"));
		APP_LOGS.debug("Navigated to Staging Application");
		Reporter.log("Navigated to Staging Application");
        Thread.sleep(4000);
}

public WebElement getObject_Css(String xpathKey)throws Throwable{
	
	try{
		//WaitForObjectAvailability(xpathKey);
	WebElement x = driver.findElement(By.cssSelector(OR.getProperty(xpathKey)));
	return x;
	} 
catch(Throwable t){
		// report error
	ErrorUtil.addVerificationFailure(t);
	APP_LOGS.debug("Couldnot find the element " +xpathKey);
	Reporter.log("Couldnot find the element  " +xpathKey);
	throw new Exception("Failed: Couldnot find the element  "+ xpathKey ,t);
	}
} 

public boolean checkText_css(String xpathKey, String expectedVal)
		throws Throwable 
		{
	   String actual = driver.findElement(By.cssSelector(OR.getProperty(xpathKey))).getText();	
	   
	try 
	{		
	//System.out.println(actual.trim());
	//System.out.println(expectedVal.trim());
	String actual2 = actual.trim().replaceAll("[^a-zA-Z]","");
	String expectedVal2 = expectedVal.trim().replaceAll("[^a-zA-Z]","");
	Thread.sleep(3000);
	Assert.assertTrue(actual2.trim().equalsIgnoreCase(expectedVal2));
	    } 
	catch (Throwable t) 
	{
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		// Assert.assertEquals(Invalid, xpathKey);
		APP_LOGS.debug("TEXT do not match" + " " + "__________" + " "+ "Text displaying in application as" + " " +actual+ " "
				+ "Text Expected is" + " " +expectedVal.toString());
		Reporter.log("TEXT do not match" + " " + "__________" + " "
				+ "Text displaying in application as" + "   " + actual + " "
				+ "Text Expected is" + " " + expectedVal.toString());
		APP_LOGS.debug("***************************************************");
		Reporter.log("***************************************************");
		throw new Exception("Failed : TEXT do not match" + " "
				+ "Text displaying in application as" + "   " + actual + " "
				+ "Text Expected is" + " " + expectedVal.toString(), t);
		// return false;
	}
	prntResults("Text match" + " "
			+ "_____________________________________" + " " + expectedVal);
	prntResults("***************************************************");
	return true;
}
public void UpdateTestResults (Boolean ExecStat, Boolean Skip)
{
	if (Skip)
	{
		TestUtil.reportDataSetResult(suite_Can_ContactUs_xls, this.getClass().getSimpleName(), count + 2, "SKIP");		
	}

	
	if (ExecStat)
	{
		TestUtil.reportDataSetResult(suite_Can_ContactUs_xls, this.getClass().getSimpleName(), count + 3, "PASS");
		TestUtil.reportDataSetResult(suite_Can_ContactUs_xls, "Test Cases", TestUtil.getRowNum(suite_Can_ContactUs_xls, this.getClass().getSimpleName()), "PASS");
	}
	else
	{
		TestUtil.reportDataSetResult(suite_Can_ContactUs_xls, this.getClass().getSimpleName(), count + 3, "FAIL");
		TestUtil.reportDataSetResult(suite_Can_ContactUs_xls, "Test Cases", TestUtil.getRowNum(suite_Can_ContactUs_xls, this.getClass().getSimpleName()), "FAIL");
		
	}
	
}
}
