package com.veo.suite.backoffice;


import java.io.IOException;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class BO_CreateOrdBtnPageRedirect extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void Backoffice_CreateOrdBtnPageRedirect(
			String uname,
			String pwd,
			String ERPNumber,
			String PageTitle1
			
			) throws Throwable,IOException{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing TC_BO_CreateOrdBtnPageRedirect");
		Reporter.log("Executing TC_BO_CreateOrdBtnPageRedirect");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Verify BackOffice Create Order Button Redirect to the Cart Page");
		Reporter.log("Verify BackOffice Create Order Button Redirect to the Cart Page");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		
		
				// webdriver
				openBrowser();
				APP_LOGS.debug("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
				Reporter.log("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
				
				driver.get(CONFIG.getProperty("backofficeurl"));
				APP_LOGS.debug("Entered Backoffice URL");
				Reporter.log("Entered Backoffice URL");

		try
		{
//	====================================Login to Backoffice========================================================//

			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
		
			getObject("BackOffice_CreateOrderButton").click();
			APP_LOGS.debug("Clicked on Create Order Button");
			Reporter.log("Clicked on Create Order Button");
			//Thread.sleep(3000);

			getObject("BackOffice_InputERPNumber").clear();
			getObject("BackOffice_InputERPNumber").sendKeys(ERPNumber);
			APP_LOGS.debug("Entered ERP Number is: "+ERPNumber);
			Reporter.log("Entered ERP Number is: "+ERPNumber);
			//Thread.sleep(3000);
			
			getObject("BackOffice_OkButton").click();
			APP_LOGS.debug("Clicked Ok Button");
			Reporter.log("Clicked Ok Button");
			Thread.sleep(6000);
			
			for (String winHandle : driver.getWindowHandles()) 
			{
			    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
			    System.out.println("Switched to new window: "+driver.getTitle());
				APP_LOGS.debug("Switched to new window: "+driver.getTitle());
				Reporter.log("Switched to new window: "+driver.getTitle());
						
			}	
			Thread.sleep(3000);
			String CurrentTitle = driver.getTitle();
			

			if(!(CurrentTitle.equals(PageTitle1)))
			{
				APP_LOGS.debug("Current Page Title is: "+CurrentTitle);
				Reporter.log("Current Page Title is: "+CurrentTitle);
				
				APP_LOGS.debug("Success: BackOffice Page Redirected to the Cart Page");
				Reporter.log("Success: BackOffice Page Redirected to the Cart Page");
			}
			else
			{
				APP_LOGS.debug("FAILED: BackOffice Page is not Redirected to the Cart Page");
				Reporter.log("FAILED: BackOffice Page is not Redirected to the Cart Page");
				capturescreenshot(this.getClass().getSimpleName() + "_" + count);
				throw new Exception("FAILED: BackOffice Page is not Redirected to the Cart Page");
			}
		 //==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
		 
			}
		catch(Exception e)
		{
			ErrorUtil.addVerificationFailure(e);
			System.err.println("FAILED");
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Failed");
			Reporter.log("Failed");
			throw e;
							
		}
		
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		

