package com.veo.suite.backoffice;


import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class BO_OrderCountDisplay extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void AbletoSelectNumber_of_OrderCountToDisplay_in_OnePage (
			String uname,
			String pwd,
			String OrderDisplayCount
			
			
			) throws Throwable,IOException{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing TC_BO_OrderCountDisplay");
		Reporter.log("Executing TC_BO_OrderCountDisplay");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to Select the Number of OrderCountToDisplay in One Page");
		Reporter.log("Ability to Select the Number of OrderCountToDisplay in One Page");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		// webdriver
		openBrowser();
		APP_LOGS.debug("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		Reporter.log("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Backoffice URL");
		Reporter.log("Entered Backoffice URL");

		try
		{
//	====================================Login to Backoffice========================================================//
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
						
			getObject("BackOffice_OrderCountDisplay").clear();
			getObject("BackOffice_OrderCountDisplay").clear();
			getObject("BackOffice_OrderCountDisplay").sendKeys(OrderDisplayCount);
			APP_LOGS.debug("Entered Order Count Display is: "+OrderDisplayCount);
			Reporter.log("Entered Order Count Display is: "+OrderDisplayCount);
			Thread.sleep(3000);

			getObject("Backoffice_RefreshButton").click();
			APP_LOGS.debug("Clicked Refresh Button");
			Reporter.log("Clicked Refresh Button");
			Thread.sleep(6000);
			
			List<WebElement> rows = driver.findElements(By.xpath("//table/tbody[2]/tr/td/div/span/a"));
			int totalRow = rows.size();
			System.out.println(totalRow);
			  
			
		    String TableRow1 = Integer.toString(totalRow);
		    //		====================================To compare whether the table having data========================================================//
			 if(OrderDisplayCount.equals(TableRow1))
			 {
				 APP_LOGS.debug("Success: Number of Orders displayed in this table: "+TableRow1);
				 Reporter.log("Success: Number of Orders displayed in this table: "+TableRow1);
				 
			 }
			 else if(totalRow>0)
			 {
				 APP_LOGS.debug("Success: Number of Orders displayed in this table: "+TableRow1);
				 Reporter.log("Success: Number of Orders displayed in this table: "+TableRow1);
			
			 }
			 else
			 {
				 APP_LOGS.debug("FAILED: No.Of. Orders Displayed is not matched with selected orders count");
				 Reporter.log("FAILED: No.Of. Orders Displayed is not matched with selected orders count");
				 capturescreenshot(this.getClass().getSimpleName()+"__"+count);
				 throw new Exception("FAILED: No.Of. Orders Displayed is not matched with selected orders count");
			 }
		 //==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
		 
			}
		catch(Exception e)
		{
			ErrorUtil.addVerificationFailure(e);
			System.err.println("FAILED");
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Failed");
			Reporter.log("Failed");
			throw e;
							
		}
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		

