package com.veo.suite.backoffice;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

	public class Backoffice_08_45_a extends TestSuiteBase {

		String runmodes[] = null;
		static boolean fail = false;
		static boolean skip = false;
		static boolean isTestPass = true;
		static int count = -1;
		
		// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		@Test(dataProvider = "getTestData")
		public void CreateAccount_for_CustomerService(
				String username_HMC, 
				String pwd_HMC,
				String ID,
				String Name,
				String Language,
				String NewPassword,
				String RepeatPassword,
				String UserGroup,
				String ERP
				)
				throws Exception, Throwable, InterruptedException, IOException {
			count++;
			if (!runmodes[count].equalsIgnoreCase("Y")) {
				throw new SkipException("Runmode for test set data set to no "+ count);
			}
			
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Executing Backoffice TC_08_45_a");
			Reporter.log("Executing Backoffice TC_08_45_a");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Validate cockpit permissions as Customer Service Agent");
			Reporter.log("Validate cockpit permissions as Customer Service Agent");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Username: "+username_HMC+" & Password:"+pwd_HMC);
			Reporter.log("Username: "+username_HMC+" & Password:"+pwd_HMC);		
			
			//Webdriver
			openBrowser();
			APP_LOGS.debug("Browser Up "+this.getClass().getSimpleName());
			Reporter.log("Browser Up "+this.getClass().getSimpleName());
			
			driver.get(CONFIG.getProperty("testSiteName_HMC"));
			APP_LOGS.debug("Entered the URL");
			Reporter.log("Entered the URL");
			
			try
			{
				if(!LoginHMC("HMC_LoginPage_Username","HMC_LoginPage_Password","HMC_LoginPage_LoginSubmit",username_HMC,pwd_HMC)){
					// screenshot
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit
					return;
			}		
			
			     
		//========To Click on User Link===========//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_UserLink").click();
			APP_LOGS.debug("Clicked On User Link");
			Reporter.log("Clicking On User Link");
		
		//====To Right Click on Employee====//
			Thread.sleep(3000);
			rightClick("Backoffice_HMC_User_Employee");
			Thread.sleep(3000);
			APP_LOGS.debug("Right Clicked Employee");
			Reporter.log("Right Clicked Employee");
			Thread.sleep(3000);
		 
			//======Mouse hover on Create====//			 
			WebElement create=getObject("Backoffice_HMC_User_Employee_Create");
			moveToElement(create);
			Thread.sleep(3000);
			APP_LOGS.debug("Mouse hover the Create");
			Reporter.log("Mouse hover the Create");		 
			 
			//=====To click on Employee======//
			getObject("Backoffice_HMC_User_Employee_Create_Employee").click();
			Thread.sleep(3000);
			APP_LOGS.debug("Clicked on Employee Option");
			Reporter.log("Clicked on Employee Option");
			Thread.sleep(3000);

			//======To Provide Id========//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_Create_ID").clear();
			Thread.sleep(1000);
			getObject("Backoffice_HMC_User_Create_ID").sendKeys(ID);
			APP_LOGS.debug("Given ID: "+ID);
			Reporter.log("Given ID: "+ID);
			Thread.sleep(3000);

			//=====To Provide Name====//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_Create_Name").clear();
			Thread.sleep(1000);
			getObject("Backoffice_HMC_User_Create_Name").sendKeys(Name);
			APP_LOGS.debug("Given Name: "+Name);
			Reporter.log("Given Name: "+Name);			
			Thread.sleep(3000);

			//=====To Select Language=====//
			dropdownByVisibleText("Backoffice_HMC_User_Create_SelectLanguage", Language);
			APP_LOGS.debug("Selected Language: "+Language);
			Reporter.log("Selected Language: "+Language);
			Thread.sleep(3000);

			//============To Add Groups==========//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_Create_AddGroups").clear();
			getObject("Backoffice_HMC_User_Create_AddGroups").sendKeys(UserGroup);
			APP_LOGS.debug("Entered the User Group");
			Reporter.log("Entered the User Group");
			Thread.sleep(1000);
			
			getObject("Backoffice_HMC_User_Create_AddGroups").sendKeys(Keys.TAB);
			APP_LOGS.debug("Clicked on TAB");
			Reporter.log("Clicked on TAB");
			Thread.sleep(1000);
			APP_LOGS.debug("Added Group is: "+UserGroup);
			Reporter.log("Added Group is: "+UserGroup);
			
			//======To Click on Create Button=========//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_Create_Create_Or_SaveLabel").click();
			APP_LOGS.debug("Clicked on Create Button");
			Reporter.log("Clicked on Create Button");
			
			//======To Click on Password Tab=========//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_Create_PasswordTab").click();
			APP_LOGS.debug("Clicked on Password Tab");
			Reporter.log("Clicked on Password Tab");
			
			//======To Provide New Password========//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_Create_NewPassword").clear();
			getObject("Backoffice_HMC_User_Create_NewPassword").sendKeys(NewPassword);
			APP_LOGS.debug("Given New Password: "+NewPassword);
			Reporter.log("Given New Password: "+NewPassword);
			
			//======To Provide Repeat Password========//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_Create_PasswordRepeat").clear();
			getObject("Backoffice_HMC_User_Create_PasswordRepeat").sendKeys(RepeatPassword);
			APP_LOGS.debug("Given Repeat Password: "+RepeatPassword);
			Reporter.log("Given Repeat Password: "+RepeatPassword);
			
			//======To Click on Save Button=========//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_Create_Create_Or_SaveLabel").click();
			APP_LOGS.debug("Clicked on Save Button");
			Reporter.log("Clicked on Save Button");
			
			//=====To Click On Search Link======//
			Thread.sleep(5000);
			highlightElement("Backoffice_HMC_User_SearchLink");
			getObject("Backoffice_HMC_User_SearchLink").click();
			APP_LOGS.debug("Clicked On Search Link");
			Reporter.log("Clicked On Search Link");
		
			//=====To Provide Search ID====//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_SearchID").clear();
			Thread.sleep(1000);
			getObject("Backoffice_HMC_User_SearchID").sendKeys(ID);
			APP_LOGS.debug("Given Search ID : "+ID);
			Reporter.log("Given Search ID : "+ID);			
			
			//=====To Click On Search Button======//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_SearchButton").click();
			APP_LOGS.debug("Clicked On Search Button");
			Reporter.log("Clicked On Search Button");
				
			//=======To Retrieve ID=====//
			Thread.sleep(3000);
			highlightElement("Backoffice_HMC_User_SearchList_ID");
			String SearchId = getObject("Backoffice_HMC_User_SearchList_ID").getText();
			if(SearchId.equals(ID))
			{
				APP_LOGS.debug("Success: Account is Created for Customer Service");
				Reporter.log("Success: Account is Created for Customer Service");
				APP_LOGS.debug("Created Customer Service UserName: "+ID);
				Reporter.log("Created Customer Service Password: "+NewPassword);
				
			}
			else
			{
				APP_LOGS.debug("Account is not Created for Customer Service");
				Reporter.log("Account is not Created for Customer Service");
				throw new Exception();
			}
		/*	//=====To Click On Logout Button======//
			Thread.sleep(3000);
			getObject("HMC_Logout").click();
			APP_LOGS.debug("Clicked On Logout Button");
			Reporter.log("Clicked On Logout Button"); */
			
			//To Open a new Tab
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL ,"t");
			APP_LOGS.debug("Opened a new tab");
			Reporter.log("Opened a new tab");
			
			//Enter the Backoffice URL
			driver.get(CONFIG.getProperty("backofficeurl"));
			APP_LOGS.debug("Entered Replenishment cockpit URL");
			Reporter.log("Entered Replenishment cockpit URL");
			
			
		//=================================== Login to Backoffice ===================================//
			
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",username_HMC,pwd_HMC)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
				
			//=================================== Clicking on Create Order ===================================//
			highlightElement("BackOffice_CreateOrderButton");
			Thread.sleep(3000);
			
			String createorderbtn = getObject("BackOffice_CreateOrderButton").getAttribute("disabled");
			APP_LOGS.debug("The Attribute value for CreateOrder is: "+createorderbtn);
			Reporter.log("The Attribute value for CreateOrder is: "+createorderbtn);
			Thread.sleep(3000);
			
			if(createorderbtn.equals("true"))
			{
				APP_LOGS.debug("Success: Create Order Button is Disabled");
				Reporter.log("Success: Create Order Button is Disabled");
				Thread.sleep(3000);
			}
			
			else
			{
				APP_LOGS.debug("FAILED: Create Order Button is not Disabled/ It is Enabled");
				Reporter.log("FAILED: Create Order Button is not Disabled/ It is Enabled");
				capturescreenshot(this.getClass().getSimpleName()+"__"+count);
				throw new Exception("FAILED: Create Order Button is not Disabled/ It is Enabled");
			}
  
	//=================================== Clicking on Logout button ===================================//
			highlightElement("Backoffice_Logout");
			getObject("Backoffice_Logout").click();
			APP_LOGS.debug("Clicked on Logout Button"); 
			Reporter.log("Clicked on Logout Button"); 
			Thread.sleep(3000);
			
			
			
	//============================== Switch back to HMC to delete the created Customer Agent ===================
			switchToTab();
			APP_LOGS.debug("Switched to hmc window: "+driver.getTitle()); 
			Reporter.log("Switched to hmc window: "+driver.getTitle()); 
			Thread.sleep(3000);

			//Select the Entries to be Deleted
			getObject("Backoffice_HMC_User_SearchList_ID").click();
			APP_LOGS.debug("Clicked on Search results to be deleted"); 
			Reporter.log("Clicked on Search results to be deleted"); 
			Thread.sleep(3000);
			
			//Click on Delete 
			highlightElement("Backoffice_HMC_Search_Delete");
			Thread.sleep(3000);
			getObject("Backoffice_HMC_Search_Delete").click();
			APP_LOGS.debug("Clicked on Delete Image"); 
			Reporter.log("Clicked on Delete Image"); 
			Thread.sleep(3000);
			
			isAlertPresent(driver);
			Thread.sleep(3000);

		/*	//Validating whether the created agent is Deleted
			//=====To Provide Search ID====//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_SearchID").clear();
			Thread.sleep(1000);
			getObject("Backoffice_HMC_User_SearchID").sendKeys(ID);
			APP_LOGS.debug("Given Search ID : "+ID);
			Reporter.log("Given Search ID : "+ID);			
			
			//=====To Click On Search Button======//
			Thread.sleep(3000);
			getObject("Backoffice_HMC_User_SearchButton").click();
			APP_LOGS.debug("Clicked On Search Button");
			Reporter.log("Clicked On Search Button");
				*/
			//=======To Retrieve ID=====//
			Thread.sleep(3000);
			highlightElement("Backoffice_HMC_User_SearchList_ID");
			Thread.sleep(3000);

			int count = driver.findElements(By.xpath("html/body/div[2]/table/tbody/tr[1]/th")).size();
			
			if((!(count == 0))&&getObject("Backoofice_HMC_Deletion_Error").isDisplayed())
			{
				APP_LOGS.debug("Removing failed: Current user cannot be removed while being active session user");
				Reporter.log("Removing failed: Current user cannot be removed while being active session user");
				capturescreenshot(this.getClass().getSimpleName()+"__"+count);
				throw new Exception("Removing failed: Current user cannot be removed while being active session user");
					
			}
			
			else if (!checkText("Backoffice_HMC_User_SearchList_ID","The search was finished. No results were found."))
		   	{
		   				  // screenshot
		   				 	hightlightscreenshot("Backoffice_HMC_User_SearchList_ID");
		   				 	APP_LOGS.debug("Failed to Validate deleted Agent");
		   				 	Reporter.log("Failed to Validate deleted Agent");	
		   				    fail=true;
		   				  // quit
		   				  		return;		
		   	}
			
			
			
			APP_LOGS.debug("Test Case Completed and End of the step");
			Reporter.log("Test Case Completed and End of the step");
			
		}
			
		catch(Exception t)
			{
				ErrorUtil.addVerificationFailure(t);
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				System.err.println("FAILED");
				APP_LOGS.debug("Test Case Failed");
				Reporter.log("Test Case Failed");
				throw t;
			}
			
		}

		@AfterMethod
		public void reportDataSetResult() {
			if (skip)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass()
						.getSimpleName(), count + 2, "SKIP");
			else if (fail) {
				isTestPass = false;
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass()
						.getSimpleName(), count + 2, "FAIL");
			} else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass()
						.getSimpleName(), count + 2, "PASS");

			skip = false;
			fail = false;
		}

		@AfterTest
		public void reportTestResult() {
			if (isTestPass)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases",
						TestUtil.getRowNum(suite_Can_BackOffice_xls, this.getClass()
								.getSimpleName()), "PASS");
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases",
						TestUtil.getRowNum(suite_Can_BackOffice_xls, this.getClass()
								.getSimpleName()), "FAIL");
			 closeBrowser();
		}
		@DataProvider
		public Object[][] getTestData() {
			return TestUtil
					.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
	}
