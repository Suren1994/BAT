package com.veo.suite.backoffice;


import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class BO_DateSelection extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void AbletodisplaytheOrders_for_theDesiredDateSelection(
			String uname,
			String pwd,
			String BackOffice_StartDate_Input,
			String BackOffice_EndDate_Input
			
			) throws Throwable,IOException{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
	
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing TC_BO_DateSelection");
		Reporter.log("Executing TC_BO_DateSelection");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Able to display the Orders for the Desired Date Selection");
		Reporter.log("Able to display the Orders for the Desired Date Selection");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		
		// webdriver
		openBrowser();
		APP_LOGS.debug("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		Reporter.log("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Backoffice URL");
		Reporter.log("Entered Backoffice URL");

		
		try
		{
//	====================================Login to Backoffice========================================================//

			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
//		====================================To Send Start Date========================================================//		
		getObject("BackOffice_StartDate").clear();
		getObject("BackOffice_StartDate").sendKeys(BackOffice_StartDate_Input);
		APP_LOGS.debug("Entered Start Date as: "+BackOffice_StartDate_Input);
		Reporter.log("Entered Start Date as: "+BackOffice_StartDate_Input);
		//Thread.sleep(3000);

//		====================================To Send End Date========================================================//
		getObject("BackOffice_EndDate").clear();
		getObject("BackOffice_EndDate").sendKeys(BackOffice_EndDate_Input);
		APP_LOGS.debug("Entered End Date as: "+BackOffice_EndDate_Input);
		Reporter.log("Entered End Date as: "+BackOffice_EndDate_Input);
		//Thread.sleep(3000);

//		====================================To Click on Refresh Button========================================================//
		//Thread.sleep(1000);
		getObject("Backoffice_RefreshButton").click();
		APP_LOGS.debug("Clicked Refresh Button");
		Reporter.log("Clicked Refresh Button");
		Thread.sleep(5000);

	
//		====================================To get row count in the table========================================================//

		List<WebElement> rows = driver.findElements(By.xpath("//span[@class='z-html']/a"));
		int totalRow = rows.size();
	   	    
	    //		====================================To compare whether the table having data========================================================//
		 if(totalRow>=1)
		 {
			 APP_LOGS.debug("Success: Order Details is displayed for the Selected Date....");
			 Reporter.log("Success: Order Details is displayed for the Selected Date....");
		 }
		 else
		 {
			 APP_LOGS.debug("Order Details is not available for the Selected Dates");
			 Reporter.log("Order Details is not available for the Selected Dates");
			 capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			 throw new Exception("Order Details is not available for the Selected Dates");
		 }
		 
		 //==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
		 
			}
		catch(Exception e)
		{
			ErrorUtil.addVerificationFailure(e);
			System.err.println("FAILED");
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Failed");
			Reporter.log("Failed");
			throw e;
							
		}
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		

