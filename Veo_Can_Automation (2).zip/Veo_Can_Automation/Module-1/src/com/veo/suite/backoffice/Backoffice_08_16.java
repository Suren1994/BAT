package com.veo.suite.backoffice;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Backoffice_08_16 extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
	
		@Test(dataProvider="getTestData")
			public void ability_to_see_Actuals_Targets_Differentials_displayingcorrectly(
			String uname,
			String pwd,
			String orderbtn_text,
			String Qty,
			String uname1,
			String pwd1
			) throws InterruptedException, IOException, AWTException,Exception, Throwable{
			count++;
				if(!runmodes[count].equalsIgnoreCase("Y")){
					throw new SkipException("Runmode for test set data set to no "+count);
				}
				
				//Starting point of the Test case
				APP_LOGS.debug("***************************************************************************************");
				Reporter.log("***************************************************************************************");
				APP_LOGS.debug("Executing Backoffice TC_08_16");
				Reporter.log("Executing Backoffice TC_08_16");
				APP_LOGS.debug("***************************************************************************************");
				Reporter.log("***************************************************************************************");
				APP_LOGS.debug("Ability to see that Actuals vs. Targets & Differentials are calculating and displaying correctly");
				Reporter.log("Ability to see that Actuals vs. Targets & Differentials are calculating and displaying correctly");
				APP_LOGS.debug("***************************************************************************************");
				Reporter.log("***************************************************************************************");
				APP_LOGS.debug("Username: "+uname +"& Password: "+pwd);
				Reporter.log("Username: "+uname +"& Password: "+pwd);
		
	
	//=================================== Open the Browser ===================================//
		openBrowser();
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
		
		//Enter the URL
		driver.get(CONFIG.getProperty("testSiteName"));
		APP_LOGS.debug("Opening Veo Admin");
		Reporter.log("Opening Veo Admin");
		try
		{
		
			
		//=================================== Login to Veo ===================================//
						if(!Login("StoreFront_LoginPage_Username","StoreFront_LoginPage_Password",
								"StoreFront_LoginPage_AgeCheckbox","StoreFront_LoginPage_LoginButton",
								uname,pwd)){
							// screenshot
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							fail=true;
							// quit
							return;
						}
					Thread.sleep(3000);
	//=================================== Verify Element exist ===================================//	
					
			          	if(!checkElementPresence("StoreFront_HomePage_Header")){
						// screenshot
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						// quit
						return;
					}
					
		  //=================================== Verify Title exist ===================================//	
						
					//	String[] final_qty = new String[10];
			
						//=================================To Retrieve a text from Create Order Label=======// 
						String LabelText = getObject("Backoffice_Create_Order").getText();
						APP_LOGS.debug("The label of the Order button present is: "+LabelText);
						Reporter.log("The label of the Order button present is: "+LabelText);
						Thread.sleep(2000);

				     	
						//======================To verify Label Text===================//
						//==============To click on Create Order Button====//
						if(LabelText.equals(orderbtn_text))
						{
						Thread.sleep(2000);
						highlightElement("Backoffice_Create_Order");
						getObject("Backoffice_Create_Order").click();
						APP_LOGS.debug("Clicked Create Order Button");
						Reporter.log("Clicked Create Order Button");
						Thread.sleep(5000);
						
						//Validating Off-Route Order		
						offRoutePopup();
				
						}
						
						//====To click on Order In Progress Button=============//
						else {
							Thread.sleep(2000);
							highlightElement("BackOffice_OrderInProgress");
							getObject("BackOffice_OrderInProgress").click();
							APP_LOGS.debug("Clicked Order In Progress Button");
							Reporter.log("Clicked Order In Progress Button");
							Thread.sleep(2000);

							//Clicking on Cancel button 
							highlightElement("BackOffice_CartPage_Cancel");
							getObject("BackOffice_CartPage_Cancel").click();
							APP_LOGS.debug("Clicked on cancel order button");
							Reporter.log("Clicked on cancel order button");
							
							//Clicking on Cancel yes button 
							highlightElement("BackOffice_CartPage_CancelOrderPopup_YesButton");
							getObject("BackOffice_CartPage_CancelOrderPopup_YesButton").click();
							APP_LOGS.debug("Clicked on cancel order yes button");
							Reporter.log("Clicked on cancel order yes button");
							Thread.sleep(2000);

							//Click on Create Order Button
							highlightElement("BackOffice_Homepage_CreateOrder");
							getObject("BackOffice_Homepage_CreateOrder").click();
							APP_LOGS.debug("Highlighted Create order button and clicked on Create Order button");
							Reporter.log("Highlighted Create order button and clicked on Create Order button");
							Thread.sleep(5000);
							
							
							
								//Validating Off-Route Order		
									offRoutePopup();
							
							Thread.sleep(2000);
						}
						//Click on Filter 
						getObject("BackOffice_CartPage_Filter").click();
						APP_LOGS.debug("Clicked on Filter");
						Reporter.log("Clicked on Filter");
						Thread.sleep(2000);
						
						//Entering the Order Qty
						highlightElement("Backoffice_CartPage_OrderQuantity0");
						getObject("Backoffice_CartPage_OrderQuantity0").clear();
						getObject("Backoffice_CartPage_OrderQuantity0").sendKeys(Qty);
						APP_LOGS.debug("Entered the quantity as: "+Qty);
						Reporter.log("Entered the quantity as: "+Qty);
						Thread.sleep(2000);
						
						
						//Click on Filter 
						getObject("BackOffice_CartPage_Filter").click();
						APP_LOGS.debug("Clicked on Filter");
						Reporter.log("Clicked on Filter");
						Thread.sleep(2000);
						
					/*	if(getObject("BackOffice_CartPage_OrderQuantity0").isDisplayed()) {
							for(int i=0;i<=3;i++) {
								driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).clear();
								driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).sendKeys("15");
								}
								APP_LOGS.debug("Entered the quantity for several products");
								Reporter.log("Entered the quantity for several products");
								Thread.sleep(2000);
						}
						else{
							APP_LOGS.debug("FAILED: Cannot find Oder Quanity Fields/Not able to Enter Order Quantity");
							Reporter.log("FAILED: Cannot find Oder Quanity Fields/Not able to Enter Order Quantity");
							capturescreenshot(this.getClass().getSimpleName()+"__"+count);
							throw new Exception("FAILED: Cannot find Oder Quanity Fields/Not able to Enter Order Quantity");
						}*/
						
						
							
						getObject("BackOffice_Continue").click();
						APP_LOGS.debug("Clicked on continue button");
						Reporter.log("Clicked on continue button");
						Thread.sleep(3000);
						
							//Validating Ignore and Continue
							ignoreAndContinue();
							Thread.sleep(3000);

							highlightElement("BackOffice_PlaceOder");
							getObject("BackOffice_PlaceOder").click();
							APP_LOGS.debug("Clicked on place order button");
							Reporter.log("Clicked on place order button");
												
							highlightElement("BackOffice_OrderNumber_Value");
							String order_no =getObject("BackOffice_OrderNumber_Value").getText();
							System.out.println("Order submitted succesfully and the Order No: "+order_no);
							APP_LOGS.debug("Order submitted succesfully and the Order No: "+order_no);
							Reporter.log("Order submitted succesfully and the Order No: "+order_no);
							Thread.sleep(3000);
			
		//============================ Switch to New tab ============================//	
							driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
							APP_LOGS.debug("Opening the New Tab");
							Reporter.log("Opening the New Tab");
							Thread.sleep(2000);
							
							//Opening the Replenishment Agent 
							driver.get(CONFIG.getProperty("backofficeurl"));
							APP_LOGS.debug("Entered the Backoffice URL");
							Reporter.log("Entered the Backoffice URL");
						
		//=================================== Login to Backoffice ===================================//
							
							if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname1,pwd1)){
								// screenshot
								capturescreenshot(this.getClass().getSimpleName()+"_"+count);
								fail=true;
								// quit
								return;
							}		
							Thread.sleep(3000);
		
							getObject("BackOffice_StartDate").clear();
							prntResults("Cleraed the start date field");
							
	//=================================== Clicking on Refresh button ===================================//
							highlightElement("Backoffice_RefreshButton");
							getObject("Backoffice_RefreshButton").click();
							APP_LOGS.debug("Clicked on Refresh Button"); 
							Reporter.log("Clicked on Refresh Button");
							Thread.sleep(5000);
							
	//=================================== Getting first Orders Delivery Date  ===================================//				
		
							
		if(!checkText("Backoffice_HomePage_Orders",order_no))
		{
				// screenshot
				APP_LOGS.debug("FAILED: OrderNo Mismatch");
				Reporter.log("FAILED: OrderNo Mismatch");		
				hightlightscreenshot("Backoffice_HomePage_Orders");
				fail=true;
				// quit
				return;		
		}
							
		APP_LOGS.debug("Passed: Validation of Order no"); 
		Reporter.log("Passed: Validation of Order no");
		Thread.sleep(3000);
		
		String ParentHandle = driver.getWindowHandle();
						
		getObject("Backoffice_HomePage_Orders")	.click();			
		APP_LOGS.debug("Clicked on 1st Orderno"); 
		Reporter.log("Clicked on 1st Orderno");
		Thread.sleep(5000);
		
		for (String winHandle : driver.getWindowHandles()) 
		{
		    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
		}	
	    System.out.println("Switched to new window: "+driver.getTitle());
		APP_LOGS.debug("Switched to new window: "+driver.getTitle());
		Reporter.log("Switched to new window: "+driver.getTitle());
		Thread.sleep(10000);
		
		//click on Amend Button 
		highlightElement("Backoffice_CartPage_AmendButton");
		getObject("Backoffice_CartPage_AmendButton").click();
		APP_LOGS.debug("Clicked on Amend button"); 
		Reporter.log("Clicked on Amend button");
		Thread.sleep(5000);
		
		String Orderqty = getObject("Backoffice_CartPage_OrderQuantity0").getAttribute("Value");
		APP_LOGS.debug("The Order Qty is: "+Orderqty); 
		Reporter.log("The Order Qty is: "+Orderqty);
		Thread.sleep(3000);		

		driver.switchTo().window(ParentHandle);
		APP_LOGS.debug("switched to previous tab"); 
		Reporter.log("switched to previous tab");
		Thread.sleep(3000);		
		
		if(!checkText("Backoffice_HomePage_ActualColumn_Value",Orderqty))
		{
				// screenshot
				APP_LOGS.debug("FAILED: Order quantity is Mismatched");
				Reporter.log("FAILED: Order quantity is Mismatched");		
				hightlightscreenshot("Backoffice_HomePage_ActualColumn");
				fail=true;
				// quit
				return;		
		}
				
		//Calculating Percentage Manually
		String actualvalue= getObject("Backoffice_HomePage_ActualColumn_Value").getText();
		float actualCol = Float.parseFloat(actualvalue);				
		APP_LOGS.debug("The actual column value is: "+actualCol); 
		Reporter.log("The actual column value is: "+actualCol);
		Thread.sleep(3000);						
							
		String targetvalue= getObject("Backoffice_HomePage_TargetColumn_Value").getText();
		float targetCol = Float.parseFloat(targetvalue);					
		APP_LOGS.debug("The actual column value is: "+targetCol); 
		Reporter.log("The actual column value is: "+targetCol);
		Thread.sleep(3000);							
		
		float percentage = (actualCol/targetCol)*100;
		String str_percentage=String.format("%.1f%%", percentage);
		System.out.println("The Percentage calculated manually is: "+str_percentage); 
		APP_LOGS.debug("The Percentage calculated manually is: "+str_percentage); 
		Reporter.log("The Percentage calculated manually is: "+str_percentage);
		Thread.sleep(3000);							
				

		if(!checkText("Backoffice_HomePage_PercentageColumn_Value",str_percentage))
		{
				// screenshot
				APP_LOGS.debug("FAILED: Backofffice Percentage Column is Mismatched");
				Reporter.log("FAILED: Backofffice Percentage Column is Mismatched");		
				hightlightscreenshot("Backoffice_HomePage_PercentageColumn");
				fail=true;
				// quit
				return;		
		}
				
							
		//Calculating Difference
		int difference =(int) (actualCol-targetCol);
		APP_LOGS.debug("The Difference calculated manually is: "+difference); 
		Reporter.log("The Percentage calculated manually is: "+difference);
		Thread.sleep(3000);							
		
		String Str_diff = Integer.toString(difference);
		if(!checkText("Backoffice_HomePage_DiffColumn",Str_diff))
		{
				// screenshot
				APP_LOGS.debug("FAILED: Backofffice difference Column is Mismatched");
				Reporter.log("FAILED: Backofffice difference Column is Mismatched");		
				hightlightscreenshot("Backoffice_HomePage_DiffColumn");
				fail=true;
				// quit
				return;		
		}
		
	
							APP_LOGS.debug("Test Passed");
							Reporter.log("Test Passed");	
							
							System.out.println("Test Completed");
							APP_LOGS.debug("Test Completed & End of the Step");
							Reporter.log("Test Completed & End of the Step");
		
			}
		
		catch (Exception t) 
		{
		System.err.println("Failed");
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		APP_LOGS.debug("Test Failed & End of the Step");
		Reporter.log("Test Failed & End of the Step");
		throw t;
		} 

	}
			
			@AfterMethod
			public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
			
			}
			
			@AfterTest
			public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
				
			@DataProvider
			public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		








