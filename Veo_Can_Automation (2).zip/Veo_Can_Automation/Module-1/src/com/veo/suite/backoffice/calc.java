package com.veo.suite.backoffice;

public class calc {
	public static void main(String arge[])
	{
		float actual = 23;
		float target = 47;
		float percentage = (actual/target)*100;
		System.out.println(percentage);
		System.out.println("The Percentage calculated manually is: "+String.format("%.1f%%", percentage)); 

		int diff = (int) (actual - target);
		System.out.println(diff);

	}

}

