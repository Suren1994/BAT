package com.veo.suite.backoffice;

import org.testng.SkipException;
import org.testng.annotations.BeforeSuite;

import com.veo.base.TestBase;
import com.veo.util.TestUtil;


public class TestSuiteBase extends TestBase{

	// check if the suite ex has to be skiped
		@BeforeSuite
		public void checkSuiteSkip() throws Exception{
			initialize();
			APP_LOGS.debug("Checking Runmode of Can_BackOffice_Suite");
			if(!TestUtil.isSuiteRunnable(suiteXls, "Can_BackOffice_Suite")){
				APP_LOGS.debug("Skipped Can_BackOffice_Suite as the runmode was set to NO");
				throw new SkipException("Runmode of Can_BackOffice_Suite set to no. So Skipping all tests in Suite Product Display");
			}
			
		}
}
