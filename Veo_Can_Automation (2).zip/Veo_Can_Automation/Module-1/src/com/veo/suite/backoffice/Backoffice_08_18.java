package com.veo.suite.backoffice;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Backoffice_08_18 extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void Geography_Selection(
			String uname,
			String pwd 			
			) throws InterruptedException, IOException, AWTException,Exception, Throwable{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_11_27");
		Reporter.log("Executing Backoffice TC_11_27");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to filter missing orders based on geography selection");
		Reporter.log("Ability to filter missing orders based on geography selection");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		try{

			//=================================== Login to Backoffice ===================================//
						
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}		
			Thread.sleep(5000);		
	
	//=======================================To click on Missing Order Tab===============================//			
		getObject("Backoffice_HomePage_MissingOrdersTab").click();
		APP_LOGS.debug("Clicked on Missing Order Tab");
		Reporter.log("Clicked on Missing Order Tab");
		Thread.sleep(3000);

	//=======================================To click on Refresh Button===============================//
		getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
		APP_LOGS.debug("Clicked On Refresh Button");
		Reporter.log("Clicked On Refresh Button");
		Thread.sleep(5000);

//		====================================To get row count in the table========================================================//
		Thread.sleep(3000);
		int tablerows = driver.findElements(By.xpath("//span[@class='z-html']/a")).size(); 
		APP_LOGS.debug("No.of.Rows is: "+tablerows);
		Reporter.log("No.of.Rows is: "+tablerows);
		
		
	    //====================================To compare whether the table having data========================================================//
		 if(tablerows!=0)
		 {
			 APP_LOGS.debug("The Missing Orders Tab contains data...");
			 Reporter.log("The Missing Orders Tab contains data...");
			 Thread.sleep(3000);		

		//==========================================To Select Root Territory in Geography Field=============================================//
			 	Thread.sleep(3000);		
			 	getObject("Backoffice_MissingOrders_Geography").click();
				APP_LOGS.debug("Selected Default Territory in Geography Field");
				Reporter.log("Selected Default Territory in Geography Field");
				
		//==========================================To Select Root Territory in Geography Field=============================================//
						Thread.sleep(3000);			
						getObject("Backoffice_HomePage_Delete").click();
						APP_LOGS.debug("Clicked On Delete Button");
						Reporter.log("Clicked On Delete Button");
						
		//=========================================To Click on Refresh button============================================//
						Thread.sleep(3000);		
						getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
						APP_LOGS.debug("Clicked On Refresh Button");
						Reporter.log("Clicked On Refresh Button");

		//==========================To Click Ok button in PopWindow==================//
						Thread.sleep(5000);		
						getObject("Backoffice_ErrorPopup_OKButton").click();
						APP_LOGS.debug("Clicked On Ok Button");
						Reporter.log("Clicked On Ok Button");
		//	====================================To get row count in the table========================================================//
						Thread.sleep(3000);
						int InitialRowCount = 0;
						int j = driver.findElements(By.xpath("//span[@class='z-html']/a")).size(); 
						if((j==0)&& !(driver.findElement(By.xpath("//span[@class='z-html']/a")).isDisplayed()))
						{
							List<WebElement> rows2 = driver.findElements(By.xpath("//span[@class='z-html']/a"));
							InitialRowCount = rows2.size();
						}
						else
						{
							APP_LOGS.debug("Cannot find the data in Missing orders tab");
							Reporter.log("Cannot find the data in Missing orders tab");
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							//throw new Exception("FAILED: Cannot find the data in Missing orders tab");
						}
						   
						//==========================================To click on Add Button in Geography Field=============================================//
						//Thread.sleep(3000);		
						getObject("Backoffice_AddButton").click();
						APP_LOGS.debug("Clicked on Add Button in Geography Field");
						Reporter.log("Clicked on Add Button in Geography Field");
						Thread.sleep(3000);			

						
						//==========================================To Select Root Node in Geography Field=============================================//
						getObject("Backoffice_GeographyWindow_Expand").click();
						APP_LOGS.debug("Clicked on Expand Arrow of Geography window");
						Reporter.log("Clicked on Expand Arrow of Geography window");
						Thread.sleep(3000);

						String desire_reg = getObject("Backoffice_GeographyWindow_Region").getText();
						System.out.println("The desired region is: "+desire_reg);
						APP_LOGS.debug("The desired region is: "+desire_reg);
						Reporter.log("The desired region is: "+desire_reg);
						Thread.sleep(3000);
						getObject("Backoffice_GeographyWindow_Region").click();
						APP_LOGS.debug("Clicked on the Desired Region");
						Reporter.log("Clicked on the Desired Region");
						Thread.sleep(3000);
						
						//=========================================To Click on Refresh button============================================//
						Thread.sleep(3000);				
						getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
						APP_LOGS.debug("Clicked On Refresh Button");
						Reporter.log("Clicked On Refresh Button");
						Thread.sleep(3000);			

						//====================================To get row count in the table========================================================//
						Thread.sleep(3000);
						int FinalRowCount;
						int m = driver.findElements(By.xpath("//span[@class='z-html']/a")).size(); 
						if(!(m==0))
						{
						List<WebElement> rows3 = driver.findElements(By.xpath("//span[@class='z-html']/a"));
						FinalRowCount = rows3.size();
																
						APP_LOGS.debug("Verifying Missing Order displays based on Geography Selection");
						Reporter.log("Verifying Missing Order displays based on Geography Selection");
						Thread.sleep(3000);			

						}
						else{
							APP_LOGS.debug("FAILED: Cannot find the data in geography field");
							Reporter.log("FAILED: Cannot find the data in geography field");
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							throw new Exception("FAILED: Cannot find the data in geography field");
						}
						
					    //====================================To compare whether the table having data========================================================//
						Thread.sleep(3000);		
						if(!Integer.toString(InitialRowCount).equals(Integer.toString(FinalRowCount)))
						 {
							 APP_LOGS.debug("Success: Missing Orders displayed based on Geography Selection");
							 Reporter.log("Success: Missing Orders displayed based on Geography Selection");
						 }
						 else
						 {
							 APP_LOGS.debug("FAILED: Missing Orders is not displayed based on Geography Selection");
							 Reporter.log("FAILED: Missing Orders is not displayed based on Geography Selection");
							 capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							 throw new Exception("FAILED: Missing Orders is not displayed based on Geography Selection");
						 }				
						
						
			//==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
		}
		 else
		 {
			 System.err.println("FAILED: No Missing Orders found");
			 APP_LOGS.debug("FAILED: No Missing Orders found");
			 Reporter.log("FAILED: No Missing Orders found");
			 capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			 throw new Exception("FAILED: No Missing Orders found");
		 }	
		}
		
		catch (Exception t) 
		{
		System.err.println("Failed");
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		APP_LOGS.debug("Test Failed & End of the Step");
		Reporter.log("Test Failed & End of the Step");
		throw t;
		} 
	
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		

