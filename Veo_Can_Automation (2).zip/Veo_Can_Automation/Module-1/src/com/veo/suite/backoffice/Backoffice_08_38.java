package com.veo.suite.backoffice;
import java.awt.AWTException;
import java.io.IOException;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Backoffice_08_38 extends TestSuiteBase {
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
	
	
	@Test(dataProvider="getTestData")
	public void Abilityto_flagan_emergencyorder(
			String uname,
			String pwd,
			String BackOfficeOrderStatus
			) throws InterruptedException, IOException, AWTException,Exception, Throwable{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_08_38");
		Reporter.log("Executing Backoffice TC_08_38");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to removed the emergency order flag");
		Reporter.log("Ability to removed the emergency order flag");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
	
		
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		
		try{
		
//====================================Login to Backoffice========================================================//
	

			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
		
		//==================================Click on Amended Order=====================================================//
				getObject("BackOffice_OrderStatus_Dropdown").clear();
				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(1000);	
				
				getObject("BackOffice_OrderStatus_Dropdown").sendKeys(BackOfficeOrderStatus);
				APP_LOGS.debug("Selecting BackOffice Order Status is: "+BackOfficeOrderStatus);
				Reporter.log("Selecting BackOffice Order Status is: "+BackOfficeOrderStatus);
				Thread.sleep(1000);	

				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(3000);

		//================================= Selecting Start Date==========================================================//

				getObject("BackOffice_StartDate").clear();
				APP_LOGS.debug("Cleared the Start Date");
				Reporter.log("Cleared the Start Date");
				Thread.sleep(3000);

		//=================================clicking on refresh button================================================================================//
				getObject("Backoffice_RefreshButton").click();
				APP_LOGS.debug("Clicked Refresh Button");
				Reporter.log("Clicked Refresh Button");
				Thread.sleep(5000);
					
				String parentHandle = driver.getWindowHandle();		// get the current window handle
				
				String Ordernumber = getObject("Backoffice_HomePage_Orders").getText();
								
				//clicking on first order
				getObject("Backoffice_HomePage_Orders").click();
				APP_LOGS.debug("Clicked Backoffice Order Number: "+Ordernumber);
				Reporter.log("Clicked Backoffice Order Number: "+Ordernumber);
				Thread.sleep(10000);

				for (String winHandle : driver.getWindowHandles()) 
				{
				    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
				   
				}		
				System.out.println("Switched to new window: "+driver.getTitle());
			    APP_LOGS.debug("Switched to new window: "+driver.getTitle());
				Reporter.log("Switched to new window: "+driver.getTitle());
				Thread.sleep(3000);

				WaitUntil_element_Visible("Backoffice_CartPage_AmendButton", 1000);
				//====================================clicking on Amend Button==============================================================================//			
						highlightElement("Backoffice_CartPage_AmendButton");	
						getObject("Backoffice_CartPage_AmendButton").click();
						APP_LOGS.debug("Clicked on Amend Button in Cart Page");
						Reporter.log("Clicked on Amend Button in Cart Page");
						Thread.sleep(3000);

				//====================================Clicked Emergency Order Checkbox==============================================================================//
						Thread.sleep(3000);
						highlightElement("Backoffice_EmergencyCheckbox");
						if(getObject("Backoffice_EmergencyCheckbox").isSelected())
						{
							APP_LOGS.debug("Emergency Flag is already set");
							Reporter.log("Emergency Flag is already set");
							Thread.sleep(2000);

						}
						
						else
						{						
						Thread.sleep(5000);
						highlightElement("Backoffice_EmergencyCheckbox");
						getObject("Backoffice_EmergencyCheckbox").click();
						APP_LOGS.debug("Success: Clicked Emergency Order Checkbox in Cart Page");
						Reporter.log("Success: Clicked Emergency Order Checkbox in Cart Page");
						}
				//==========================================To Stop the test cases=============================================//
						 driver.switchTo().window(parentHandle);		
						 APP_LOGS.debug("Switched to parent window: "+driver.getTitle());	
						 Reporter.log("Switched to parent window: "+driver.getTitle());
						 Thread.sleep(2000);
	
						APP_LOGS.debug("Test Case Completed and End of the step");	
						Reporter.log("Test Case Completed and End of the step");
											
						
		
		}
		catch (Exception t) 
		{
		System.err.println("Failed");
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		APP_LOGS.debug("Test Failed & End of the Step");
		Reporter.log("Test Failed & End of the Step");
		throw t;
		} 

}
    @AfterMethod
		public void reportDataSetResult(){
			if(skip)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
	
		}
		
		@AfterTest
		public void reportTestResult(){
			if(isTestPass)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
		}
		
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
		}
	}

