package com.veo.suite.backoffice;


import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class BO_FlaggedToAmendStatus extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void FlaggedOrderStatus_Should_ChangedtoAmendedOrder(
			String uname,
			String pwd,
			String BackOfficeOrderStatus,
			String BackOfficeOrderStatus1,
			String OrderQuantity,
			String BackOffice_StartDate_Input
			
			
			) throws Throwable,IOException{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing TC_BO_FlaggedToAmendStatus");
		Reporter.log("Executing TC_BO_FlaggedToAmendStatus");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("BackOffice Flagged Order Status Should Changed to Amended Order");
		Reporter.log("BackOffice Flagged Order Status Should Changed to Amended Order");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		
		// webdriver
		openBrowser();
		APP_LOGS.debug("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		Reporter.log("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Backoffice URL");
		Reporter.log("Entered Backoffice URL");

		
		try
		{
//	====================================Login to Backoffice========================================================//

			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}		
				
			Thread.sleep(3000);
			
			getObject("BackOffice_OrderStatus_Dropdown").clear();
			getObject("BackOffice_OrderStatus_Dropdown").click();
			getObject("BackOffice_OrderStatus_Dropdown").sendKeys(BackOfficeOrderStatus);
			getObject("BackOffice_OrderStatus_Dropdown").click();
			APP_LOGS.debug("Selecting Order Status is: "+BackOfficeOrderStatus);
			Reporter.log("Selecting Order Status is: "+BackOfficeOrderStatus);
			WaitUntil_element_tobe_clicked("BackOffice_StartDate",1000);

	//================================= Selecting Start Date==========================================================//

			getObject("BackOffice_StartDate").clear();
			APP_LOGS.debug("Cleared the Start Date Field");
			Reporter.log("Cleared the Start Date Field");
			WaitUntil_element_tobe_clicked("Backoffice_RefreshButton",1000);
	//=================================clicking on refresh button================================================================================//

			getObject("Backoffice_RefreshButton").click();
			APP_LOGS.debug("Clicked Refresh Button");
			Reporter.log("Clicked Refresh Button");
			Thread.sleep(5000);
			
			
			String parentHandle = driver.getWindowHandle();		// get the current window handle
			
			//clicking on first order
			String Ordernumber1 = BackofficeFindElements("//span[@class='z-html']/button",1);
			driver.findElement(By.xpath("//button[contains(.,'"+Ordernumber1+"')]")).click();
			APP_LOGS.debug("Clicked BackOffice Order Number:"+Ordernumber1);
			Reporter.log("Clicked BackOffice Order Number:"+Ordernumber1);
			Thread.sleep(3000);

			for (String winHandle : driver.getWindowHandles()) 
			{
			    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
			    System.out.println("Switched to new window: "+driver.getTitle());
				APP_LOGS.debug("Switched to new window: "+driver.getTitle());
				Reporter.log("Switched to new window: "+driver.getTitle());
								
			}		
			
			Thread.sleep(5000);

	//====================================clicking on Amend Button==============================================================================//			
					highlightElement("BackOffice_Amend");				
					getObject("BackOffice_Amend").click();
					APP_LOGS.debug("Clicked on Amend Button");
					Reporter.log("Clicked on Amend Button");
					Thread.sleep(5000);
				
				
					   for(int i=0;i<5;i++)
						 {
							   Thread.sleep(2000);
							  WebElement QuantityValue= driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']"));
							  QuantityValue.clear();
							  QuantityValue.sendKeys(OrderQuantity);
							  APP_LOGS.debug("Entered the Order Quantity");
							  Reporter.log("Entered the Order Quantity");
								
							  QuantityValue.sendKeys(Keys.TAB);
							  APP_LOGS.debug("Clicked on TAB");
							  Reporter.log("Clicked on TAB");
								
							  int j=i+1;
							  APP_LOGS.debug("Enter Order Quantity for "+j+" Product is: "+OrderQuantity);
							  Reporter.log("Enter Order Quantity for "+j+" Product is: "+OrderQuantity);
							  i=i+1;
						   }
					
				
				//============To Click on Continue Button======================//
						   Thread.sleep(3000);
						   getObject("BackOffice_Continue").click();
						   APP_LOGS.debug("Clicked Continue Button in Cart Page");
						   Reporter.log("Clicked Continue Button in Cart Page");
						   Thread.sleep(2000);

				//============To Click on Ignore and Continue Link===========//
						ignoreAndContinue();
						Thread.sleep(4000);

			//============To Click on Place Order Button===================//
						   getObject("BackOffice_PlaceOder").click();
						   APP_LOGS.debug("Clicked Place Order Button");
						   Reporter.log("Clicked Place Order Button");
						   Thread.sleep(5000);

				//===========To Switch Child Window to Parent Window(Backoffice Missing Tab)=============//
						   driver.switchTo().window(parentHandle); 
						   APP_LOGS.debug("Page Redirected to the BackOffice Page");
						   Reporter.log("Page Redirected to the BackOffice Page"); 
						   Thread.sleep(5000);
						   
						   
							getObject("BackOffice_StartDate").clear();
							getObject("BackOffice_StartDate").sendKeys(BackOffice_StartDate_Input);
							APP_LOGS.debug("Entered the Start Date");
							Reporter.log("Entered the Start Date"); 
							Thread.sleep(2000);
							   
							//Thread.sleep(3000);
							getObject("BackOffice_OrderStatus_Dropdown").clear();
							getObject("BackOffice_OrderStatus_Dropdown").click();
							getObject("BackOffice_OrderStatus_Dropdown").sendKeys(BackOfficeOrderStatus1);
							getObject("BackOffice_OrderStatus_Dropdown").click();
							APP_LOGS.debug("Selecting Order Status is: "+BackOfficeOrderStatus1);
							Reporter.log("Selecting Order Status is: "+BackOfficeOrderStatus1);
							Thread.sleep(3000);

						   
				//============To Click on Refresh Button========================//
						   getObject("Backoffice_RefreshButton").click();
						   APP_LOGS.debug("Clicked Refresh Button");
						   Reporter.log("Clicked Refresh Button");
							Thread.sleep(3000);

				//===================================To get row count in the table========================================================//
							
							List<WebElement> rows = driver.findElements(By.xpath("//span[@class='z-html']/button"));
							int totalRow = rows.size();
							APP_LOGS.debug("Number of Rows in this Table: "+totalRow);
							Reporter.log("Number of Rows in this Table: "+totalRow);
							Thread.sleep(3000);
							
				//============To Check the just Placed Order is exist in the table=====//
						   
						   for(int j=1;j<=totalRow;j++)
						   {
							   Thread.sleep(3000);
												   
							   	String BacOfceTableOrderNumber = driver.findElement(By.xpath("//table/tbody[2]/tr["+j+"]/td[3]/div/span/button")).getText();
							   	prntResults("Order No in Ammended Orders list is : "+BacOfceTableOrderNumber);
								String BacOfceTableOrderStatus = driver.findElement(By.xpath("//table/tbody[2]/tr["+j+"]/td[4]/div")).getText();
							   	prntResults("Order Status in Ammended Orders list is : "+BacOfceTableOrderStatus);

							   Thread.sleep(3000);
							   if(BacOfceTableOrderNumber.equals(Ordernumber1))
							   {
								   APP_LOGS.debug("Success: Order Status is Changed '"+BackOfficeOrderStatus+"' to : "+BacOfceTableOrderStatus);
								   Reporter.log("Success: Order Status is Changed '"+BackOfficeOrderStatus+"' to : "+BacOfceTableOrderStatus);
								   break;
							   }
							   else
							   {
								   if(j==totalRow)
								   {
									   APP_LOGS.debug("FAILED: Order Status is not changed from Flagged to Amend");
									   Reporter.log("FAILED: Order Status is not changed from Flagged to Amend");
									   capturescreenshot(this.getClass().getSimpleName() + "_" + count);
									   throw new Exception("FAILED: Order Status is not changed from Flagged to Amend");
								   }
							   }   
						   }
							
	
					
		 //==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
		 
			}
		catch(Exception e)
		{
			ErrorUtil.addVerificationFailure(e);
			System.err.println("FAILED");
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Failed");
			Reporter.log("Failed");
			throw e;
							
		}
		
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		

