package com.veo.suite.backoffice;

import java.awt.AWTException;
import java.io.IOException;
import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Backoffice_08_19 extends TestSuiteBase{

	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void SelectdesiredERPnumber_and_RedirectOrderPage(
			String uname,
			String pwd, 	
			String title
			) throws InterruptedException, IOException, AWTException,Exception, Throwable{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_11_28");
		Reporter.log("Executing Backoffice TC_11_28");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("ability to click on ERP number to be re-directed to the same order sheet as the retailer");
		Reporter.log("ability to click on ERP number to be re-directed to the same order sheet as the retailer");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");	
		
		try{
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}		
			Thread.sleep(5000);		
	
	//=====================To Click on Missing Order Tab================//
		getObject("Backoffice_HomePage_MissingOrdersTab").click();
		APP_LOGS.debug("Clicked on Missing Order Tab");
		Reporter.log("Clicked on Missing Order Tab");
		Thread.sleep(1000);

	//=====================To Click on Refresh Button===================//
		Thread.sleep(1000);
		getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
		APP_LOGS.debug("Clicked on Refresh Button");
		Reporter.log("Clicked on Refresh Button");
		Thread.sleep(1000);

		
//		====================================To get row count in the table========================================================//
		Thread.sleep(3000);
		int tablerows = driver.findElements(By.xpath("//span[@class='z-html']/a")).size(); 
		APP_LOGS.debug("No.of.Rows is: "+tablerows);
		Reporter.log("No.of.Rows is: "+tablerows);
		
		
	    //====================================To compare whether the table having data========================================================//
		 if(tablerows!=0)
		 {
			 APP_LOGS.debug("The Missing Orders Tab contains data...");
			 Reporter.log("The Missing Orders Tab contains data...");
		 	
			 String parentHandle = driver.getWindowHandle();		
			 APP_LOGS.debug("Get the current window handle");
			 Reporter.log("Get the current window handle");
				
			 //=====================To Click on First ERP Number ===================//
			 String ERPNumber=BackofficeFindElements("//span[@class='z-html']/a",11);
			 APP_LOGS.debug("The Selected ERP Number is : "+ERPNumber);
			 Reporter.log("The Selected ERP Number is : "+ERPNumber);
			 Thread.sleep(3000);
			 
			 driver.findElement(By.linkText(ERPNumber)).click();
			 APP_LOGS.debug("Clicked on First ERP Number");
			 Reporter.log("Clicked on First ERP Number");
			 Thread.sleep(10000);
			 
			 for (String winHandle : driver.getWindowHandles()) 
			 {
				driver.switchTo().window(winHandle);
			 }		
		
			 APP_LOGS.debug("Switched to Window: "+driver.getTitle());
			 Reporter.log("Switched to Window: "+driver.getTitle());
			 Thread.sleep(5000);

			 //==========To Compare the Title of the Window==================//
			   if(!compareTitle(title)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			   }	
			
			   //======================To Click On Man Icon=================//
			   highlightElement("Backoffice_StoreFrontPage_ManIkon");
			   getObject("Backoffice_StoreFrontPage_ManIkon").click();
			   APP_LOGS.debug("Clicked on Man Ikon");
			   Reporter.log("Clicked Man Ikon");
				 Thread.sleep(3000);

			   //======================To Click On MyAccount Option=================//
			   highlightElement("Backoffice_StoreFront_MyAccount");
			   getObject("Backoffice_StoreFront_MyAccount").click();
			   APP_LOGS.debug("Clicked on MyAccount");
			   Reporter.log("Clicked on MyAccount");
			   Thread.sleep(3000);

			   //======================To Retrieve UserName (or) ERP Number=================//
			   highlightElement("Backoffice_MyAccountPage_StoreNumber");
			   String ERPNumber1 = getObject("Backoffice_MyAccountPage_StoreNumber").getAttribute("Value");
			   APP_LOGS.debug("User Name (or) ERP Number in My Account Page : "+ERPNumber1);
			   Reporter.log("User Name (or) ERP Number in My Account Page : "+ERPNumber1);
			   Thread.sleep(3000);

			   ERPNumber1 = ERPNumber1.trim();
			   Thread.sleep(3000);
			   if(ERPNumber.equals(ERPNumber1))
			   {			   
			   APP_LOGS.debug("Success: Page redirected to VEO Home Page for Same Customer");
			   Reporter.log("Success: Page redirected to VEO Home Page for Same Customer");
			   Thread.sleep(3000);

			   }
			   
			   else
			   {
				   APP_LOGS.debug("FAILED: Page is not redirected to VEO Home Page for the Selected ERP");
				   Reporter.log("FAILED: Page is not redirected to VEO Home Page for the Selected ERP");
				   capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				   throw new Exception("FAILED: Page is not redirected to VEO Home Page for the Selected ERP");
			   }
			   
			   driver.switchTo().window(parentHandle);
			   APP_LOGS.debug("Switched back to Parent window: "+driver.getTitle());
			   Reporter.log("Switched back to Parent window: "+driver.getTitle());
			   Thread.sleep(3000);

			   
			   //==========================================To Stop the test cases=============================================//
			   APP_LOGS.debug("Test Case Completed and End of the step");
			   Reporter.log("Test Case Completed and End of the step");
		 	   
			   
			}
		
		 else
		 {
			 System.out.println("FAILED: No Missing Orders found");
			 APP_LOGS.debug("FAILED: No Missing Orders found");
			 Reporter.log("FAILED: No Missing Orders found");
			 capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			 throw new Exception("FAILED: No Missing Orders found");
		 }	
		}
		
		catch (Exception t) 
		{
		System.err.println("Failed");
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		APP_LOGS.debug("Test Failed & End of the Step");
		Reporter.log("Test Failed & End of the Step");
		throw t;
		} 
		
				
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		

