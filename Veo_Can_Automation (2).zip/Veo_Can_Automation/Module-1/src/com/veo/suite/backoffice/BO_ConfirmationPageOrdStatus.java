package com.veo.suite.backoffice;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class BO_ConfirmationPageOrdStatus extends TestSuiteBase {
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
	
	
	@Test(dataProvider="getTestData")
	public void Backoffice_ConfirmationPageOrdStatus(
			String VEO_Username,
			String VEO_PWD,
			String CreatOrderLabel,
			String OrderQuantity,
			String PageTitle,
			String OrderStatus
			
			) throws Throwable,IOException{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}

		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing TC_BO_ConfirmationPageOrdStatus");
		Reporter.log("Executing TC_BO_ConfirmationPageOrdStatus");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Verify Order Status is Order Confirmed in Order Confirmation Page");
		Reporter.log("Verify Order Status is Order Confirmed in Order Confirmation Page");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("VEO_Username: "+VEO_Username+" & Password:"+VEO_PWD);
		Reporter.log("VEO_Username: "+VEO_Username+" & Password:"+VEO_PWD);
		
		
		// webdriver
		openBrowser();
		APP_LOGS.debug("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		Reporter.log("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		
		driver.get(CONFIG.getProperty("testSiteName"));
		APP_LOGS.debug("Entered VeO URL");
		Reporter.log("Entered VeO URL");

		try
		{
		
//====================================Login to Backoffice========================================================//
	
			if(!Login("StoreFront_LoginPage_Username","StoreFront_LoginPage_Password","StoreFront_LoginPage_AgeCheckbox","StoreFront_LoginPage_LoginButton",VEO_Username,VEO_PWD)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}	
				
			Thread.sleep(3000);
		
		String LabelTest = getObject("Backoffice_Create_Order").getText();
		
		if (LabelTest.equals(CreatOrderLabel)) 
		{
			Thread.sleep(2000);
			highlightElement("Backoffice_Create_Order");
			getObject("Backoffice_Create_Order").click();
			APP_LOGS.debug("Clicked Create Order Button");
			Reporter.log("Clicked Create Order Button");

			offRoutePopup();
			Thread.sleep(3000);

		}
		// ====To click on Order In Progress Button=============//
		else {
			Thread.sleep(2000);
			highlightElement("BackOffice_OrderInProgress");
			getObject("BackOffice_OrderInProgress").click();
			APP_LOGS.debug("Clicked Order In Progress Button");
			Reporter.log("Clicked Order In Progress Button");
			Thread.sleep(3000);

		}

			Thread.sleep(5000);
			
			getObject("BackOffice_CartPage_Filter").click();
			APP_LOGS.debug("Clicked on Cart Filter");
			Reporter.log("Clicked on Cart Filter");
			Thread.sleep(3000);

			getObject("Backoffice_CartPage_OrderQuantity0").clear();
			getObject("Backoffice_CartPage_OrderQuantity0").sendKeys(OrderQuantity);
			APP_LOGS.debug("Entered Order Quantity is: "+OrderQuantity);
			Reporter.log("Entered Order Quantity is: "+OrderQuantity);	
			
			getObject("Backoffice_CartPage_OrderQuantity0").sendKeys(Keys.TAB);
			APP_LOGS.debug("Clicked on TAB");
			Reporter.log("Clicked on TAB");	
			Thread.sleep(3000);

			getObject("BackOffice_Continue").click();
			APP_LOGS.debug("Clicked BackOffice Continue Button");
			Reporter.log("Clicked BackOffice Continue Button");
			Thread.sleep(3000);
			
			ignoreAndContinue();
			Thread.sleep(3000);
			
			 getObject("BackOffice_PlaceOder").click();
			 APP_LOGS.debug("Clicked on Place Order Button");
			 Reporter.log("Clicked on Place Order Button");
			 Thread.sleep(3000);
			 
			 String CurrentTitle=driver.getTitle();
			 
			 if(CurrentTitle.equals(PageTitle))
			 {
				 APP_LOGS.debug("Current Page Title is: "+CurrentTitle);
				 Reporter.log("Current Page Title is: "+CurrentTitle);
				 Thread.sleep(3000);

			 }
			 
			 String FrondendOrdStatus = driver.findElement(By.xpath(".//*[@id='page-content']/div/div[2]/div[1]/div[1]/div/div/div")).getText();
			 
			 if(FrondendOrdStatus.equals(OrderStatus))
			 {
				 APP_LOGS.debug("Success: Order Status in Order Confirmation Page is : "+FrondendOrdStatus);
				 Reporter.log("Success: Order Status in Order Confirmation Page is : "+FrondendOrdStatus); 
			 }
		
	 //==========================================To Stop the test cases=============================================//
    				 APP_LOGS.debug("Test Case Completed and End of the step");
    				 Reporter.log("Test Case Completed and End of the step");
		
		}
		catch(Exception e)
		{
			ErrorUtil.addVerificationFailure(e);
			System.err.println("FAILED");
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Failed");
			Reporter.log("Failed");
			throw e;
							
		}
}
    @AfterMethod
		public void reportDataSetResult(){
			if(skip)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
	
		}
		
		@AfterTest
		public void reportTestResult(){
			if(isTestPass)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
		}
		
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
		}
	}

