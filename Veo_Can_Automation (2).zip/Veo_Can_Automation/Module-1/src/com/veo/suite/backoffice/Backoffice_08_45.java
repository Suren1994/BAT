package com.veo.suite.backoffice;


import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

	public class Backoffice_08_45 extends TestSuiteBase{

		String runmodes[]=null;
		static boolean fail=false;
		static boolean skip=false;
		static boolean isTestPass=true;
		static int count=-1;
		// Runmode of test case in a suite
			@BeforeTest
			public void checkTestSkip(){
				
				if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
					APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
					throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
				}
				runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
			}
		@Test(dataProvider="getTestData")
		public void cockpit_permissions_as_Replenishment_agent(
				String uname,
				String pwd,
				String ERP,
				String CartPagTitle,
				String BackofficeOrderStatus,
				String OrderQuantity
				) throws InterruptedException, IOException, AWTException,Exception, Throwable{
			count++;
			if(!runmodes[count].equalsIgnoreCase("Y")){
				throw new SkipException("Runmode for test set data set to no "+count);
			}
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Executing Backoffice TC_08_45");
			Reporter.log("Executing Backoffice TC_08_45");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Validate cockpit permissions as a Replenishment Agent");
			Reporter.log("Validate cockpit permissions as a Replenishment Agent");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
			Reporter.log("Username: "+uname+" & Password:"+pwd);
		
			// webdriver
			openBrowser();	
			APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
			Reporter.log("Browser up: "+this.getClass().getSimpleName());
		
			
			driver.get(CONFIG.getProperty("backofficeurl"));
			APP_LOGS.debug("Entered Replenishment cockpit URL");
			Reporter.log("Entered Replenishment cockpit URL");
			
			
			try{
				
				//=================================== Login to Backoffice ===================================//
							
				if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
					// screenshot
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit
					return;
				}
				Thread.sleep(3000);
					
		
				//=================================== Clicking on Create Order ===================================//
						highlightElement("BackOffice_CreateOrderButton");
						getObject("BackOffice_CreateOrderButton").click();
						APP_LOGS.debug("Clicked on Create Order Button");
						Reporter.log("Clicked on Create Order Button");
						Thread.sleep(3000);

	          //=================================== Entering ERP Number ===================================//
						highlightElement("Backoffice_CreateOrderButton_ERP");
						getObject("Backoffice_CreateOrderButton_ERP").sendKeys(ERP);
						APP_LOGS.debug("Entered the ERP Number");
						Reporter.log("Entered the ERP Number");
						Thread.sleep(3000);

						String ParentWindow = driver.getWindowHandle();
	      //=================================== Clicking on OK ===================================//
						getObject("Backoffice_CreateOrderButton_Ok").click();
						APP_LOGS.debug("Clicked on OK Button "); 
						Reporter.log("Clicked on OK Button "); 
						Thread.sleep(3000);

						APP_LOGS.debug("Trying to Open the Cart Page of Entered ERP Number..."); 
						Reporter.log("Trying to Open the Cart Page of Entered ERP Number..."); 
						
         //==================== Switch focus of WebDriver to the next found window handle (that's your newly opened window)==================//
						for (String winHandle : driver.getWindowHandles()) 
						{
						    driver.switchTo().window(winHandle);
						}
						APP_LOGS.debug("Switched to new Window: "+driver.getTitle()); 
						Reporter.log("Switched to new Window: "+driver.getTitle()); 
						Thread.sleep(3000);
						
						APP_LOGS.debug("Validating the Page Title of the newly opened window"); 
						Reporter.log("Validating the Page Title of the newly opened window"); 
						
						String Cart_PageTitle = driver.getTitle();
						if(!compareTitle(Cart_PageTitle))
						{
							// screenshot
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							fail=true;
							// quit
							return;
						}
				
						Thread.sleep(3000);
						driver.switchTo().window(ParentWindow);
						APP_LOGS.debug("Switched to Parent Window: "+driver.getTitle()); 
						Reporter.log("Switched to Parent Window: "+driver.getTitle()); 
						Thread.sleep(3000);
						
	//==================================Click on Flagged Order=====================================================//
						Thread.sleep(3000);
						getObject("BackOffice_OrderStatus_Dropdown").clear();
						getObject("BackOffice_OrderStatus_Dropdown").click();
						APP_LOGS.debug("Clicked on Order Status");
						Reporter.log("Clicked on Order Status");
						Thread.sleep(1000);	
						
						getObject("BackOffice_OrderStatus_Dropdown").sendKeys(BackofficeOrderStatus);
						APP_LOGS.debug("Selecting BackOffice Order Status as: "+BackofficeOrderStatus);
						Reporter.log("Selecting BackOffice Order Status as: "+BackofficeOrderStatus);
						Thread.sleep(1000);		
						
						getObject("BackOffice_OrderStatus_Dropdown").click();
						APP_LOGS.debug("Clicked on Order Status");
						Reporter.log("Clicked on Order Status");
						Thread.sleep(4000);		
						
			//================================= Selecting Start Date==========================================================//

						getObject("BackOffice_StartDate").clear();
						APP_LOGS.debug("Cleared the Start Date");
						Reporter.log("Cleared the Start Date");
						Thread.sleep(3000);

		//=================================clicking on refresh button================================================================================//
						getObject("Backoffice_RefreshButton").click();
						APP_LOGS.debug("Clicked on Refresh Button");
						Reporter.log("Clicked on Refresh Button");
						Thread.sleep(10000);
						
												
						String Ordernumber = getObject("Backoffice_HomePage_Orders").getText();
						
				//=========================clicking on first order==============================//
						getObject("Backoffice_HomePage_Orders").click();
						APP_LOGS.debug("Clicked Order Number is: "+Ordernumber);
						Reporter.log("Clicked Order Number is: "+Ordernumber );
						Thread.sleep(10000);

						for (String winHandle : driver.getWindowHandles()) 
						{
						    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
						
						}		
						APP_LOGS.debug("Switched to new window: "+driver.getTitle());
						Reporter.log("Switched to new window: "+driver.getTitle());
						
						WaitUntil_element_Visible("Backoffice_CartPage_AmendButton", 1000);
						
				//====================================clicking on Amend Button==============================================================================//			
						highlightElement("Backoffice_CartPage_AmendButton");	
						getObject("Backoffice_CartPage_AmendButton").click();
						APP_LOGS.debug("Clicked on Amend Button in Cart Page");
						Reporter.log("Clicked on Amend Button in Cart Page");
						Thread.sleep(5000);
						
						int count = driver.findElements(By.xpath(".//*[@id='quantity-0']")).size();

						if(!(count == 0))
						{
							for(int i=0;i<=3;i++)
							{
								driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).clear();
								driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']")).sendKeys(OrderQuantity);
								APP_LOGS.debug("Entered the Value for quantity: "+i);
							    Reporter.log("Entered the Value for quantity: "+i);
							}
						}
						else
						{
							APP_LOGS.debug("FAILED: Could not find the Cart Quanity field");
							Reporter.log("FAILED: Could not find the Cart Quanity field");
							capturescreenshot(this.getClass().getSimpleName()+"__"+count);
							throw new Exception("FAILED: Could not find the Cart Quanity field");
						}
					    
						
						//click on Continue 
						getObject("Backoffice_CartPage_Continue").click();
						APP_LOGS.debug("Clicked on Continue");
						Reporter.log("Clicked on Continue");
						Thread.sleep(4000);
						
						//Validating Ignore and Continue
						ignoreAndContinue();
						Thread.sleep(4000);
						
						//click on Place Order 
						getObject("Backoffice_CartPage_PlaceOrder").click();
						APP_LOGS.debug("Clicked on Place Order");
						Reporter.log("Clicked on Place Order");
						Thread.sleep(4000);
						
						//Fetch the Order No 
						String new_Orderno = getObject("BackOffice_Front_OrderNumber").getText();
						APP_LOGS.debug("The newly created order no is: "+new_Orderno);
						Reporter.log("The newly created order no is: "+new_Orderno);
						Thread.sleep(4000);
						
						driver.switchTo().window(ParentWindow);
						APP_LOGS.debug("Switched to Parent Window: "+driver.getTitle()); 
						Reporter.log("Switched to Parent Window: "+driver.getTitle()); 
						Thread.sleep(3000);
				
						
		//=================================== Clicking on Logout button ===================================//
						highlightElement("Backoffice_Logout");
						getObject("Backoffice_Logout").click();
						APP_LOGS.debug("Clicked on Logout Button"); 
						Reporter.log("Clicked on Logout Button"); 
						Thread.sleep(3000);
						
						
						
						APP_LOGS.debug("Test completed and End of the Step"); 
						Reporter.log("Test completed and End of the Step"); 
						

			}
		
			catch (Exception t) 
			{
			System.err.println("Failed");
			ErrorUtil.addVerificationFailure(t);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Test Failed & End of the Step");
			Reporter.log("Test Failed & End of the Step");
			throw t;
			} 
					}
						
					     @AfterMethod
							public void reportDataSetResult(){
								if(skip)
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
								else if(fail){
									isTestPass=false;
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
								}
								else
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
								
								skip=false;
								fail=false;
						
							}
							
							@AfterTest
							public void reportTestResult(){
								if(isTestPass)
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
								else
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
								closeBrowser();
							}
							
							@DataProvider
							public Object[][] getTestData(){
								return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
							}
						}
		
		

