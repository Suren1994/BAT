package com.veo.suite.backoffice;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Backoffice_08_22 extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void see_missing_EDIorder(
			String uname,
			String pwd,
			String primarychannel
			) throws InterruptedException, IOException, AWTException,Exception, Throwable{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_08_22");
		Reporter.log("Executing Backoffice TC_08_22");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to see a missing EDI order in the replenishment cockpit");
		Reporter.log("Ability to see a missing EDI order in the replenishment cockpit");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		try{
			//=================================== Login to Backoffice ===================================//
			
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}		
			Thread.sleep(3000);	
	
	//=====================To Click on Missing Order Tab================//
		getObject("Backoffice_HomePage_MissingOrdersTab").click();
		APP_LOGS.debug("Clicked on Missing Order Tab");
		Reporter.log("Clicked on Missing Order Tab");
		Thread.sleep(1000);

	//=====================To Click on Refresh Button===================//
		getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
		APP_LOGS.debug("Clicked on Refresh Button");
		Reporter.log("Clicked on Refresh Button");
		Thread.sleep(3000);

	//		====================================To get row count in the table========================================================//
		int totalRow;
		int r = driver.findElements(By.xpath("//span[@class='z-html']/a")).size(); 
		if(!(r==0))
		{
		List<WebElement> rows = driver.findElements(By.xpath("//span[@class='z-html']/a"));
		totalRow = rows.size();
	    //APP_LOGS.debug("Number of Rows in this Table: "+totalRow);
	    
		APP_LOGS.debug("The Row size of Missing Orders Tab is: "+totalRow);
	    Reporter.log("The Row size of Missing Orders Tab is: "+totalRow);
		Thread.sleep(3000);

		}
		else{
			APP_LOGS.debug("FAILED: Cannot find the rows in Missing Orders tab");
			Reporter.log("FAILED: Cannot find the rows in Missing Orders tab");
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("FAILED: Cannot find the rows in Missing Orders tab");
		}
	    //		====================================To compare whether the table having data========================================================//
		 if(totalRow!=0)
		 {
			 APP_LOGS.debug("The Missing Orders Tab contains data...");
			 Reporter.log("The Missing Orders Tab contains data...");
		 		
			 	driver.findElement(By.xpath("//i[@ytestid='typeComboBox']/input[@class='z-combobox-inp']")).clear();
				getObject("Backoffice_MissingOrders_PrimaryChannel").click();
				getObject("Backoffice_MissingOrders_PrimaryChannel").sendKeys(primarychannel);
				getObject("Backoffice_MissingOrders_PrimaryChannel").click();
				APP_LOGS.debug("Selecting Order Status is: "+primarychannel);
				Reporter.log("Selecting Order Status is: "+primarychannel);
				//WaitUntil_element_tobe_clicked("BackOffice_MissigorderRefresh_Button",1000);
		
				getObject("BackOffice_MissigorderRefresh_Button").click();
				APP_LOGS.debug("Clicked on Refresh button");
				Reporter.log("Clicked on Refresh button");
				Thread.sleep(3000);
				
				int errorcount = driver.findElements(By.xpath("//span[contains(.,'No results found. Please amend your search')]")).size();
				APP_LOGS.debug("The size of the Error count is: "+errorcount);
				Reporter.log("The size of the Error count is: "+errorcount);
				Thread.sleep(3000);
				
				if(!(errorcount == 0))
				{
					getObject("Backoffice_NoSearchFound_Error_OkButton").click();
					APP_LOGS.debug("Clicked on OK Button in No Results Found Error");
					Reporter.log("Clicked on OK Button in No Results Found Error");
					Thread.sleep(3000);
				}
				else
				{
					APP_LOGS.debug("Data are displayed as per the Selected criteria");
					Reporter.log("Data are displayed as per the Selected criteria");
					Thread.sleep(3000);
				}
		//==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
				 
			}
		 
		 else
		 {
			 System.err.println("No Missing Orders found");
			 APP_LOGS.debug("No Missing Orders found");
			 Reporter.log("No Missing Orders found");
			 capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			 throw new Exception("No Missing Orders found");
		  }	
		}
		
			catch(Exception e)
			{
				System.err.println("Failed");
				ErrorUtil.addVerificationFailure(e);
				capturescreenshot(this.getClass().getSimpleName() + "_" + count);
				APP_LOGS.debug("Failed");
				Reporter.log("Failed");
				throw e;
				
			}
		
				
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

	

