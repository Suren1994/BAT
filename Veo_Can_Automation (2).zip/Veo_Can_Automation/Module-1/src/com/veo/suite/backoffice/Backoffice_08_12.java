package com.veo.suite.backoffice;

import java.awt.AWTException;
import java.io.IOException;
import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

	public class Backoffice_08_12 extends TestSuiteBase{

		String runmodes[]=null;
		static boolean fail=false;
		static boolean skip=false;
		static boolean isTestPass=true;
		static int count=-1;
		// Runmode of test case in a suite
			@BeforeTest
			public void checkTestSkip(){
				
				if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
					APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
					throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
				}
				runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
			}
		
		
		@Test(dataProvider="getTestData")
		public void to_Access_to_view_History_Comments(
				String uname,
				String pwd
				) throws InterruptedException, IOException, AWTException,Exception, Throwable{
			count++;
			if(!runmodes[count].equalsIgnoreCase("Y")){
				throw new SkipException("Runmode for test set data set to no "+count);
			}

			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Executing Backoffice TC_11_15");
			Reporter.log("Executing Backoffice TC_11_15");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Able to Access to view History Comments by clicking on the  I  icon");
			Reporter.log("Able to Access to view History Comments by clicking on the  I  icon");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
			Reporter.log("Username: "+uname+" & Password:"+pwd);
		
			// webdriver
			openBrowser();
			APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
			Reporter.log("Browser up: "+this.getClass().getSimpleName());
			
			driver.get(CONFIG.getProperty("backofficeurl"));
			APP_LOGS.debug("Entered Replenishment cockpit URL");
			Reporter.log("Entered Replenishment cockpit URL");
			
			
			try{
				
			//==================================== Login to Backoffice ====================================//
				if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
					// screenshot
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit
					return;
				}
				Thread.sleep(5000);		
			
        //==================================== Entering the Start Date ====================================//
						getObject("BackOffice_StartDate").clear();
						APP_LOGS.debug("Cleared the Start Date");
						Reporter.log("Cleared the Start Date");
						Thread.sleep(3000);
						
       //==================================== Clicking on Refresh button ====================================//
						highlightElement("Backoffice_RefreshButton");
						getObject("Backoffice_RefreshButton").click();
						APP_LOGS.debug("Clicked on Refresh Button "); 
						Reporter.log("Clicked on Refresh Button "); 
						Thread.sleep(5000);
	
      //==================================== Clicking on  Comment icon ====================================//
						
						highlightElement("Backoffice_CommentsColumn_Order1");
						getObject("Backoffice_CommentsColumn_Order1").click();
						APP_LOGS.debug("Clicked on first Comment");
						Reporter.log("Clicked on first Comment");
						Thread.sleep(5000);
						
	//==================================== Printing the Comments ====================================//
						
						
						int rowcount = driver.findElements(By.xpath("html/body/div[4]/div[3]/div/div/div/div/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr")).size();
						System.out.println("No.Of.Comments: "+rowcount);
						APP_LOGS.debug("No.Of.Comments: "+rowcount);
						Reporter.log("No.Of.Comments: "+rowcount);
						Thread.sleep(3000);
						
						String comm_arr[] = new String[10];
						for(int i=1;i<=rowcount;i++)
						{
						comm_arr[i] = driver.findElement(By.xpath("html/body/div[4]/div[3]/div/div/div/div/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr["+i+"]/td[1]/div/span")).getText();
						System.out.println("The comments are:");
						System.out.println(comm_arr[i]);
						APP_LOGS.debug("The comments are: ");
						APP_LOGS.debug(comm_arr[i]);
						Reporter.log("The comments are: ");
						Reporter.log(comm_arr[i]);
						}
						
						APP_LOGS.debug("Printed the Added Comments in Console");
						Reporter.log("Printed the Added Comments in Console");
						
						System.out.println("Test Passed");
						APP_LOGS.debug("Test Passed");
						Reporter.log("Test Passed");
						
						APP_LOGS.debug("Test Completed & End of the Step");
						Reporter.log("Test Completed & End of the Step");		
					
						
			}
		
			catch (Exception t) 
			{
			System.err.println("Failed");
			ErrorUtil.addVerificationFailure(t);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Test Failed & End of the Step");
			Reporter.log("Test Failed & End of the Step");
			throw t;
			} 
					}
						
					     @AfterMethod
							public void reportDataSetResult(){
								if(skip)
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
								else if(fail){
									isTestPass=false;
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
								}
								else
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
								
								skip=false;
								fail=false;
						
							}
							
							@AfterTest
							public void reportTestResult(){
								if(isTestPass)
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
								else
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
								
								closeBrowser();
							}
							
							@DataProvider
							public Object[][] getTestData(){
								return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
							}
						}
		
		

