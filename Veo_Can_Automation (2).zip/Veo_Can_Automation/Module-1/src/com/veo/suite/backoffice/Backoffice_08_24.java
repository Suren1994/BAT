package com.veo.suite.backoffice;
import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;
public class Backoffice_08_24 extends TestSuiteBase {
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
	
	
	@Test(dataProvider="getTestData")
	public void ability_to_mimic_the_same_rules(
			String uname,
			String pwd,
			String BackOfficeOrderStatus,
			String LoopCount,
			String CartInput,
			String PackInput,
			String QuantityInput,
			String DaysOfCoverage
			
			) throws InterruptedException, IOException, AWTException,Exception, Throwable {
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_08_24");
		Reporter.log("Executing Backoffice TC_08_24");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to mimic the same rules from the validation engine when ammending an order in the replenishment cockpit");
		Reporter.log("Ability to mimic the same rules from the validation engine when ammending an order in the replenishment cockpit");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		//sessionData.put("mobile_"+count, uname);
		
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		
		try{
		
//====================================Login to Backoffice========================================================//
			
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
	//==================================Click on Flagged Order=====================================================//
				
				getObject("BackOffice_OrderStatus_Dropdown").clear();
				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(1000);	
				
				getObject("BackOffice_OrderStatus_Dropdown").sendKeys(BackOfficeOrderStatus);
				APP_LOGS.debug("Selected Order status as: "+BackOfficeOrderStatus);
				Reporter.log("Selected Order status as: "+BackOfficeOrderStatus);
				Thread.sleep(1000);	

				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(3000);
		//================================= Selecting Start Date==========================================================//
				getObject("BackOffice_StartDate").clear();
				APP_LOGS.debug("Cleared Start Date");
				Reporter.log("Cleared Start Date");
				
		//=================================clicking on refresh button================================================================================//
				getObject("Backoffice_RefreshButton").click();
				APP_LOGS.debug("Clicked on Refresh Button");
				Reporter.log("Clicked on Refresh Button");
				Thread.sleep(10000);
					
				String parentHandle = driver.getWindowHandle();		// get the current window handle
				
				String Ordernumber = getObject("Backoffice_HomePage_Orders").getText();
				
		//=========================clicking on first order==============================//
				getObject("Backoffice_HomePage_Orders").click();
				APP_LOGS.debug("Clicked Order Number in the Table: "+Ordernumber);
				Reporter.log("Clicked Order Number in the Table: "+Ordernumber);
				Thread.sleep(10000);

				for (String winHandle : driver.getWindowHandles()) 
				{
				    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
				
				}		
				APP_LOGS.debug("Switched to new Window: "+driver.getTitle());
				Reporter.log("Switched to new Window: "+driver.getTitle());
				
				WaitUntil_element_Visible("Backoffice_CartPage_AmendButton", 1000);
		//====================================clicking on Amend Button==============================================================================//			
				highlightElement("Backoffice_CartPage_AmendButton");	
				getObject("Backoffice_CartPage_AmendButton").click();
				APP_LOGS.debug("Clicked on Amend Button in Cart Page");
				Reporter.log("Clicked on Amend Button in Cart Page");
				Thread.sleep(3000);

				
					 //==============To Retrieve Target Inventory============//
						int j=0;
						String InlineValidationMessage;
						int m = driver.findElements(By.xpath(".//*[@id='on-hand-inv-carton-0']")).size(); 
						if(!(m==0))
						{
							for(int i=1;i<=Integer.parseInt(LoopCount);i++)
							{
												
									 j=i-1;
									 WebElement Value = driver.findElement(By.xpath("//*[@id='on-hand-inv-carton-"+j+"']"));
									 Value.clear();
									 Value.sendKeys(CartInput);
									 Value.sendKeys(Keys.TAB);
									 APP_LOGS.debug("Entered the value in Inventory on hand Carton");
									 Reporter.log("Entered the value in Inventory on hand Carton");
									 if(CartInput.matches("[0-9]+"))
									 {
									 APP_LOGS.debug("Success: Entered Value in Cart Field in Product Number "+i+" is Integer:"+CartInput);
									 Reporter.log("Success: Entered Value in Cart Field in Product Number "+i+" is Integer:"+CartInput);
									 Thread.sleep(3000);

									 }
									 else
									 {
										 APP_LOGS.debug("Entered Value in Cart Field in Product Number "+i+" is: "+CartInput);
										 Reporter.log("Entered Value in Cart Field in Product Number "+i+" is: "+CartInput);
										 InlineValidationMessage = getObject("Backoffice_Cart_InlineErrorText").getText();
										 APP_LOGS.debug("Inline Validation Error Message:"+InlineValidationMessage);
										 Reporter.log("Inline Validation Error Message:"+InlineValidationMessage);
											Thread.sleep(3000);

									 }
									 Thread.sleep(3000);
									 Value = driver.findElement(By.xpath("//*[@id='on-hand-inv-pack-"+j+"']"));
									 Value.clear();
									 Value.sendKeys(PackInput);
									 Value.sendKeys(Keys.TAB);
									 APP_LOGS.debug("Entered the value in Inventory on hand Pack");
									 Reporter.log("Entered the value in Inventory on hand Pack");
										Thread.sleep(3000);

									 if(PackInput.matches("[0-9]+"))
									 {
										 APP_LOGS.debug("Success: Entered Value in Pack Field in Product Number "+i+" is Integer:"+PackInput);
										 Reporter.log("Success: Entered Value in Pack Field in Product Number "+i+" is Integer:"+PackInput);
											Thread.sleep(3000);

									 }
									 else
									 {
										 APP_LOGS.debug("Entered Value in Pack Field in Product Number "+i+" is:"+PackInput);
										 Reporter.log("Entered Value in Pack Field in Product Number "+i+" is:"+PackInput);
										 InlineValidationMessage = getObject("Backoffice_Pack_InlineErrorText").getText();
										 APP_LOGS.debug("Inline Validation Error Message:"+InlineValidationMessage);
										 Reporter.log("Inline Validation Error Message:"+InlineValidationMessage);
											Thread.sleep(3000);

									 }
									 Thread.sleep(3000);
									 Value = driver.findElement(By.xpath(".//*[@id='quantity-"+j+"']"));
									 Value.clear();
									 Value.sendKeys(QuantityInput);
									 Value.sendKeys(Keys.TAB);
									 APP_LOGS.debug("Entered the value in Quantity");
									 Reporter.log("Entered the value in Quantity");
									 if(QuantityInput.matches("[0-9]+"))
									 {
										 APP_LOGS.debug("Success: Entered Value in Quantity Field in Product Number "+i+" is Integer:"+QuantityInput);
										 Reporter.log("Success: Entered Value in Quantity Field in Product Number "+i+" is Integer:"+QuantityInput);
									 }
									 else
									 {
										 APP_LOGS.debug("Entered Value in Quantity Field in Product Number "+i+" is: "+QuantityInput);
										 Reporter.log("Entered Value in Quantity Field in Product Number "+i+" is: "+QuantityInput);
										 InlineValidationMessage = getObject("Backoffice_Quantity_InlineErrorText").getText();
										 APP_LOGS.debug("Inline Validation Error Message:"+InlineValidationMessage);
										 Reporter.log("Inline Validation Error Message:"+InlineValidationMessage);
										 Thread.sleep(3000);

									 }
									
								 }
						}
						else {
							APP_LOGS.debug("FAILED: Cannot find Inventory on hand Carton field");
							Reporter.log("FAILED: Cannot find Inventory on hand Carton field");
							capturescreenshot(this.getClass().getSimpleName()+"_"+count);
							throw new Exception("FAILED: Cannot find Inventory on hand Carton field");
						    }
							//====To Apply Validation for DaysofCoverage====//
							Thread.sleep(3000);
							getObject("Backoffice_CartPage_DaysCoveage").sendKeys(Keys.BACK_SPACE);
							getObject("Backoffice_CartPage_DaysCoveage").sendKeys(Keys.BACK_SPACE);
							getObject("Backoffice_CartPage_DaysCoveage").sendKeys(DaysOfCoverage);
							getObject("Backoffice_CartPage_DaysCoveage").sendKeys(Keys.TAB);
							APP_LOGS.debug("Entered Value in Days Of Coverage Field is: "+DaysOfCoverage);
							Reporter.log("Entered Value in Days Of Coverage Field is: "+DaysOfCoverage);
							
							String DaysofCovInlineMsg = getObject("BackOff_DaysofCoverage_InlineErrorMsg").getText();
							APP_LOGS.debug("Inline Validation Error Message:"+DaysofCovInlineMsg);
							Reporter.log("Inline Validation Error Message:"+DaysofCovInlineMsg);
							
										   
						//============To Click on Continue Button======================//
								   Thread.sleep(4000);
								   getObject("Backoffice_CartPage_Continue").click();
								   APP_LOGS.debug("Clicked on Continue Button in Cart Page");
								   Reporter.log("Clicked on Continue Button in Cart Page");
								   Thread.sleep(4000);

						//============To Click on Ignore and Continue Link===========//
								ignoreAndContinue();
								Thread.sleep(3000);
						//===============Review Order Page Displayed================//
								   APP_LOGS.debug("Review Order Page Displayed");
								   Reporter.log("Review Order Page Displayed");
								   Thread.sleep(4000);

								     
						//============To Click on Place Order Button===================//
								   Thread.sleep(2000);
								   getObject("Backoffice_CartPage_PlaceOrder").click();
								   APP_LOGS.debug("Clicked on Place Order Button");
								   Reporter.log("Clicked on Place Order Button");
								   Thread.sleep(4000);

								   APP_LOGS.debug("Success: Order is placed for this Order Number:"+Ordernumber);
								   Reporter.log("Success: Order is placed for this Order Number:"+Ordernumber);
								   Thread.sleep(4000);

								   
								   driver.switchTo().window(parentHandle);
								   APP_LOGS.debug("Switched to Parent window: "+driver.getTitle());
								   Reporter.log("Switched to Parent window: "+driver.getTitle());
								   Thread.sleep(4000);

						//==========================================To Stop the test cases=============================================//
								   APP_LOGS.debug("Test Case Completed and End of the step");
								   Reporter.log("Test Case Completed and End of the step");
								  
								   
		}
		catch (Exception t) 
		{
		System.err.println("Failed");
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		APP_LOGS.debug("Test Failed & End of the Step");
		Reporter.log("Test Failed & End of the Step");
		throw t;
		} 

}
    @AfterMethod
		public void reportDataSetResult(){
			if(skip)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
	
		}
		
		@AfterTest
		public void reportTestResult(){
			if(isTestPass)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
		}
		
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
		}
	}


