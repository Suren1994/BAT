package com.veo.suite.backoffice;


import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class BO_MissingOrderPlaced extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void Backoffice_MissingOrderPlaced(
			String uname,
			String pwd,
			String title,
			String CreateOrderLabel,
			String OrderQuantity
			
			) throws Throwable,IOException{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing TC_BO_MissingOrderPlaced");
		Reporter.log("Executing TC_BO_MissingOrderPlaced");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Missing order is refreshed once an order is placed");
		Reporter.log("Missing order is refreshed once an order is placed");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		
		// webdriver
		openBrowser();
		APP_LOGS.debug("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		Reporter.log("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Backoffice URL");
		Reporter.log("Entered Backoffice URL");

		try
		{
//	====================================Login to Backoffice========================================================//


			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}		
			Thread.sleep(3000);
			//=====================To Click on Missing Order Tab================//
			Thread.sleep(3000);
			getObject("Backoffice_HomePage_MissingOrdersTab").click();
			APP_LOGS.debug("Clicked Missing Order Tab");
			Reporter.log("Clicked Missing Order Tab");
			
			String parentHandle = driver.getWindowHandle();		// get the current window handle

		//=====================To Click on Refresh Button===================//
			Thread.sleep(1000);
			getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
			APP_LOGS.debug("Clicked Refresh Button");
			Reporter.log("Clicked Refresh Button");
			Thread.sleep(5000);	
			
		//=====================To Click on First ERP Number ===================//
			
			String ERPNumber=BackofficeFindElements("//span[@class='z-html']/a",3);
			driver.findElement(By.linkText(ERPNumber)).click();
			APP_LOGS.debug("Clicked ERP Number is: "+ERPNumber);
			Reporter.log("Clicked ERP Number is: "+ERPNumber);
			Thread.sleep(5000);
			
			for (String winHandle : driver.getWindowHandles()) 
			{
			    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
			    System.out.println("Switched to new window: "+driver.getTitle());
				APP_LOGS.debug("Switched to new window: "+driver.getTitle());
				Reporter.log("Switched to new window: "+driver.getTitle());
									
			}		
			
		//==========To Compare the Title of the Window==================//
				   if(!compareTitle(title)){
					// screenshot
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit
					return;
				}	
				   	APP_LOGS.debug("PASSED: Validation of Title in Cart Page");
					Reporter.log("PASSED: Validation of Title in Cart Page");
		  
	//=================================To Retrieve a text from Create Order Label=======//	
			String LabelTest = driver.findElement(By.xpath("html/body/header/div/div/div[1]/a")).getText();
			
			//==============To click on Create Order Button====//
					
			if(LabelTest.equals(CreateOrderLabel))
			{
				Thread.sleep(2000);
				highlightElement("Backoffice_Create_Order");
				getObject("Backoffice_Create_Order").click();
				APP_LOGS.debug("Clicked Create Order Button");
				Reporter.log("Clicked Create Order Button");
				Thread.sleep(4000);

				offRoutePopup();
				Thread.sleep(4000);

			}
	//====To click on Order In Progress Button=============//
			else
			{
				Thread.sleep(4000);
				highlightElement("BackOffice_OrderInProgress");
				getObject("BackOffice_OrderInProgress").click();
				APP_LOGS.debug("Clicked Order In Progress Button");
				Reporter.log("Clicked Order In Progress Button");
			}

					//	driver.switchTo().window(parentHandle1);*/
				   for(int i=0;i<5;i++)
				   {
					   Thread.sleep(2000);
					  WebElement QuantityValue= driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']"));
					  QuantityValue.clear();
					  QuantityValue.sendKeys(OrderQuantity);
					  APP_LOGS.debug("Entered the Order Quantity");
					  Reporter.log("Entered the Order Quantity");
						
					  QuantityValue.sendKeys(Keys.TAB);
					  APP_LOGS.debug("Clicked on TAB");
					  Reporter.log("Clicked on TAB");
					  
					  int j=i+1;
					  APP_LOGS.debug("Enter Order Quantity for "+j+" Product is: "+OrderQuantity);
					  Reporter.log("Enter Order Quantity for "+j+" Product is: "+OrderQuantity);
					  i=i+1;
				   }
				   
				   Thread.sleep(3000);

		//============To Click on Continue Button======================//
				   getObject("BackOffice_Continue").click();
				   APP_LOGS.debug("Clicked Continue Button in Cart Page");
				   Reporter.log("Clicked Continue Button in Cart Page");
				   Thread.sleep(4000);

		//============To Click on Ignore and Continue Link===========//
				   ignoreAndContinue();
				   Thread.sleep(4000);

		//============To Click on Place Order Button===================//
				   getObject("BackOffice_PlaceOder").click();
				   APP_LOGS.debug("Clicked Place Order Button");
				   Reporter.log("Clicked Place Order Button");
				   Thread.sleep(6000);

		//===========To Switch Child Window to Parent Window(Backoffice Missing Tab)=============//
				   driver.switchTo().window(parentHandle);
					 APP_LOGS.debug("Page Redirected to the BackOffice Page");
					 Reporter.log("Page Redirected to the BackOffice Page"); 
					 
		//============To Click on Refresh Button========================//
				   Thread.sleep(2000);
				   getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
				   APP_LOGS.debug("Clicked Refresh Button");
				   Reporter.log("Clicked Refresh Button");
				   
		//===================================To get row count in the table========================================================//
					Thread.sleep(7000);
					List<WebElement> rows = driver.findElements(By.xpath("//span[@class='z-html']/a"));
					int totalRow = rows.size();
					// APP_LOGS.debug("Number of Rows in this Table: "+totalRow);
					Thread.sleep(2000);
					if(totalRow==0)
					 {
						 APP_LOGS.debug("FAILED: No missing orders are displayed in Backoffice");
						 Reporter.log("FAILED: No missing orders are displayed in Backoffice");
						 capturescreenshot(this.getClass().getSimpleName()+"__"+count);
						 throw new Exception("FAILED: No missing orders are displayed in Backoffice");
					 }
					 else
					 {
				    			
		//============To Check the just Placed Order is exist in the table=====//
				   
				   for(int j=1;j<=totalRow;j++)
				   {
					   Thread.sleep(1000);
					   int k=j+1;
					   String StringERPNumber= driver.findElements(By.xpath("//span[@class='z-html']/a")).get(k).getText();
					  
					   Thread.sleep(2000);
					   if(ERPNumber.equals(StringERPNumber))
					   {
						   APP_LOGS.debug("FAILED: The given ERP Number "+ERPNumber+" is displayed in Missing Orders");
						   Reporter.log("FAILED: The given ERP Number "+ERPNumber+" is displayed in Missing Orders");
						   capturescreenshot(this.getClass().getSimpleName()+"__"+count);
						   throw new Exception("FAILED: The given ERP Number "+ERPNumber+" is displayed in Missing Orders");					   
						}
					   else
					   {
						   if(j==totalRow)
						   {
							   APP_LOGS.debug("Success: The given ERP Number "+ERPNumber+" is not displayed in Missing Orders");
							   Reporter.log("Success: The given ERP Number "+ERPNumber+" is not displayed in Missing Orders");
						   }
					   }
					   
				   }
					 }
		 //==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
		 
			}
		catch(Exception e)
		{
			ErrorUtil.addVerificationFailure(e);
			System.err.println("FAILED");
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Failed");
			Reporter.log("Failed");
			throw e;
							
		}
		
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		

