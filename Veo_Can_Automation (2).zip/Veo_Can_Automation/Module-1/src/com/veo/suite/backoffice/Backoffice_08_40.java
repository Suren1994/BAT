package com.veo.suite.backoffice;


import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Backoffice_08_40 extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	
	
	@Test(dataProvider="getTestData")
	public void ToChange_Expected_DeliveryDate(
			String uname,
			String pwd,
			String BackOfficeOrderStatus,
			String Future_Date
			) throws InterruptedException, IOException, AWTException,Exception, Throwable
{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_08_40");
		Reporter.log("Executing Backoffice TC_08_40");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to change the expected delivery date on a flagged order");
		Reporter.log("Ability to change the expected delivery date on a flagged order");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		try{
		
//====================================Login to Backoffice========================================================//
	
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
//==================================Click on Amended Order=====================================================//
		
				getObject("BackOffice_OrderStatus_Dropdown").clear();
				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(1000);	
				
				getObject("BackOffice_OrderStatus_Dropdown").sendKeys(BackOfficeOrderStatus);
				APP_LOGS.debug("Selecting BackOffice Order Status is: "+BackOfficeOrderStatus);
				Reporter.log("Selecting BackOffice Order Status is: "+BackOfficeOrderStatus);
				Thread.sleep(1000);	

				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(3000);		

//================================= Selecting Start Date==========================================================//
				
				getObject("BackOffice_StartDate").clear();
				APP_LOGS.debug("Clicked on Start Date");
				Reporter.log("Clicked on Start Date");
				Thread.sleep(1000);	

//=================================clicking on refresh button======================================================//
				getObject("Backoffice_RefreshButton").click();
				APP_LOGS.debug("Clicked Refresh Button");
				Reporter.log("Clicked Refresh Button");
				Thread.sleep(10000);
					
//==================================Get the Current window Handle======================================================//
				String parentHandle = driver.getWindowHandle();		
				String Ordernumber = getObject("Backoffice_HomePage_Orders").getText();
							
//==================================Clicked First Order Number======================================================//
				getObject("Backoffice_HomePage_Orders").click();
				APP_LOGS.debug("Clicked Backoffice Order Number: "+Ordernumber);
				Reporter.log("Clicked Backoffice Order Number: "+Ordernumber);
				Thread.sleep(10000);

				for (String winHandle : driver.getWindowHandles()) 
				{
					// switch focus of WebDriver to the next found window handle (that's your newly opened window)
					driver.switchTo().window(winHandle); 
					
				}		
				
				System.out.println("Switched to new Window: "+driver.getTitle());
				APP_LOGS.debug("Switched to new Window: "+driver.getTitle());
				Reporter.log("Switched to new Window: "+driver.getTitle());
				Thread.sleep(3000);

				
//====================================clicking on Amend Button==============================================================================//			
				WaitUntil_element_Visible("Backoffice_CartPage_AmendButton", 1000);
				highlightElement("Backoffice_CartPage_AmendButton");
				getObject("Backoffice_CartPage_AmendButton").click();
				APP_LOGS.debug("Clicked Amend Button in Cart Page");
				Reporter.log("Clicked Amend Button in Cart Page");
				Thread.sleep(3000);

//====================================Clicked Emergency Order Checkbox==============================================================================//
				//WaitUntil_element_Visible("Backoffice_EmergencyCheckbox", 100);
				Thread.sleep(3000);
				highlightElement("Backoffice_EmergencyCheckbox");
				
				WebElement Checkboxvalidation = getObject("Backoffice_EmergencyCheckbox");
				
				if(!Checkboxvalidation.isSelected())
				{
				getObject("Backoffice_EmergencyCheckbox").click();
				APP_LOGS.debug("Clicked Emergency Order Checkbox in Cart Page");
				Reporter.log("Clicked Emergency Order Checkbox in Cart Page");
				}
				
//====================================Modifying the Delivery Date==============================================================================//
					       
				Thread.sleep(3000);
				getObject("Backoffice_CartPage_DeliveryDate").click();  
				String BeforeChange =  getObject("Backoffice_CartPage_DeliveryDate").getAttribute("Value");
				APP_LOGS.debug("Before changing Expected Delivery Date is :"+BeforeChange);
				Reporter.log("Before changing Expected Delivery Date is :"+BeforeChange);
				Thread.sleep(3000);

				
				getObject("Backoffice_CartPage_DeliveryDate").sendKeys(Future_Date);
				APP_LOGS.debug("Entered the Delivery date: "+Future_Date);
				Reporter.log("Entered the Delivery date: "+Future_Date);
				Thread.sleep(3000);
				  
				  
//===================================To Click on Save & Close Button===================================================================//
				Thread.sleep(3000);
				getObject("Backoffice_CartPage_SaveAndClose").click();
				APP_LOGS.debug("Clicked Save and Close Button");
				Reporter.log("Clicked Save and Close Button");
				
//===================================To Click on Yes Button===================================================================//
				Thread.sleep(3000);
				getObject("Backoffice_CartPage_SaveYesButton").click();
				APP_LOGS.debug("Clicked Yes Button in PopUp");
				Reporter.log("Clicked Yes Button in PopUp");
				
				Thread.sleep(5000);
				  
//===================================To Switch back to Backoffice Order Window===================================================================//				
				driver.switchTo().window(parentHandle);
				APP_LOGS.debug("Switched to Parent Window");
				Reporter.log("Switched to Parent Window");
//===================================To Click on First Order Number to verify the Expected Delivery Date is  updated===================================================================//
				WaitUntil_element_Visible("Backoffice_HomePage_Orders",100);
				highlightElement("Backoffice_HomePage_Orders");
				getObject("Backoffice_HomePage_Orders").click();
				APP_LOGS.debug("Clicked BackOffce Order Number is: "+Ordernumber);
				Reporter.log("Clicked BackOffce Order Number is: "+Ordernumber);
				
				Thread.sleep(6000);
				//WaitUntil_element_Visible("Backoff_DeliveryDate", 100);

//===================================To Handle the current Window===================================================================//
				
				for (String winHandle1 : driver.getWindowHandles()) 
				{
					// switch focus of WebDriver to the next found window handle (that's your newly opened window)
				    driver.switchTo().window(winHandle1); 
				    
				}		
				System.out.println("Switched to new window: "+driver.getTitle());
			    APP_LOGS.debug("Switched to new window: "+driver.getTitle());
				Reporter.log("Switched to new window: "+driver.getTitle());
//===================================To Retrieve Expected Delivery Date after saved==================================================//
				WaitUntil_element_Visible("Backoffice_CartPage_DeliveryDate", 1000);
				
				Thread.sleep(3000);
				highlightElement("Backoffice_CartPage_DeliveryDate");
				String AfterChange =  getObject("Backoffice_CartPage_DeliveryDate").getAttribute("Value");
				APP_LOGS.debug("After changing Expected Delivery Date is :"+AfterChange);
				Reporter.log("After changing Expected Delivery Date is :"+AfterChange);
				  
				if(!BeforeChange.equals(AfterChange))
				{
				  APP_LOGS.debug("Success: Your Expected Delivery Date is Changed and the date is : "+AfterChange);
				  Reporter.log("Success: Your Expected Delivery Date is Changed and the date is : "+AfterChange);
				}
				else 
				{
				  APP_LOGS.debug("FAILED: Your Expected Delivery Date is not Changed and the date is : "+AfterChange);
				  Reporter.log("FAILED: Your Expected Delivery Date is not Changed and the date is : "+AfterChange);
				  capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				  throw new Exception("FAILED: Your Expected Delivery Date is not Changed and the date is : "+AfterChange);
				}
		//==========================================To Stop the test cases=============================================//
				Thread.sleep(2000); 
				APP_LOGS.debug("Test Case Completed and End of the step");
				Reporter.log("Test Case Completed and End of the step");
		}
	
		
		catch (Exception t) 
		{
		System.err.println("Failed");
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		APP_LOGS.debug("Test Failed & End of the Step");
		Reporter.log("Test Failed & End of the Step");
		throw t;
		} 

}
    @AfterMethod
		public void reportDataSetResult(){
			if(skip)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
	
		}
		
		@AfterTest
		public void reportTestResult(){
			if(isTestPass)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
		}
		
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
		}
	}

