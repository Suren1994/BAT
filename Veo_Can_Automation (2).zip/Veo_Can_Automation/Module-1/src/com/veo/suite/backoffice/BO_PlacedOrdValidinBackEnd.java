package com.veo.suite.backoffice;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;
public class BO_PlacedOrdValidinBackEnd extends TestSuiteBase {
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
	
	
	@Test(dataProvider="getTestData")
	public void Backoffice_PlacedOrdValidinBackEnd(
			String VEO_Username,
			String VEO_PWD,
			String uname,
			String pwd,
			String CreatOrderLabel,
			String OrderQuantity,
			String PageTitle,
			String OrderStatus,
			String BackOffice_StartDate_Input
			
			) throws Throwable,IOException{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		
		
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing TC_BO_PlacedOrdValidinBackEnd");
		Reporter.log("Executing TC_BO_PlacedOrdValidinBackEnd");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Place an order in VEO Front End and Check Order Status in BackOffice");
		Reporter.log("Place an order in VEO Front End and Check Order Status in BackOffice");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("VEO_Username: "+VEO_Username+" & VEO_Password:"+VEO_PWD);
		Reporter.log("VEO_Username: "+VEO_Username+" & VEO_Password:"+VEO_PWD);
		//sessionData.put("mobile_"+count, uname);
		
		
		// webdriver
		openBrowser();
		APP_LOGS.debug("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		Reporter.log("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		
		driver.get(CONFIG.getProperty("testSiteName"));
		APP_LOGS.debug("Entered VeO URL");
		Reporter.log("Entered VeO URL");

		try
		{
		
//====================================Login to Backoffice========================================================//
	
			if(!Login("StoreFront_LoginPage_Username","StoreFront_LoginPage_Password","StoreFront_LoginPage_AgeCheckbox","StoreFront_LoginPage_LoginButton",VEO_Username,VEO_PWD)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}	
				
			Thread.sleep(3000);
		
		String LabelTest = getObject("Backoffice_Create_Order").getText();
		if (LabelTest.equals(CreatOrderLabel)) 
		{
			Thread.sleep(2000);
			highlightElement("BackOffice_Homepage_CreateOrder");
			getObject("BackOffice_Homepage_CreateOrder").click();
			APP_LOGS.debug("Clicked Create Order Button");
			Reporter.log("Clicked Create Order Button");
			Thread.sleep(4000);

			offRoutePopup();
			Thread.sleep(4000);

		}
		// ====To click on Order In Progress Button=============//
		else {
			Thread.sleep(4000);
			highlightElement("Order_In_Progress");
			getObject("Order_In_Progress").click();
			APP_LOGS.debug("Clicked Order In Progress Button");
			Reporter.log("Clicked Order In Progress Button");
			Thread.sleep(4000);

		}
		Thread.sleep(4000);

		getObject("Backoffice_CartPage_OrderQuantity0").click();
		getObject("Backoffice_CartPage_OrderQuantity0").clear();
		getObject("Backoffice_CartPage_OrderQuantity0").sendKeys(OrderQuantity);
		APP_LOGS.debug("Entered Order Quantity is: "+OrderQuantity);
		Reporter.log("Entered Order Quantity is: "+OrderQuantity);	
		 
		getObject("Backoffice_CartPage_OrderQuantity0").sendKeys(Keys.TAB);
		APP_LOGS.debug("Clicked on TAB");
		Reporter.log("Clicked on TAB");	
		Thread.sleep(2000);
		
		//Click on Filter 
		getObject("BackOffice_CartPage_Filter").click();
		APP_LOGS.debug("Clicked on Filter");
		Reporter.log("Clicked on Filter");
		Thread.sleep(3000);
		
		getObject("BackOffice_Continue").click();
		APP_LOGS.debug("Clicked BackOffice Continue Button");
		Reporter.log("Clicked BackOffice Continue Button");
		 	
		ignoreAndContinue();
		Thread.sleep(4000);

			 getObject("BackOffice_PlaceOder").click();
			 APP_LOGS.debug("Clicked on Place Order button");
			 Reporter.log("Clicked on Place Order button");
			 Thread.sleep(4000);
 	

			 String CurrentTitle=driver.getTitle();
			 
			 if(CurrentTitle.equals(PageTitle))
			 {
				 APP_LOGS.debug("Current Page Title is: "+CurrentTitle);
				 Reporter.log("Current Page Title is: "+CurrentTitle);
				 
			 }
			 
			 String FrondendOrdStatus = driver.findElement(By.xpath(".//*[@id='page-content']/div/div[2]/div[1]/div[1]/div/div/div")).getText();
			 
			 if(FrondendOrdStatus.equals(OrderStatus))
			 {
				 APP_LOGS.debug("Order Status is :"+FrondendOrdStatus);
				 Reporter.log("Order Status is :"+FrondendOrdStatus); 
			 }
			 
			 String OrderNumber = getObject("BackOffice_Front_OrderNumber").getText();
			 APP_LOGS.debug("Order Placed in Front End and Order Number is : "+OrderNumber);
			 Reporter.log("OOrder Placed in Front End and Order Number is: "+OrderNumber); 
			 Thread.sleep(3000);
			 
			 getObject("BackOffice_ManIkon").click();
			 APP_LOGS.debug("Clicked on Man Ikon");
			 Reporter.log("Clicked on Man Ikon");
			 Thread.sleep(3000);
			 
			 getObject("BackOffice_MyAccount").click();
			 APP_LOGS.debug("Clicked on My Account");
			 Reporter.log("Clicked on My Account");
			 Thread.sleep(3000);

			 String StoreNumber = getObject("BackOffice_FrontEnd_StoreERPNumber1").getAttribute("Value");
			 APP_LOGS.debug("Order Placed in Front End and ERP Number is: "+StoreNumber);
			 Reporter.log("Order Placed in Front End and ERP Number is: "+StoreNumber); 
			 
			APP_LOGS.debug("Logged in BackOffice Application");
			Reporter.log("Logged in BackOffice Application");
			Thread.sleep(3000); 
			
			driver.get(CONFIG.getProperty("backofficeurl"));
			APP_LOGS.debug("Entered Backoffice URL");
			Reporter.log("Entered Backoffice URL");

			 try
				{
//			====================================Login to Backoffice========================================================//

				 if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
						// screenshot
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						fail=true;
						// quit
						return;
					}
					Thread.sleep(3000);
				
				getObject("BackOffice_StartDate").clear();
				getObject("BackOffice_StartDate").sendKeys(BackOffice_StartDate_Input);
				APP_LOGS.debug("Entered the Start Date as: "+BackOffice_StartDate_Input);
				Reporter.log("Entered the Start Date as: "+BackOffice_StartDate_Input);
				Thread.sleep(3000);
				
				getObject("BackOffice_ERPNumber_Inputbox").clear();
				getObject("BackOffice_ERPNumber_Inputbox").sendKeys(StoreNumber);
				APP_LOGS.debug("Entered ERP Number is: "+StoreNumber);
				Reporter.log("Entered ERP Number is: "+StoreNumber);
				Thread.sleep(5000);

				
						   
	//============To Click on Refresh Button========================//
			   getObject("Backoffice_RefreshButton").click();
			   APP_LOGS.debug("Clicked Refresh Button");
			   Reporter.log("Clicked Refresh Button");
			   Thread.sleep(5000);

	//===================================To get row count in the table========================================================//
				Thread.sleep(3000);
				List<WebElement> rows = driver.findElements(By.xpath("//table/tbody[2]/tr/td/div/span/a"));
				int totalRow = rows.size();
				APP_LOGS.debug("Number of Rows in this Table: "+totalRow);
				Reporter.log("Number of Rows in this Table: "+totalRow);
				Thread.sleep(2000);
			
	//============To Check the just Placed Order is exist in the table=====//
			   
			   for(int j=1;j<=totalRow;)
			   {
				   Thread.sleep(3000);
				   String StringERPNumbers = driver.findElement(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr["+j+"]/td[2]/div/span/a")).getText();
				   String StringOrderNumber = driver.findElement(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[1]/div/div/div[2]/div[2]/div[3]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr["+j+"]/td[3]/div/span/button")).getText();
				   String StringOrderStatus1 = driver.findElement(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[1]/div/div/div[2]/div[2]/div[3]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr["+j+"]/td[4]/div")).getText();
			
				   Thread.sleep(2000);
				   	APP_LOGS.debug("ERPNum: "+StringERPNumbers);
					Reporter.log("ERPNum: "+StringERPNumbers);
					APP_LOGS.debug("Ord Num: "+StringOrderNumber);
					Reporter.log("Ord Num: "+StringOrderNumber);
					APP_LOGS.debug("OrderStatus: "+StringOrderStatus1);
					Reporter.log("OrderStatus: "+StringOrderStatus1);

				   if(StringOrderNumber.equals(OrderNumber))
				   {
					   capturescreenshot(this.getClass().getSimpleName() + "_" + count);
					   APP_LOGS.debug("Searching Order in BackOffice:");
					   Reporter.log("Searching Order in BackOffice:");
					   
					   APP_LOGS.debug("ERP Number is: "+StringERPNumbers);
					   Reporter.log("ERP Number is: "+StringERPNumbers);
					   
					   APP_LOGS.debug("ERP Number is: "+StringOrderNumber);
					   Reporter.log("ERP Number is: "+StringOrderNumber);
					   
					   APP_LOGS.debug("Success: Order is placed in Front End and Order Status in BackOffice is : "+StringOrderStatus1);
					   Reporter.log("Success: Order is placed in Front End and Order Status in BackOffice is : "+StringOrderStatus1);
					  
					   break;
				   }
				   else
				   { 
					   APP_LOGS.debug("FAILED: UnExpected Error occured while placing order / in Backoffice");
					   Reporter.log("FAILED: UnExpected Error occured while placing order / in Backoffice");
					   capturescreenshot(this.getClass().getSimpleName() + "_" + count);
					   throw new Exception("FAILED: UnExpected Error occured while placing order / in Backoffice");
				   }
			  	}
				}
				catch(Exception e)
				{
					ErrorUtil.addVerificationFailure(e);
					System.err.println("FAILED");
					capturescreenshot(this.getClass().getSimpleName() + "_" + count);
					Reporter.log("BackOffice Failed");
					APP_LOGS.debug("BackOffice Failed");
					throw new Exception("BackOffice Failed");
				}
	 //==========================================To Stop the test cases=============================================//
    				 APP_LOGS.debug("Test Case Completed and End of the step");
    				 Reporter.log("Test Case Completed and End of the step");
	    			// driver.switchTo().window(parentHandle);
		}
		
			catch(Exception e)
			{
				ErrorUtil.addVerificationFailure(e);
				System.err.println("FAILED");
				capturescreenshot(this.getClass().getSimpleName() + "_" + count);
				Reporter.log("Front End Application Failed");
				APP_LOGS.debug("Front End Application Failed");
				throw e;
								
			}
}
    @AfterMethod
		public void reportDataSetResult(){
			if(skip)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
	
		}
		
		@AfterTest
		public void reportTestResult(){
			if(isTestPass)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
		}
		
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
		}
	}

