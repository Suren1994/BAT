package com.veo.suite.backoffice;

import java.awt.AWTException;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Backoffice_08_21 extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void Missingorderis_refreshedonce_anorderisplaced(
			String uname,
			String pwd,
			String title,
			String CreatOrderLabel,
			String OrderQuantity
			) throws InterruptedException, IOException, AWTException,Exception, Throwable{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_11_30");
		Reporter.log("Executing Backoffice TC_11_30");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to see a previously missing order removed from the missing tab ");
		Reporter.log("Ability to see a previously missing order removed from the missing tab ");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		try{
			//=================================== Login to Backoffice ===================================//
			
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}		
			Thread.sleep(5000);		
	
	//=====================To Click on Missing Order Tab================//
		getObject("Backoffice_HomePage_MissingOrdersTab").click();
		APP_LOGS.debug("Clicked on Missing Order Tab");
		Reporter.log("Clicked on Missing Order Tab");
		Thread.sleep(1000);

	//=====================To Click on Refresh Button===================//
		getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
		APP_LOGS.debug("Clicked on Refresh Button");
		Reporter.log("Clicked on Refresh Button");
		Thread.sleep(3000);

	//		====================================To get row count in the table========================================================//
		int tablerows = driver.findElements(By.xpath("//span[@class='z-html']/a")).size(); 
		APP_LOGS.debug("No.of.Rows is: "+tablerows);
		Reporter.log("No.of.Rows is: "+tablerows);
		
	    //====================================To compare whether the table having data========================================================//
		 if(tablerows!=0)
		 {
			 APP_LOGS.debug("The Missing Orders Tab contains data...");
			 Reporter.log("The Missing Orders Tab contains data...");
		 		
		
		String parentHandle = driver.getWindowHandle();		// get the current window handle
		APP_LOGS.debug("Get the current window handle");
		Reporter.log("Get the current window handle");
		
	//=====================To Click on First ERP Number ===================//
		String ERPNumber = BackofficeFindElements("//span[@class='z-html']/a",11);
		APP_LOGS.debug("The Selected ERP Number is: "+ERPNumber);
		Reporter.log("The Selected ERP Number is: "+ERPNumber);
		Thread.sleep(3000);
		
		driver.findElement(By.linkText(ERPNumber)).click();
		APP_LOGS.debug("Clicked on the selected ERP Number");
		Reporter.log("Clicked on the selected ERP Number");
		Thread.sleep(10000);
		
		
		for (String winHandle : driver.getWindowHandles()) 
		{
		    driver.switchTo().window(winHandle);
		  
		}		
		  System.out.println("Switched to Child window: "+driver.getTitle());
		  APP_LOGS.debug("Switched to Child window: "+driver.getTitle());
		  Reporter.log("Switched to Child window: "+driver.getTitle());
		  Thread.sleep(5000);

	//==========To Compare the Title of the Window==================//
			   if(!compareTitle(title)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}	
			   
	  
//=================================To Retrieve a text from Create Order Label=======//	
		String LabelTest = getObject("Backoffice_StoreFront_CreateOrderButton").getText();
		APP_LOGS.debug("The Label present in Cart page Order button is: "+LabelTest);
		Reporter.log("The Label present in Cart page Order button is: "+LabelTest);
		Thread.sleep(3000);

//======================To verify Label Text===================//
		//==============To click on Create Order Button====//
				
		if(LabelTest.equals(CreatOrderLabel))
		{
			Thread.sleep(2000);
			highlightElement("Backoffice_StoreFront_CreateOrderButton");
			getObject("Backoffice_StoreFront_CreateOrderButton").click();
			APP_LOGS.debug("Clicked Create Order Button");
			Reporter.log("Clicked Create Order Button");
			Thread.sleep(3000);

			offRoutePopup();
			Thread.sleep(3000);

		}
//====To click on Order In Progress Button=============//
		else
		{
			Thread.sleep(2000);
			highlightElement("Backoffice_StoreFront_OrderInProgress");
			getObject("Backoffice_StoreFront_OrderInProgress").click();
			APP_LOGS.debug("Clicked on Order In Progress Button");
			Reporter.log("Clicked on Order In Progress Button");
		}

			
		//	driver.switchTo().window(parentHandle1);*/
		int t = driver.findElements(By.xpath(".//*[@id='quantity-0']")).size(); 
		if(!(t==0))
		{
		for(int i=0;i<5;i++)
			   {
				   Thread.sleep(2000);
				  WebElement QuantityValue= driver.findElement(By.xpath(".//*[@id='quantity-"+i+"']"));
				  QuantityValue.clear();
				  APP_LOGS.debug("Cleared Order Quantity for "+i+" Product");
				  Reporter.log("Cleared Order Quantity for "+i+" Product");
				  Thread.sleep(1000);

				  QuantityValue.sendKeys(OrderQuantity);
				  APP_LOGS.debug("Enter Order Quantity for "+i+" Product is: "+OrderQuantity);
				  Reporter.log("Enter Order Quantity for "+i+" Product is: "+OrderQuantity);
				  Thread.sleep(2000);

				  QuantityValue.sendKeys(Keys.TAB);
				  APP_LOGS.debug("Clicked on TAB");
				  Reporter.log("Clicked on TAB");
				  Thread.sleep(3000);
  
			   }
		}
		else
		{
			APP_LOGS.debug("Failed: Cannot find the Quantity field in Cart Page");
			Reporter.log("Failed: Cannot find the Quantity field in Cart Page");
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("Failed: Cannot find the Quantity field in Cart Page");
		}
	//============To Click on Continue Button======================//
			   Thread.sleep(3000);
			   getObject("Backoffice_CartPage_Continue").click();
			   APP_LOGS.debug("Clicked on Continue Button in Cart Page");
			   Reporter.log("Clicked on Continue Button in Cart Page");
				Thread.sleep(3000);

	//============To Click on Ignore and Continue Link===========//
				ignoreAndContinue();
				Thread.sleep(3000);

	//============To Click on Place Order Button===================//
			   Thread.sleep(2000);
			   getObject("Backoffice_CartPage_PlaceOrder").click();
			   APP_LOGS.debug("Clicked on Place Order Button");
			   Reporter.log("Clicked on Place Order Button");
				 
	//===========To Switch Child Window to Parent Window(Backoffice Missing Tab)=============//
			   Thread.sleep(6000);
			   driver.switchTo().window(parentHandle); 
			   APP_LOGS.debug("Page Redirected to BackOffice Window: "+driver.getTitle());
			   Reporter.log("Page Redirected to BackOffice Window: "+driver.getTitle());
			   
	//============To Click on Refresh Button========================//
			   	//WaitUntil_element_tobe_clicked("Backoffice_HomePage_MissingOrders_RefreshButton", 1000);
				getObject("Backoffice_HomePage_MissingOrders_RefreshButton").click();
			   	APP_LOGS.debug("Clicked on Refresh Button");
			   	Reporter.log("Clicked on Refresh Button");
				Thread.sleep(5000);

	//===================================To get row count in the table========================================================//
				Thread.sleep(1000);
				int rowcount = driver.findElements(By.xpath("//span[@class='z-html']/a")).size(); 
				if(!(rowcount==0))
				{
				
					if(rowcount==0)
					{
						APP_LOGS.debug("Failed: Number of Rows in Missing Order Table is: "+rowcount);
						Reporter.log("Failed: Number of Rows in Missing Order Table is: "+rowcount);
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						throw new Exception("Failed: Number of Rows in Missing Order Table is: "+rowcount);
					}
				
					else
					{
			    				
	//============To Check the just Placed Order is exist in the table=====//
			   
						for(int j=1;j<=rowcount;j++)
						{
							Thread.sleep(1000);
							WebElement ERPNumbers = driver.findElement(By.xpath("html/body/div[1]/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[3]/div/div/div[2]/div[2]/div/div/div[2]/div[3]/div[2]/div[2]/div/div[2]/div/div/div[3]/table/tbody[2]/tr["+j+"]/td[2]/div/span/a"));
							String actualERPNumber = ERPNumbers.getText();
							Thread.sleep(2000);
							if(ERPNumber.equals(actualERPNumber))
							{
								APP_LOGS.debug("The ERP Number is still exists in Missing Order Tab:"+ERPNumber);
								Reporter.log("The ERP Number is still exists in Missing Order Tab:"+ERPNumber);
								APP_LOGS.debug("Success: Order Placed for this ERP Number: "+ERPNumber);
								Reporter.log("Success: Order Placed for this ERP Number: "+ERPNumber);
								break;
							}
							else
							{
								if(j==tablerows)
								{
									APP_LOGS.debug("This ERP Number does not exists in Missing Order Tab: "+ERPNumber);
									Reporter.log("This ERP Number does not exists in Missing Order Tab: "+ERPNumber);
									APP_LOGS.debug("Success: Order Placed for this ERP Number: "+ERPNumber);
									Reporter.log("Success: Order Placed for this ERP Number: "+ERPNumber);
									Thread.sleep(3000);
								}
							}
				   
						}
					}
				}
	
				else {
					APP_LOGS.debug("FAILED: Could not find the search results data in Missing Orders");
					Reporter.log("FAILED: Could not find the search results data in Missing Orders");
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					throw new Exception("FAILED: Could not find the search results data in Missing Orders");
				    }
		//==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
				 
			}
		 
		 else
		 {
			 System.err.println("No Missing Orders found");
			 APP_LOGS.debug("No Missing Orders found");
			 Reporter.log("No Missing Orders found");
			 capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			 throw new Exception("No Missing Orders found");
		 }	
		}
		
			catch(Exception e)
			{
				System.err.println("Failed");
				ErrorUtil.addVerificationFailure(e);
				capturescreenshot(this.getClass().getSimpleName() + "_" + count);
				APP_LOGS.debug("Failed");
				Reporter.log("Failed");
				throw e;
				
			}
		
				
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

	

