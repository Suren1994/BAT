package com.veo.suite.backoffice;
import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;
public class Backoffice_08_23 extends TestSuiteBase {
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
	
	
	@Test(dataProvider="getTestData")
	public void click_Ordernumber_amend_flaggedorder(
			String uname,
			String pwd,	
			String BackofficeOrderStatus,
			String OrderQuantity
			) throws InterruptedException, IOException, AWTException,Exception, Throwable{

		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_08_23");
		Reporter.log("Executing Backoffice TC_08_23");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to click on the Order number to amend a flagged order in the replenishment cockpit");
		Reporter.log("Ability to click on the Order number to amend a flagged order in the replenishment cockpit");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		
		try{
		
//====================================Login to Backoffice========================================================//
			
			
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}		
			Thread.sleep(3000);	

		
		//==================================Click on Flagged Order=====================================================//
				Thread.sleep(3000);
				getObject("BackOffice_OrderStatus_Dropdown").clear();
				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(1000);	
				
				getObject("BackOffice_OrderStatus_Dropdown").sendKeys(BackofficeOrderStatus);
				APP_LOGS.debug("Selecting BackOffice Order Status as: "+BackofficeOrderStatus);
				Reporter.log("Selecting BackOffice Order Status as: "+BackofficeOrderStatus);
				Thread.sleep(1000);		
				
				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(4000);		

		//================================= Selecting Start Date==========================================================//

				getObject("BackOffice_StartDate").clear();
				APP_LOGS.debug("Cleared the Start Date");
				Reporter.log("Cleared the Start Date");
				Thread.sleep(3000);

		//=================================clicking on refresh button================================================================================//
				getObject("Backoffice_RefreshButton").click();
				APP_LOGS.debug("Clicked on Refresh Button");
				Reporter.log("Clicked on Refresh Button");
				Thread.sleep(10000);
					
				String parentHandle = driver.getWindowHandle();		// get the current window handle
				
				String Ordernumber = BackofficeFindElements("//span[@class='z-html']/button", 3);
				
		//=========================clicking on first order==============================//
				driver.findElement(By.xpath("//button[contains(.,'"+Ordernumber+"')]")).click();
				APP_LOGS.debug("Clicked Order Number is: "+Ordernumber);
				Reporter.log("Clicked Order Number is: "+Ordernumber );
				Thread.sleep(10000);

				for (String winHandle : driver.getWindowHandles()) 
				{
				    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
				
				}		
				APP_LOGS.debug("Switched to new window: "+driver.getTitle());
				Reporter.log("Switched to new window: "+driver.getTitle());
				
				WaitUntil_element_Visible("Backoffice_CartPage_AmendButton", 1000);
				
		//====================================clicking on Amend Button==============================================================================//			
				highlightElement("Backoffice_CartPage_AmendButton");	
				getObject("Backoffice_CartPage_AmendButton").click();
				APP_LOGS.debug("Clicked on Amend Button in Cart Page");
				Reporter.log("Clicked on Amend Button in Cart Page");
				Thread.sleep(3000);
				
				getObject("Backoffice_CartPage_OrderQuantity0").clear();
			    APP_LOGS.debug("Clearing Previous Quantity");
			    Reporter.log("Clearing Previous Quantity");
			    
			    getObject("Backoffice_CartPage_OrderQuantity0").sendKeys(OrderQuantity);
			    getObject("Backoffice_CartPage_OrderQuantity0").sendKeys(Keys.TAB);
			    APP_LOGS.debug("Entered Order Quantity as : "+OrderQuantity);
			    Reporter.log("Entered Order Quantity as : "+OrderQuantity);
			     Thread.sleep(3000);

			   			
		//====================================clicking on Save & Close Button==============================================================================//					
				
			     highlightElement("Backoffice_CartPage_SaveAndClose");
			     getObject("Backoffice_CartPage_SaveAndClose").click();	
			     APP_LOGS.debug("Clicked on Save and Close Button");
			     Reporter.log("Clicked on Save and Close Button");
			     Thread.sleep(3000);

			     Thread.sleep(3000);
			     highlightElement("Backoffice_CartPage_SaveYesButton");
			     getObject("Backoffice_CartPage_SaveYesButton").click();	
			     APP_LOGS.debug("Clicked on Yes button");
			     Reporter.log("Clicked on Yes button");
			     Thread.sleep(3000);

			     APP_LOGS.debug("Success: Order Quantity is Saved");
			     Reporter.log("Success: Order Quantity is Saved");
			     
			     driver.switchTo().window(parentHandle);
				 APP_LOGS.debug("Switched back to Parent window: "+driver.getTitle());
				 Reporter.log("Switched back to Parent window: "+driver.getTitle());
			     Thread.sleep(3000);

			     
		//==========================================To Stop the test cases=============================================//
				 APP_LOGS.debug("Test Case Completed and End of the step");
				 Reporter.log("Test Case Completed and End of the step");
				 
				
		}
		catch (Exception t) 
		{
		System.err.println("Failed");
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		APP_LOGS.debug("Test Failed & End of the Step");
		Reporter.log("Test Failed & End of the Step");
		throw t;
		} 
}
    @AfterMethod
		public void reportDataSetResult(){
			if(skip)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
	
		}
		
		@AfterTest
		public void reportTestResult(){
			if(isTestPass)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
		}
		
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
		}
	}

