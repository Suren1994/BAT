package com.veo.suite.backoffice;
import java.awt.AWTException;
import java.io.IOException;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;
public class Backoffice_08_42 extends TestSuiteBase {
//	private static final WebElement Blank = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
		@BeforeTest
		public void checkTestSkip(){
			
			if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
				APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
				Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
	
	
	@Test(dataProvider="getTestData")
	public void Testbehaviour_of_expecteddeliveryday(
			String uname,
			String pwd,
			String BackOfficeOrderStatus
			) throws InterruptedException, IOException, AWTException,Exception, Throwable{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing Backoffice TC_08_42");
		Reporter.log("Executing Backoffice TC_08_42");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Ability to see a automatically change in the expected delivery date once an emergency flag is removed");
		Reporter.log("Ability to see a automatically change in the expected delivery date once an emergency flag is removed");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
	
		
		// webdriver
		openBrowser();	
		APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
		Reporter.log("Browser up: "+this.getClass().getSimpleName());
	
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Replenishment cockpit URL");
		Reporter.log("Entered Replenishment cockpit URL");
		
		try{
		
//====================================Login to Backoffice========================================================//
	
			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
		//==================================Click on Amended Order=====================================================//
				getObject("BackOffice_OrderStatus_Dropdown").clear();
				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(1000);	
				
				getObject("BackOffice_OrderStatus_Dropdown").sendKeys(BackOfficeOrderStatus);
				APP_LOGS.debug("Selecting BackOffice Order Status is: "+BackOfficeOrderStatus);
				Reporter.log("Selecting BackOffice Order Status is: "+BackOfficeOrderStatus);
				Thread.sleep(1000);
				
				getObject("BackOffice_OrderStatus_Dropdown").click();
				APP_LOGS.debug("Clicked on Order Status");
				Reporter.log("Clicked on Order Status");
				Thread.sleep(3000);	

		//================================= Selecting Start Date==========================================================//
				getObject("BackOffice_StartDate").clear();
				APP_LOGS.debug("Cleared the Start Date");
				Reporter.log("Cleared the Start Date");
				Thread.sleep(3000);		

		//=================================clicking on refresh button================================================================================//
				getObject("Backoffice_RefreshButton").click();
				APP_LOGS.debug("Clicked On Refresh Button");
				Reporter.log("Clicked On Refresh Button");
				Thread.sleep(5000);
					
		//=============== get the current window handle==========//
				String parentHandle = driver.getWindowHandle();		
				
				String Ordernumber = getObject("Backoffice_HomePage_Orders").getText();
								
				//clicking on first order
				getObject("Backoffice_HomePage_Orders").click();
				APP_LOGS.debug("Clicked Order Number is:"+Ordernumber);
				Reporter.log("Clicked Order Number is:"+Ordernumber);
				Thread.sleep(5000);

				for (String winHandle : driver.getWindowHandles()) 
				{
					 //====switch focus of WebDriver to the next found window handle (that's your newly opened window)==//
					driver.switchTo().window(winHandle); 
				}		
				
				   	System.out.println("Switched to new window: "+driver.getTitle());
				    APP_LOGS.debug("Switched to new window: "+driver.getTitle());
					Reporter.log("Switched to new window: "+driver.getTitle());
					
					Thread.sleep(3000);		

	//====================================Retrieving the Expected delivery Date before Setting Emergencey Flag===========//
				WaitUntil_element_Visible("Backoffice_CartPage_DeliveryDate", 1000);
				highlightElement("Backoffice_CartPage_DeliveryDate");
				String BeforeExpectedDeliveryDate = getObject("Backoffice_CartPage_DeliveryDate").getAttribute("Value");
				APP_LOGS.debug("Expected Delivery Date before changing is: "+BeforeExpectedDeliveryDate);
				Reporter.log("Expected Delivery Date before changing is: "+BeforeExpectedDeliveryDate);
				
	//====================================clicking on Amend Button==============================================================================//			
				WaitUntil_element_Visible("Backoffice_CartPage_AmendButton", 1000);
				highlightElement("Backoffice_CartPage_AmendButton");
				getObject("Backoffice_CartPage_AmendButton").click();
				APP_LOGS.debug("Clicked Amend Button in Cart Page");
				Reporter.log("Clicked Amend Button in Cart Page");
				
	//====================================Clicked Emergency Order Checkbox==============================================================================//
				Thread.sleep(3000);
				if(!getObject("Backoffice_EmergencyCheckbox").isSelected())
				{
					APP_LOGS.debug("Emergency Flag is Not Set");
					Reporter.log("Emergency Flag is Not Set");
					
					getObject("Backoffice_EmergencyCheckbox").click();
					APP_LOGS.debug("Emergency Flag is Setted now");
					Reporter.log("Emergency Flag is Setted now");
				}
				
				else
				{
					APP_LOGS.debug("Emergency Flag is already set");
					Reporter.log("Emergency Flag is already set");
				}
				
				
			
//===================================To Click on Save & Close Button===================================================================//
				Thread.sleep(3000);
				getObject("Backoffice_CartPage_SaveAndClose").click();
				APP_LOGS.debug("Clicked Save and Close Button");
				Reporter.log("Clicked Save and Close Button");
				Thread.sleep(3000);

//===================================To Click on Yes Button===================================================================//
				getObject("Backoffice_CartPage_SaveYesButton").click();
				APP_LOGS.debug("Clicked Yes Button in PopUp");
				Reporter.log("Clicked Yes Button in PopUp");
				Thread.sleep(5000);
				  
	//===================================To Switch back to Backoffice Order Window===================================================================//				
				driver.switchTo().window(parentHandle);
				APP_LOGS.debug("Switched to Parent window: "+driver.getTitle());
				Reporter.log("Switched to Parent window: "+driver.getTitle());
				Thread.sleep(3000);
	//===================================To Click on First Order Number to verify the Expected Delivery Date is  updated===================================================================//
				WaitUntil_element_Visible("Backoffice_HomePage_Orders", 100);
				highlightElement("Backoffice_HomePage_Orders");
				getObject("Backoffice_HomePage_Orders").click();
				String VerifyOrderNum = getObject("Backoffice_HomePage_Orders").getText();
				APP_LOGS.debug("Clicked Order Number in Backoffice :"+VerifyOrderNum);
				Reporter.log("Clicked Order Number in Backoffice :"+VerifyOrderNum);
				Thread.sleep(6000);

//===================================To Handle the current Window===================================================================//
				
				for (String winHandle1 : driver.getWindowHandles()) 
				{
					// switch focus of WebDriver to the next found window handle (that's your newly opened window)
				    driver.switchTo().window(winHandle1); 
				   
				}	
				 	System.out.println("Switched to new window: "+driver.getTitle());
					APP_LOGS.debug("Switched to new window: "+driver.getTitle());
					Reporter.log("Switched to new window: "+driver.getTitle());
				
//====================================Verifying the Expected Delivery Date is Autopopulated==============================================================================//
				Thread.sleep(5000);
				highlightElement("Backoffice_CartPage_DeliveryDate");
				String AfterExpectedDeliveryDate = getObject("Backoffice_CartPage_DeliveryDate").getAttribute("Value");	
				APP_LOGS.debug("Expected Delivery Date after changed is :"+AfterExpectedDeliveryDate);
				Reporter.log("Expected Delivery Date after changed is :"+AfterExpectedDeliveryDate);
				
	//====================================Verifying the Expected Delivery Date is Autopopulated==============================================================================//
				Thread.sleep(3000);
				APP_LOGS.debug("Verifying whether the Expected Delivery Date is Changed or not");
				Reporter.log("Verifying whether the Expected Delivery Date is Changed or not");
				
				if(!BeforeExpectedDeliveryDate.equals(AfterExpectedDeliveryDate))
				{
					APP_LOGS.debug("Success: Modified the Expected Delivery Date and it is: "+AfterExpectedDeliveryDate);
					Reporter.log("Success: Modified the Expected Delivery Date and it is: "+AfterExpectedDeliveryDate);
				}
				else
				{
					//capturescreenshot(this.getClass().getSimpleName() + "_" + count);
					APP_LOGS.debug("FAILED: Expected Delivery Date is not autopopulated and it is: "+AfterExpectedDeliveryDate);
					Reporter.log("FAILED: Expected Delivery Date is not autopopulated and it is: "+AfterExpectedDeliveryDate);
					capturescreenshot(this.getClass().getSimpleName()+"__"+count);
					throw new Exception("FAILED: Expected Delivery Date is not autopopulated and it is: "+AfterExpectedDeliveryDate);
				}
						
	//==========================================To Stop the test cases=============================================//
			   APP_LOGS.debug("Test Case Completed and End of the step");	
			   Reporter.log("Test Case Completed and End of the step");
						
		
		}
		catch (Exception t) 
		{
		System.err.println("Failed");
		ErrorUtil.addVerificationFailure(t);
		capturescreenshot(this.getClass().getSimpleName() + "_" + count);
		APP_LOGS.debug("Test Failed & End of the Step");
		Reporter.log("Test Failed & End of the Step");
		throw t;
		} 

}
    @AfterMethod
		public void reportDataSetResult(){
			if(skip)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
			}
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
			
			skip=false;
			fail=false;
	
		}
		
		@AfterTest
		public void reportTestResult(){
			if(isTestPass)
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
			else
				TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
			closeBrowser();
		}
		
		@DataProvider
		public Object[][] getTestData(){
			return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
		}
	}

