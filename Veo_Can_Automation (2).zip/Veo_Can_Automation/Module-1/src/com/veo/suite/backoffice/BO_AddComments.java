package com.veo.suite.backoffice;


import java.io.IOException;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class BO_AddComments extends TestSuiteBase{

	//private static final CharSequence FFC7CE = null;
	String runmodes[]=null;
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=true;
	static int count=-1;
	// Runmode of test case in a suite
	@BeforeTest
	public void checkTestSkip(){
			
		if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
		APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
		Reporter.log("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");
				throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
			}
			runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
		}
		
	@Test(dataProvider="getTestData")
	public void Backoffice_AddComments(
			String uname,
			String pwd,
			String ERPNumber,
			String BackOffice_StartDate_Input,
			String AddComments			
			) throws Throwable,IOException{
		count++;
		if(!runmodes[count].equalsIgnoreCase("Y")){
			throw new SkipException("Runmode for test set data set to no "+count);
		}
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Executing TC_BO_AddComments");
		Reporter.log("Executing TC_BO_AddComments");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Able to Add the Comments and verify Comments Value Changes");
		Reporter.log("Able to Add the Comments and verify Comments Value Changes");
		APP_LOGS.debug("***************************************************************************************");
		Reporter.log("***************************************************************************************");
		APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
		Reporter.log("Username: "+uname+" & Password:"+pwd);
		//sessionData.put("mobile_"+count, uname);
		
		// webdriver
		openBrowser();
		APP_LOGS.debug("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		Reporter.log("Browser Up: "+this.getClass().getSimpleName()+"__"+count);
		
		driver.get(CONFIG.getProperty("backofficeurl"));
		APP_LOGS.debug("Entered Backoffice URL");
		Reporter.log("Entered Backoffice URL");
		
		
		try
		{
//	====================================Login to Backoffice========================================================//

			if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
				// screenshot
				capturescreenshot(this.getClass().getSimpleName()+"_"+count);
				fail=true;
				// quit
				return;
			}
			Thread.sleep(3000);
			
			getObject("BackOffice_ERPNumber_Inputbox").clear();
			getObject("BackOffice_ERPNumber_Inputbox").sendKeys(ERPNumber);
			APP_LOGS.debug("Entered ERP Number is: "+ERPNumber);
			Reporter.log("Entered ERP Number is: "+ERPNumber);
			//Thread.sleep(5000);
			
			getObject("BackOffice_StartDate").clear();
			/*getObject("BackOffice_StartDate").sendKeys(BackOffice_StartDate_Input);
			APP_LOGS.debug("Entered Start Date is: "+BackOffice_StartDate_Input);
			Reporter.log("Entered Start Date is: "+BackOffice_StartDate_Input);
			Thread.sleep(2000);*/

		//=====================To Click on Refresh Button===================//
			getObject("Backoffice_RefreshButton").click();
			APP_LOGS.debug("Clicked Refresh Button");
			Reporter.log("Clicked Refresh Button");
			//Thread.sleep(5000);
			
		//=====================To Click on First ERP Number ===================//
			String FirstERPNumber =BackofficeFindElements("//span[@class='z-html']/a",1);
			APP_LOGS.debug("The Value of FirstERPNumber present is: "+FirstERPNumber);
			Reporter.log("The Value of FirstERPNumber present is: "+FirstERPNumber);
			//Thread.sleep(3000);
			
			highlightElement("BackOffice_Comments_Button");
			//Thread.sleep(3000);

			String InitialComment  = getObject("BackOffice_Comments_Button").getText();
			APP_LOGS.debug("Initial Comments Button Value is: "+InitialComment);
			Reporter.log("Initial Comments Button Value is: "+InitialComment);
			
			getObject("BackOffice_Comments_Button").click();
			APP_LOGS.debug("Clicked Comments Button forERP Number is: "+FirstERPNumber);
			Reporter.log("Clicked Comments Button forERP Number is: "+FirstERPNumber);
			
			getObject("BackOffice_Comments_IntputText").clear();
			getObject("BackOffice_Comments_IntputText").sendKeys(AddComments);
			APP_LOGS.debug("Entered Comment is: "+AddComments);
			Reporter.log("Entered Comment is: "+AddComments);
			
			getObject("BackOffice_Comments_AddButton").click();
			APP_LOGS.debug("Clicked Add Button");
			Reporter.log("Clicked Add Button");
			
			WaitForObjectAvailability("BackOffice_Comment_WindowCloseButton");
			highlightElement("BackOffice_Comment_WindowCloseButton");
			Thread.sleep(2000);
			getObject("BackOffice_Comment_WindowCloseButton").click();
			APP_LOGS.debug("Closed Comment Window");
			Reporter.log("Closed Comment Window");
			
			//=====================To Click on Refresh Button===================//
			//Thread.sleep(1000);
			getObject("Backoffice_RefreshButton").click();
			APP_LOGS.debug("Clicked Refresh Button");
			Reporter.log("Clicked Refresh Button");
			
			Thread.sleep(3000);
			highlightElement("BackOffice_Comments_Button");
			
			String FinalComment  = getObject("BackOffice_Comments_Button").getText();
			APP_LOGS.debug("Final Comments Button Value is: "+FinalComment);
			Reporter.log("Final Comments Button Value is: "+FinalComment);
			
			if(!InitialComment.equals(FinalComment))
			{
				APP_LOGS.debug("Success: Comments Value is changed");
				Reporter.log("Success: Comments Value is changed");
			}
			
			else
			{
				APP_LOGS.debug("FAILED: Comments Value is not changed");
				Reporter.log("FAILED: Comments Value is not changed");
				capturescreenshot(this.getClass().getSimpleName() + "_" + count);
				throw new Exception("FAILED: Comments Value is not changed");
			}
			
		 //==========================================To Stop the test cases=============================================//
		 APP_LOGS.debug("Test Case Completed and End of the step");
		 Reporter.log("Test Case Completed and End of the step");
		 
			}
			catch(Exception e)
			{
				ErrorUtil.addVerificationFailure(e);
				System.err.println("FAILED");
				capturescreenshot(this.getClass().getSimpleName() + "_" + count);
				APP_LOGS.debug("Failed");
				Reporter.log("Failed");
				throw e;
								
			}
		
	}
		
	  @AfterMethod
	  public void reportDataSetResult(){
				if(skip)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
				else if(fail){
					isTestPass=false;
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
				}
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
				
				skip=false;
				fail=false;
				

			}
			
		@AfterTest
		public void reportTestResult(){
				if(isTestPass)
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
				else
					TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
				closeBrowser();
			}
			
			
			
		@DataProvider
		public Object[][] getTestData(){
				return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
			}
		}

		

