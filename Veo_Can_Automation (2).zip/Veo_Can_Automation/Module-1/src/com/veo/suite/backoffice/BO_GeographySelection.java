package com.veo.suite.backoffice;


import java.awt.AWTException;
import java.io.IOException;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

	public class BO_GeographySelection extends TestSuiteBase{

		String runmodes[]=null;
		static boolean fail=false;
		static boolean skip=false;
		static boolean isTestPass=true;
		static int count=-1;
		// Runmode of test case in a suite
			@BeforeTest
			public void checkTestSkip(){
				
				if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
					APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
					throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
				}
				runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
			}
		
		
		@Test(dataProvider="getTestData")
		public void  filter_based_on_Geography(
				String uname,
				String pwd
				) throws InterruptedException, IOException, AWTException,Exception, Throwable{
			count++;
			if(!runmodes[count].equalsIgnoreCase("Y")){
				throw new SkipException("Runmode for test set data set to no "+count);
			}
			
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Executing Backoffice TC_BO_GeographySelection");
			Reporter.log("Executing Backoffice TC_BO_GeographySelection");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Ability to filter based on Geography (territory, district, region, province, or any other pre-defined group)");
			Reporter.log("Ability to filter based on Geography (territory, district, region, province, or any other pre-defined group)");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
			Reporter.log("Username: "+uname+" & Password:"+pwd);
			
			// webdriver
			openBrowser();
			APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
			Reporter.log("Browser up: "+this.getClass().getSimpleName());
			
			driver.get(CONFIG.getProperty("backofficeurl"));
			APP_LOGS.debug("Entered Replenishment cockpit URL");
			Reporter.log("Entered Replenishment cockpit URL");
			try{
				
				//=================================== Login to Backoffice ===================================//
							
				if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
					// screenshot
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit
					return;
				}		
				Thread.sleep(5000);		
			
			 //=================================== Clicking on Add Button ===================================//
						highlightElement("Backoffice_Order_AddButton");
						getObject("Backoffice_Order_AddButton").click();
						APP_LOGS.debug("Clicked on Add button in Home Page");
						Reporter.log("Clicked on Add button in Home Page");
						Thread.sleep(3000);

						
			 //=================================== Selecting the desired Comments ===================================//
						getObject("Backoffice_GeographyWindow_Expand").click();
						APP_LOGS.debug("Clicked on Expand Arrow of Geography window");
						Reporter.log("Clicked on Expand Arrow of Geography window");
						Thread.sleep(3000);

						String desire_reg = getObject("Backoffice_GeographyWindow_Region").getText();
						System.out.println("The desired region is: "+desire_reg);
						APP_LOGS.debug("The desired region is: "+desire_reg);
						Reporter.log("The desired region is: "+desire_reg);
						Thread.sleep(3000);
						getObject("Backoffice_GeographyWindow_Region").click();
						APP_LOGS.debug("Clicked on the Desired Region");
						Reporter.log("Clicked on the Desired Region");
						Thread.sleep(3000);

			 //=================================== Validating the Selected Region ===================================//
						getObject("Backoffice_HomePage_SelectedRegion").click();
						APP_LOGS.debug("Selected the added region in HomePage");
						Reporter.log("Selected the added region in HomePage");
						Thread.sleep(2000);
						
						highlightElement("Backoffice_Order_Delete");
						getObject("Backoffice_Order_Delete").click();
						APP_LOGS.debug("Clicked on Delete Button in Home Page"); 
						Reporter.log("Clicked on Delete Button in Home Page"); 
						Thread.sleep(3000);
						
						System.out.println("Test Passed");
						APP_LOGS.debug("Test Passed"); 
						Reporter.log("Test Passed");

						
						APP_LOGS.debug("Test Completed & End of the Step");
						Reporter.log("Test Completed & End of the Step");
						
			}
		
			catch (Exception t) 
			{
			System.err.println("Failed");
			ErrorUtil.addVerificationFailure(t);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Test Failed & End of the Step");
			Reporter.log("Test Failed & End of the Step");
			throw t;
			} 

					}
						
					     @AfterMethod
							public void reportDataSetResult(){
								if(skip)
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
								else if(fail){
									isTestPass=false;
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
								}
								else
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
								
								skip=false;
								fail=false;
						
							}
							
							@AfterTest
							public void reportTestResult(){
								if(isTestPass)
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
								else
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
								closeBrowser();
							}
							
							@DataProvider
							public Object[][] getTestData(){
								return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
							}
						}
		
		

