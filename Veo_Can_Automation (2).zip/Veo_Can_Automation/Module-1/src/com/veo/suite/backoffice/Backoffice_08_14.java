
package com.veo.suite.backoffice;


import java.awt.AWTException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

	public class Backoffice_08_14 extends TestSuiteBase{

		String runmodes[]=null;
		static boolean fail=false;
		static boolean skip=false;
		static boolean isTestPass=true;
		static int count=-1;
		// Runmode of test case in a suite
			@BeforeTest
			public void checkTestSkip(){
				
				if(!TestUtil.isTestCaseRunnable(suite_Can_BackOffice_xls,this.getClass().getSimpleName())){
					APP_LOGS.debug("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//logs
					throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
				}
				runmodes=TestUtil.getDataSetRunmodes(suite_Can_BackOffice_xls, this.getClass().getSimpleName());
			}
		
		
		@Test(dataProvider="getTestData")
		public void ability_to_Sort_by_any_column(
				String uname,
				String pwd,
				String Start_Date,
				String End_Date
				) throws InterruptedException, IOException, AWTException,Exception, Throwable{
			count++;
			if(!runmodes[count].equalsIgnoreCase("Y")){
				throw new SkipException("Runmode for test set data set to no "+count);
			}
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Executing Backoffice TC_08_14");
			Reporter.log("Executing Backoffice TC_08_14");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Ability to Sort by any column on the replenishment cockpit");
			Reporter.log("Ability to Sort by any column on the replenishment cockpit");
			APP_LOGS.debug("***************************************************************************************");
			Reporter.log("***************************************************************************************");
			APP_LOGS.debug("Username: "+uname+" & Password:"+pwd);
			Reporter.log("Username: "+uname+" & Password:"+pwd);	
			
			// webdriver
			openBrowser();
			APP_LOGS.debug("Browser up: "+this.getClass().getSimpleName());
			Reporter.log("Browser up: "+this.getClass().getSimpleName());
			
			driver.get(CONFIG.getProperty("backofficeurl"));
			APP_LOGS.debug("Entered Replenishment cockpit URL");
			Reporter.log("Entered Replenishment cockpit URL");
			
			try{
				
				//==================================== Login to Backoffice ====================================//
							
				if(!LoginBackOffice("Backoffice_LoginPage_Username","Backoffice_LoginPage_Password","Backoffice_LoginPage_LoginButton",uname,pwd)){
					// screenshot
					capturescreenshot(this.getClass().getSimpleName()+"_"+count);
					fail=true;
					// quit
					return;
				}		
				Thread.sleep(5000);		
			
			//==================================== Clicking on Desired Start Date ====================================//
						
						
						getObject("Backoffice_Startdate").clear();
						APP_LOGS.debug("Cleared Start Date");
						Reporter.log("Cleared Start Date ");
						
						getObject("Backoffice_Startdate").sendKeys(Start_Date);
						APP_LOGS.debug("Entered Start Date");
						Reporter.log("Entered Start Date ");
						Thread.sleep(3000);		

						getObject("Backoffice_EndDate").clear();
						APP_LOGS.debug("Cleared End Date");
						Reporter.log("Cleared End Date ");
						
						getObject("Backoffice_EndDate").sendKeys(End_Date);
						APP_LOGS.debug("Entered End Date ");
						Reporter.log("Entered End Date ");
						Thread.sleep(3000);		

			//==================================== Clicking on Refresh button ====================================//
						highlightElement("Backoffice_RefreshButton");
						getObject("Backoffice_RefreshButton").click();
						APP_LOGS.debug("Clicked on Refresh Button "); 
						Reporter.log("Clicked on Refresh Button "); 
						Thread.sleep(5000);
	
		  //==================================== Clicking on the Desired Column ====================================//
					int rowcount;
					List<WebElement> tablerow=null;  
					
					
					Thread.sleep(3000);
					rowcount = driver.findElements(By.xpath("//table/tbody[2]/tr/td/div/span/a")).size();
					System.out.println("No.of Rows "+rowcount);
					APP_LOGS.debug("No.of Rows "+rowcount); 
					Reporter.log("No.of Rows "+rowcount); 
					
					tablerow = driver.findElements(By.xpath("//table/tbody[2]/tr"));
					System.out.println("Total No.Of Rows in Table "+tablerow.size());
					APP_LOGS.debug("Total No.Of Rows in Table "+tablerow.size()); 
					Reporter.log("Total No.Of Rows in Table "+tablerow.size()); 

					System.out.println("----------------------------------------------------------------------");
					APP_LOGS.debug("----------------------------------------------------------------------"); 
					Reporter.log("----------------------------------------------------------------------"); 
					
					System.out.println("Trying to Click on Actual Column...");
					APP_LOGS.debug("Trying to Click on Actual Column..."); 
					Reporter.log("Trying to Click on Actual Column..."); 
					
		 //==================================== Clicking on the Actual Column ====================================//
					
					getObject("Backoffice_HomePage_ActualColumn").click();
					APP_LOGS.debug("Clicked on Actual Column for first time"); 
					Reporter.log("Clicked on Actual Column for first time"); 
					Thread.sleep(5000);
					
					String str[] = new String[tablerow.size()];
					String rc[] = new String[tablerow.size()];
					
					System.out.println("----------- ACTUAL ----------");
					System.out.println("Sorting in Ascending order!!!!");
					APP_LOGS.debug("Sorting in Ascending order!!!!"); 
					Reporter.log("Sorting in Ascending order!!!!"); 
					
					int k =driver.findElements(By.xpath("//table/tbody[2]/tr/td/div/span/a")).size();
					if(!(k==0))
					{
						for (int i=1;i<=rowcount;i++) {
							str[i-1]= driver.findElement(By.xpath("//table/tbody[2]/tr["+i+"]/td[10][@class='yw-listview-cell z-listcell']")).getText();
							System.out.println(str[i-1]);
							APP_LOGS.debug(str[i-1]);
							Reporter.log(str[i-1]); 
							}	
							APP_LOGS.debug("Sorted in Ascending"); 
							Reporter.log("Sorted in Ascending"); 
					}
					else
					{
						APP_LOGS.debug("FAILED: Could not find the search results data in Actual Column");
						Reporter.log("FAILED: Could not find the search results data in Actual Column");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						throw new Exception("Failed: Could not find the search results data in Actual Column");
					}
					
			//==================================== Again Clicking on the Actual Column ====================================//			
					System.out.println("Trying to Click on Actual Column seconfd time...");	
					APP_LOGS.debug("Trying to Click on Actual Column seconfd time..."); 
					Reporter.log("Trying to Click on Actual Column seconfd time..."); 
					
					getObject("Backoffice_HomePage_ActualColumn").click();
					APP_LOGS.debug("Clicked on Actual Column for second time"); 
					Reporter.log("Clicked on Actual Column for second time"); 
					Thread.sleep(5000);
					
					System.out.println("----------- ACTUAL ----------");
					System.out.println("Sorting in Descending order!!!!");
					APP_LOGS.debug("Sorting in Descending order!!!!"); 
					Reporter.log("Sorting in Descending order!!!!"); 
					
					int l =driver.findElements(By.xpath("//table/tbody[2]/tr/td/div/span/a")).size();
					if(!(l==0))
					{
						for(int i=1;i<=rowcount;i++)
						{
							rc[i-1]= driver.findElement(By.xpath("//table/tbody[2]/tr["+i+"]/td[10][@class='yw-listview-cell z-listcell']")).getText();
							System.out.println(rc[i-1]);
							APP_LOGS.debug(rc[i-1]);
							Reporter.log(rc[i-1]); 
						}	
						
				APP_LOGS.debug("Sorted in Descending order");
				Reporter.log("Sorted in Descending order");
					}
					else
					{
						APP_LOGS.debug("FAILED: Could not find the search results data in Actual Column");
						Reporter.log("FAILED: Could not find the search results data in Actual Column");
						capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						throw new Exception("FAILED: Could not find the search results data in Actual Column");
					}
					
				
				System.out.println("Test Passed");
				APP_LOGS.debug("Test Passed");
				Reporter.log("Test Passed");	
				
		//==================================== Clicking on Logout button ====================================//
						Thread.sleep(2000);
						highlightElement("Backoffice_Logout");
						getObject("Backoffice_Logout").click();
						APP_LOGS.debug("Clicked on Logout button");
						Reporter.log("Clicked on Logout button");
						
						APP_LOGS.debug("Test Completed & End of the Step");
						Reporter.log("Test Completed & End of the Step");		
					
												
			}
		
			catch (Exception t) 
			{
			System.err.println("Failed");
			ErrorUtil.addVerificationFailure(t);
			capturescreenshot(this.getClass().getSimpleName() + "_" + count);
			APP_LOGS.debug("Test Failed & End of the Step");
			Reporter.log("Test Failed & End of the Step");
			throw t;
			} 
					}
						
					     @AfterMethod
							public void reportDataSetResult(){
								if(skip)
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "SKIP");
								else if(fail){
									isTestPass=false;
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "FAIL");
								}
								else
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, this.getClass().getSimpleName(), count+2, "PASS");
								
								skip=false;
								fail=false;
						
							}
							
							@AfterTest
							public void reportTestResult(){
								if(isTestPass)
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "PASS");
								else
									TestUtil.reportDataSetResult(suite_Can_BackOffice_xls, "Test Cases", TestUtil.getRowNum(suite_Can_BackOffice_xls,this.getClass().getSimpleName()), "FAIL");
								
								closeBrowser();	
							}
							
							@DataProvider
							public Object[][] getTestData(){
								return TestUtil.getData(suite_Can_BackOffice_xls, this.getClass().getSimpleName()) ;
							}
						}
		
		


