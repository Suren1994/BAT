package test;

import com.veo.util.Zip;

public class TestZip {

	public static void main(String[] args) throws Exception {
      
		//System.out.println();
		Zip.zipFolder("C:\\rep", "C:\\myzippedFolder.rar");
		
	}
}
