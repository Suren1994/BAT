package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.suite.backoffice.TestSuiteBase;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class veo_home_page extends TestSuiteBase
{
	
	/*By login_page_retailer_store_number = By.cssSelector(".col-xs-7>input[id='retailer-store-number']");
	By login_page_retailer_password		= By.cssSelector(".col-xs-7>input[id='retailer-password']");
	By login_page_ageCheckboxRetailer	= By.cssSelector(".checkbox.pb5.pt0>label>input[id='ageCheckboxRetailer']");
	By login_page_forgotpassword_lnk	= By.cssSelector(".login-help.dib.pt15>ul>li>a[title='Forgot your password1?']");
	By login_page_troublelogging_lnk	= By.cssSelector(".login-help.dib.pt15>ul>li>a[title='Having trouble logging in?']");
	*/
	
	By Home_page_HelpandContact_Link = By.cssSelector("a[title*='Help & Contact']");
	
	public void click_on_helpandcontactus_link()
	{
		driver.findElement(Home_page_HelpandContact_Link).click();
		prntResults("Clicked on Help and ContactUs Link");
		
	}	
   
	}

