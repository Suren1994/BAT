package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.suite.backoffice.TestSuiteBase;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class veo_contact_us extends TestSuiteBase
{
	
	By fa_enevelope 				= By.cssSelector(".container>div[class='row']>h1>i");
	By contact_name 				= By.cssSelector(".form-control.required[id='contact-name']");
	By contact_email				= By.cssSelector(".form-control.required[id='contact-email']");
	By contact_reason				= By.cssSelector(".form-control.required[id='contact-reason']");
	By Reason_for_Contact			= By.xpath(".//*[@id='contact-reasonSelectBoxItArrowContainer']");
	
	By contact_reasonSelectBoxIt	= By.cssSelector(".form-control.required[id='contact-reasonSelectBoxIt']");
	By message						= By.cssSelector(".form-control.required[id='contact-message']");
	By contact_copy					= By.cssSelector(".col-xs-offset-2.col-xs-10>div>input[id='contact-copy']");
	By send_button					= By.cssSelector(".col-xs-offset-2.col-xs-3.pb5>button");
	

	public void set_contact_name(String str)
	{
		driver.findElement(contact_name).clear();
		driver.findElement(contact_name).sendKeys(str);
		prntResults("Entered contactuspage_name"+str);
				
	}
	
	public void set_contact_email(String str)
	{
		driver.findElement(contact_email).clear();
		driver.findElement(contact_email).sendKeys(str);
		prntResults("Entered contactuspage_email"+str);
		
	}

	public void set_contact_reason(String str) throws IOException, Throwable
	{
		driver.findElement(Reason_for_Contact).click();
		driver.findElement(By.xpath((".//*[@id='contact-reasonSelectBoxItOptions']/li[3]/a"))).click();
		prntResults("Entered ReasonforContact"+str);		
	}
	
	public void set_message(String str)
	{
		driver.findElement(message).clear();
		driver.findElement(message).sendKeys(str);
		prntResults("Entered contactuspage_Description"+str);
		
	}
	

	public void click_contact_copy()
	{
		driver.findElement(contact_copy).click();
		prntResults("Clicked on Contactus_contactuspage_Checkbox");
		
	}
	
	public void click_send_button()
	{
		driver.findElement(send_button).click();
		prntResults("Clicked on Contactus_contactuspage_SendButton");
		
		
	}
}

