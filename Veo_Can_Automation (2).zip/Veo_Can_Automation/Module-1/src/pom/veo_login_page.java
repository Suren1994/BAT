package pom;

import org.openqa.selenium.By;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.suite.backoffice.TestSuiteBase;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class veo_login_page extends TestSuiteBase
{
	
	By login_page_retailer_store_number = By.cssSelector(".col-xs-7>input[id='retailer-store-number']");
	By login_page_retailer_password		= By.cssSelector(".col-xs-7>input[id='retailer-password']");
	By login_page_ageCheckboxRetailer	= By.cssSelector(".checkbox.pb5.pt0>label>input[id='ageCheckboxRetailer']");
	By login_page_forgotpassword_lnk	= By.cssSelector(".login-help.dib.pt15>ul>li>a[title='Forgot your password1?']");
	By login_page_troublelogging_lnk	= By.cssSelector(".login-help.dib.pt15>ul>li>a[title='Having trouble logging in?']");
	By login_page_retailer_login_button	= By.cssSelector(".col-xs-9.pb5>button[id='retailer-login-button']");
	
	public void set_retailer_store_number(String str)
	{
		driver.findElement(login_page_retailer_store_number).clear();
		driver.findElement(login_page_retailer_store_number).sendKeys(str);
		
	}
	
	public void set_retailer_password(String str)
	{
		driver.findElement(login_page_retailer_password).clear();
		driver.findElement(login_page_retailer_password).sendKeys(str);
	}
	
	public void check_ageCheckboxRetailer(int iVal)
	{
		driver.findElement(login_page_ageCheckboxRetailer).click();
	}
	
	public void click_link(String str)
	{
		if (str =="forgotpassword_lnk")
		{
			driver.findElement(login_page_forgotpassword_lnk).click();
		}
		else if (str == "troublelogging_lnk")
		{
			driver.findElement(login_page_troublelogging_lnk).click();
		}
	}
	
	public void click_button(String str)
	{
		if (str == "login")
		{
			driver.findElement(login_page_retailer_login_button).click();
		}
	}
}
